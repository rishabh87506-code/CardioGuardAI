# CardioGuard AI - Live Deployment Guide
**Target Domain:** `www.cardioguardai.co.in`

Your application has been successfully built for production. The `dist/` folder contains the optimized, minified code ready for deployment.

Since this is a Single Page Application (SPA) using React Router, special configuration files (`_redirects` for Netlify, `vercel.json` for Vercel) have already been generated and included in the build to ensure refreshing pages like `/analyze` works correctly.

## Option 1: Deploy with Netlify (Recommended)
Netlify detects the `_redirects` file automatically.

1.  **Create Account:** Go to [Netlify.com](https://www.netlify.com) and sign up/login.
2.  **Upload:**
    *   Navigate to the "Sites" tab.
    *   Drag and drop the `dist` folder directly onto the "Drag and drop your site folder here" area.
3.  **Custom Domain Setup:**
    *   Once deployed, click on "Domain settings".
    *   Click "Add custom domain".
    *   Enter `www.cardioguardai.co.in`.
    *   Netlify will provide you with DNS records.
4.  **DNS Configuration (at your Registrar):**
    *   Log in to where you bought `cardioguardai.co.in` (e.g., GoDaddy, Namecheap).
    *   Add a **CNAME** record:
        *   **Host/Name:** `www`
        *   **Value/Target:** `[your-site-name].netlify.app` (Netlify will show you this).
    *   Add an **A** record (for root domain redirection):
        *   **Host/Name:** `@`
        *   **Value:** `75.2.60.5` (Netlify Load Balancer IP).

## Option 2: Deploy with Vercel
Vercel detects the `vercel.json` file automatically.

1.  **Create Account:** Go to [Vercel.com](https://vercel.com) and sign up/login.
2.  **Upload:**
    *   Install Vercel CLI: `npm i -g vercel`
    *   Run `vercel` in your terminal and follow the prompts.
    *   Select the `dist` folder if asked, or just deploy the project root.
3.  **Custom Domain:**
    *   Go to your project dashboard -> Settings -> Domains.
    *   Add `www.cardioguardai.co.in`.
    *   Vercel will give you the required A/CNAME records (usually `76.76.21.21` for A record).

## Option 3: Traditional Hosting (cPanel/Apache/Nginx)
If hosting on a standard server:

1.  **Upload:** Upload the contents of the `dist` folder to your `public_html`.
2.  **Server Config:** You MUST configure your server to rewrite all requests to `index.html` (since this is an SPA).
    *   **Apache (.htaccess):**
        ```apache
        <IfModule mod_rewrite.c>
          RewriteEngine On
          RewriteBase /
          RewriteRule ^index\.html$ - [L]
          RewriteCond %{REQUEST_FILENAME} !-f
          RewriteCond %{REQUEST_FILENAME} !-d
          RewriteRule . /index.html [L]
        </IfModule>
        ```
    *   **Nginx:**
        ```nginx
        location / {
          try_files $uri $uri/ /index.html;
        }
        ```

## Post-Deployment Checklist
- [ ] Verify SSL certificate is active (https://...).
- [ ] Check `/analyze` route works when refreshed.
- [ ] Test the "Connect Wearable" feature on a mobile device (requires SSL context).
