
export type SupportedLanguage = 'English' | 'Hindi' | 'Spanish' | 'French' | 'German' | 'Chinese' | 'Japanese';

export interface VitalsData {
  age: number;
  gender: 'male' | 'female' | 'other';
  systolicBP: number;
  diastolicBP: number;
  totalCholesterol: number;
  hdlCholesterol: number;
  isSmoker: boolean;
  hasDiabetes: boolean;
  heightCm: number;
  weightKg: number;
  activityLevel: 'sedentary' | 'moderate' | 'active';
  medicalId?: string; // e.g., ABHA ID
  heartRate?: number;
  bloodSugar?: number;
  spO2?: number;
  temperature?: number;
  respiratoryRate?: number;
  hrv?: number;
  patientName?: string;
  identificationId?: string;
}

export interface MedicalDocument {
  id: string;
  type: 'CT' | 'X-Ray' | 'Echo' | 'Lab Report' | 'ECG';
  fileName: string;
  uploadDate: number;
  analysis?: {
    criticality: number; // 0-100
    summary: string;
    pointers: string[];
    isUrgent: boolean;
  };
  base64Data?: string;
  storagePath?: string;
}

export interface AssessmentResult {
  riskScore: number;
  riskCategory: 'Low' | 'Moderate' | 'High' | 'Very High';
  summary: string;
  consistencyScore: number; // 0-100 (Detection of "lying" or clinical variance)
  consistencyAlert?: string;
  keyFactors: {
    factor: string;
    impact: 'positive' | 'negative' | 'neutral';
    description: string;
  }[];
  recommendations: string[];
  disclaimer: string;
  timeline?: {
    expectedOnsetHours: string;
    severityProgression: 'Stable' | 'Slow' | 'Rapid' | 'Acute';
    clinicalMilestones: string[];
  };
}

export type TriageLevel = 'Critical' | 'Urgent' | 'Stable' | 'Routine';
export type CaseType = 'Disease' | 'Drug' | 'Healthy' | 'Mix';

export interface StressTestStats {
  total: number;
  completed: number;
  failed: number;
  accuracy: number;
  avgTimeMs: number;
  riskDistribution: Record<string, number>;
}

export interface HistoricalAssessment extends AssessmentResult {
  id: string;
  timestamp: number;
  vitals: VitalsData;
  isEncrypted?: boolean;
  patientName?: string;
  triageLevel?: TriageLevel;
  expectedRisk?: string;
  caseType?: string;
}

export interface Medication {
  id: string;
  name: string;
  dosage: string;
  frequency: string;
  purpose: string;
}

// Added TestCase interface for Diagnostic Lab verification module
export interface TestCase {
  id: string;
  age: number;
  cholesterol: number;
  bpSystolic: number;
  smoker: boolean;
  diabetic: boolean;
  activity: string;
  targetRisk: string;
  status: 'pending' | 'running' | 'completed' | 'error';
  prediction?: AssessmentResult;
  // Enhanced fields for Clinical Simulation
  symptoms?: string[];
  medicalHistory?: string[];
  conditionProfile?: string;
  gender?: 'male' | 'female';
  bpDiastolic?: number;
}

export enum ViewState {
  INPUT = 'input',
  LOADING = 'loading',
  RESULT = 'result',
  HISTORY = 'history',
  DASHBOARD = 'dashboard',
  LAB = 'lab',
  SCAN = 'scan',
  AGENTS = 'agents',
  MARKETING = 'marketing',
  PPG = 'ppg',
  LOCKER = 'locker',
  DOCTOR = 'doctor', // New view for doctors
  EMERGENCY = 'emergency', // New view for emergency access
  CONCIERGE = 'concierge',
  MEDICATIONS = 'medications',
  FEED = 'feed',
  RESEARCH = 'research',
  WEARABLES = 'wearables',
  SELF_EVAL = 'self_eval',
  PRIVACY = 'privacy',
  TERMS = 'terms',
  HEALTHCARE = 'healthcare',
  STRESS_TEST = 'stress_test',
  DEV_WORKSPACE = 'dev_workspace',
  AUDIT_SUITE = 'audit_suite'
}


export type SocialChannel = 'twitter' | 'linkedin' | 'instagram' | 'email';

export interface MarketingDraft {
  id: string;
  channel: SocialChannel;
  content: string;
  status: 'draft' | 'approved' | 'rejected' | 'posted';
  predictedEngagement: string; // e.g. "High", "Medium"
  hashtags: string[];
  timestamp: number;
}

export interface Doctor {
  id: string;
  fullName: string;
  specialty: string;
  hospital: string;
  npiNumber?: string;
  verified: boolean;
}

export interface AccessGrant {
  id: string;
  patientId: string;
  doctorId?: string;
  token: string;
  accessType: 'EMERGENCY' | 'CONSULTATION' | 'PERMANENT';
  expiresAt: number;
}
