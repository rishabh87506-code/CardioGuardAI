import { useState, useEffect, useCallback } from 'react';
import { VitalsData } from '../types';
import { VitalsReading } from '../services/wearableService';

interface FusionStatus {
    isVerified: boolean;
    sourceMismatch: boolean;
    activeSources: ('camera' | 'wearable')[];
    confidenceScore: number; // 0-100
}

export const useVitalsFusion = (
    cameraVitals: VitalsData | null,
    wearableVitals: VitalsReading | null
) => {
    const [status, setStatus] = useState<FusionStatus>({
        isVerified: false,
        sourceMismatch: false,
        activeSources: [],
        confidenceScore: 0
    });

    const verifyAuthenticity = useCallback(() => {
        const sources: ('camera' | 'wearable')[] = [];
        if (cameraVitals) sources.push('camera');
        if (wearableVitals) sources.push('wearable');

        let verified = false;
        let mismatch = false;
        let score = 0;

        if (sources.length === 0) {
            // No data
            verified = false;
            score = 0;
        } else if (sources.length === 1) {
            // Single source is "valid" but not "cross-verified"
            verified = true;
            score = 75; // Good confidence for single source
        } else {
            // Dual source: Cross-reference
            if (cameraVitals && wearableVitals && cameraVitals.heartRate !== undefined && wearableVitals.heartRate !== undefined) {
                const bpmDiff = Math.abs(cameraVitals.heartRate - wearableVitals.heartRate);

                // Allow 10% variance
                const threshold = 10;

                if (bpmDiff <= threshold) {
                    verified = true;
                    mismatch = false;
                    score = 98; // High confidence!
                } else {
                    verified = false;
                    mismatch = true;
                    score = 40; // Penalty for mismatch
                }
            }
        }

        setStatus({
            isVerified: verified,
            sourceMismatch: mismatch,
            activeSources: sources,
            confidenceScore: score
        });
    }, [cameraVitals, wearableVitals]);

    useEffect(() => {
        verifyAuthenticity();
    }, [verifyAuthenticity]);

    return status;
};
