/**
 * CardioGuard AI - Cloud Sync Service
 * 
 * Handles syncing health data between local storage and Supabase cloud.
 * Supports offline-first with automatic sync when online.
 */

import { supabase, isSupabaseConfigured } from './supabaseService';
import type { User } from '@supabase/supabase-js';

// Types matching our database schema
export interface CloudUserProfile {
    id: string;
    name?: string;
    age?: number;
    gender?: string;
    known_conditions: string[];
    medications: string[];
    allergies: string[];
    emergency_contact?: {
        name: string;
        phone: string;
        relationship: string;
    };
    created_at?: string;
    updated_at?: string;
}

export interface CloudAssessment {
    id?: string;
    user_id: string;
    risk_score: number;
    risk_category: string;
    summary: string;
    vitals: Record<string, any>;
    key_factors: Array<{
        factor: string;
        impact: string;
        description: string;
    }>;
    recommendations: string[];
    created_at?: string;
}

export interface CloudSymptomEntry {
    id?: string;
    user_id: string;
    symptom: string;
    category?: string;
    severity?: string;
    notes?: string;
    triggers?: string[];
    created_at?: string;
}

/**
 * Sync user profile to cloud
 */
export async function syncProfile(profile: Partial<CloudUserProfile>): Promise<{ success: boolean; error?: string }> {
    if (!isSupabaseConfigured) {
        return { success: false, error: 'Supabase not configured' };
    }

    try {
        const { data: { user } } = await supabase.auth.getUser();
        if (!user) {
            return { success: false, error: 'User not authenticated' };
        }

        const { error } = await supabase
            .from('user_profiles')
            .upsert({
                id: user.id,
                ...profile,
                updated_at: new Date().toISOString(),
            });

        if (error) {
            return { success: false, error: error.message };
        }

        return { success: true };
    } catch (err: any) {
        return { success: false, error: err.message };
    }
}

/**
 * Fetch user profile from cloud
 */
export async function fetchProfile(): Promise<{ profile: CloudUserProfile | null; error?: string }> {
    if (!isSupabaseConfigured) {
        return { profile: null, error: 'Supabase not configured' };
    }

    try {
        const { data: { user } } = await supabase.auth.getUser();
        if (!user) {
            return { profile: null, error: 'User not authenticated' };
        }

        const { data, error } = await supabase
            .from('user_profiles')
            .select('*')
            .eq('id', user.id)
            .single();

        if (error && error.code !== 'PGRST116') { // PGRST116 = no rows returned
            return { profile: null, error: error.message };
        }

        return { profile: data };
    } catch (err: any) {
        return { profile: null, error: err.message };
    }
}

/**
 * Save assessment to cloud
 */
export async function syncAssessment(assessment: Omit<CloudAssessment, 'user_id'>): Promise<{ success: boolean; id?: string; error?: string }> {
    if (!isSupabaseConfigured) {
        return { success: false, error: 'Supabase not configured' };
    }

    try {
        const { data: { user } } = await supabase.auth.getUser();
        if (!user) {
            return { success: false, error: 'User not authenticated' };
        }

        const { data, error } = await supabase
            .from('health_assessments')
            .insert({
                ...assessment,
                user_id: user.id,
            })
            .select('id')
            .single();

        if (error) {
            return { success: false, error: error.message };
        }

        return { success: true, id: data?.id };
    } catch (err: any) {
        return { success: false, error: err.message };
    }
}

/**
 * Fetch all assessments from cloud
 */
export async function fetchAssessments(limit: number = 50): Promise<{ assessments: CloudAssessment[]; error?: string }> {
    if (!isSupabaseConfigured) {
        return { assessments: [], error: 'Supabase not configured' };
    }

    try {
        const { data: { user } } = await supabase.auth.getUser();
        if (!user) {
            return { assessments: [], error: 'User not authenticated' };
        }

        const { data, error } = await supabase
            .from('health_assessments')
            .select('*')
            .eq('user_id', user.id)
            .order('created_at', { ascending: false })
            .limit(limit);

        if (error) {
            return { assessments: [], error: error.message };
        }

        return { assessments: data || [] };
    } catch (err: any) {
        return { assessments: [], error: err.message };
    }
}

/**
 * Save symptom entry to cloud
 */
export async function syncSymptom(symptom: Omit<CloudSymptomEntry, 'user_id'>): Promise<{ success: boolean; id?: string; error?: string }> {
    if (!isSupabaseConfigured) {
        return { success: false, error: 'Supabase not configured' };
    }

    try {
        const { data: { user } } = await supabase.auth.getUser();
        if (!user) {
            return { success: false, error: 'User not authenticated' };
        }

        const { data, error } = await supabase
            .from('symptom_entries')
            .insert({
                ...symptom,
                user_id: user.id,
            })
            .select('id')
            .single();

        if (error) {
            return { success: false, error: error.message };
        }

        return { success: true, id: data?.id };
    } catch (err: any) {
        return { success: false, error: err.message };
    }
}

/**
 * Fetch symptom history from cloud
 */
export async function fetchSymptoms(days: number = 30): Promise<{ symptoms: CloudSymptomEntry[]; error?: string }> {
    if (!isSupabaseConfigured) {
        return { symptoms: [], error: 'Supabase not configured' };
    }

    try {
        const { data: { user } } = await supabase.auth.getUser();
        if (!user) {
            return { symptoms: [], error: 'User not authenticated' };
        }

        const since = new Date();
        since.setDate(since.getDate() - days);

        const { data, error } = await supabase
            .from('symptom_entries')
            .select('*')
            .eq('user_id', user.id)
            .gte('created_at', since.toISOString())
            .order('created_at', { ascending: false });

        if (error) {
            return { symptoms: [], error: error.message };
        }

        return { symptoms: data || [] };
    } catch (err: any) {
        return { symptoms: [], error: err.message };
    }
}

/**
 * Sync all local data to cloud (bulk sync)
 */
export async function syncAllToCloud(data: {
    profile?: Partial<CloudUserProfile>;
    assessments?: Omit<CloudAssessment, 'user_id'>[];
    symptoms?: Omit<CloudSymptomEntry, 'user_id'>[];
}): Promise<{ success: boolean; synced: { profiles: number; assessments: number; symptoms: number }; error?: string }> {
    if (!isSupabaseConfigured) {
        return {
            success: false,
            synced: { profiles: 0, assessments: 0, symptoms: 0 },
            error: 'Supabase not configured'
        };
    }

    const synced = { profiles: 0, assessments: 0, symptoms: 0 };

    try {
        // Sync profile
        if (data.profile) {
            const result = await syncProfile(data.profile);
            if (result.success) synced.profiles = 1;
        }

        // Sync assessments
        if (data.assessments) {
            for (const assessment of data.assessments) {
                const result = await syncAssessment(assessment);
                if (result.success) synced.assessments++;
            }
        }

        // Sync symptoms
        if (data.symptoms) {
            for (const symptom of data.symptoms) {
                const result = await syncSymptom(symptom);
                if (result.success) synced.symptoms++;
            }
        }

        return { success: true, synced };
    } catch (err: any) {
        return { success: false, synced, error: err.message };
    }
}

/**
 * Fetch all user data from cloud
 */
export async function fetchAllFromCloud(): Promise<{
    profile: CloudUserProfile | null;
    assessments: CloudAssessment[];
    symptoms: CloudSymptomEntry[];
    error?: string;
}> {
    const [profileResult, assessmentsResult, symptomsResult] = await Promise.all([
        fetchProfile(),
        fetchAssessments(),
        fetchSymptoms(),
    ]);

    return {
        profile: profileResult.profile,
        assessments: assessmentsResult.assessments,
        symptoms: symptomsResult.symptoms,
        error: profileResult.error || assessmentsResult.error || symptomsResult.error,
    };
}

/**
 * Check if cloud sync is available
 */
export function isCloudSyncAvailable(): boolean {
    return isSupabaseConfigured;
}

export default {
    syncProfile,
    fetchProfile,
    syncAssessment,
    fetchAssessments,
    syncSymptom,
    fetchSymptoms,
    syncAllToCloud,
    fetchAllFromCloud,
    isCloudSyncAvailable,
};
