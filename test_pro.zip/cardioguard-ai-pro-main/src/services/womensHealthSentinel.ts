/**
 * CardioGuard AI - Women's Health Sentinel Agent
 * © 2026 CardioGuard AI / TCH Medical
 * 
 * Specialized agent for detecting female-specific cardiovascular conditions
 * that are often misdiagnosed or present differently than in male patients.
 * 
 * Clinical Basis: Women experience CVD differently - atypical symptoms, 
 * sex-specific conditions (SCAD, Peripartum), and hormonal influences.
 */

import { VitalsData, AssessmentResult } from '../types';

// Female-specific cardiovascular conditions that mimic or differ from typical CVD
export const FEMALE_CVD_CONDITIONS = {
    SCAD: {
        name: "Spontaneous Coronary Artery Dissection (SCAD)",
        prevalence: "Accounts for ~25-35% of heart attacks in women under 50",
        mechanism: "Tear in coronary artery wall, often without traditional risk factors",
        symptoms: ["sudden chest pain", "arm pain", "shortness of breath", "extreme fatigue", "neck pain"],
        riskFactors: ["recent pregnancy", "hormonal therapy", "fibromuscular dysplasia", "extreme physical stress", "emotional stress"],
        ageGroup: "30-50",
        misdiagnosedAs: ["anxiety", "panic attack", "acid reflux", "muscle strain"],
        urgency: "CRITICAL"
    },
    PERIPARTUM_CARDIOMYOPATHY: {
        name: "Peripartum Cardiomyopathy (PPCM)",
        prevalence: "1 in 1,000-4,000 pregnancies",
        mechanism: "Heart muscle weakening during late pregnancy or postpartum",
        symptoms: ["swelling in legs/ankles", "shortness of breath", "fatigue", "rapid heartbeat", "cough when lying down"],
        riskFactors: ["multiple pregnancies", "age over 30", "preeclampsia history", "gestational hypertension", "african descent"],
        ageGroup: "Any pregnant/postpartum",
        misdiagnosedAs: ["normal pregnancy fatigue", "post-delivery exhaustion"],
        urgency: "HIGH"
    },
    TAKOTSUBO_STRESS: {
        name: "Takotsubo Cardiomyopathy (Broken Heart Syndrome)",
        prevalence: "90% of cases occur in women, typically post-menopausal",
        mechanism: "Stress-induced left ventricular dysfunction",
        symptoms: ["sudden chest pain", "shortness of breath", "arm weakness", "sweating", "nausea"],
        riskFactors: ["recent severe emotional stress", "sudden grief", "divorce", "job loss", "menopause"],
        ageGroup: "50+",
        misdiagnosedAs: ["acute MI", "anxiety attack"],
        urgency: "HIGH"
    },
    MVD: {
        name: "Microvascular Disease (Small Vessel Disease)",
        prevalence: "More common in women with diabetes",
        mechanism: "Damage to small coronary arteries, often invisible on angiogram",
        symptoms: ["persistent chest discomfort", "fatigue", "shortness of breath", "sleep disturbance"],
        riskFactors: ["diabetes", "hypertension", "obesity", "polycystic ovary syndrome", "autoimmune disorders"],
        ageGroup: "40+",
        misdiagnosedAs: ["fibromyalgia", "chronic fatigue", "anxiety"],
        urgency: "MODERATE"
    },
    PREECLAMPSIA_CVD_LINK: {
        name: "Preeclampsia-Related CVD Risk",
        prevalence: "Women with preeclampsia history have 2-4x higher CVD risk",
        mechanism: "Vascular dysfunction during pregnancy indicates underlying CVD susceptibility",
        symptoms: ["high blood pressure", "protein in urine (history)", "swelling", "headaches", "visual changes"],
        riskFactors: ["history of preeclampsia", "gestational diabetes", "early delivery"],
        ageGroup: "Post-pregnancy (lifelong risk)",
        misdiagnosedAs: ["normal aging", "stress-related hypertension"],
        urgency: "SURVEILLANCE"
    }
};

// Keywords that indicate female-specific CVD concerns
const FEMALE_CVD_KEYWORDS = [
    'pregnant', 'pregnancy', 'postpartum', 'after delivery', 'after giving birth',
    'menopause', 'post-menopausal', 'hormones', 'hormone therapy', 'hrt',
    'preeclampsia', 'gestational', 'period', 'menstrual',
    'extreme fatigue', 'anxiety', 'panic', 'emotional stress', 'grief',
    'swelling ankles', 'can\'t lie down', 'sleep issues'
];

/**
 * Women's Health Sentinel Agent
 * Analyzes female patient data for sex-specific cardiovascular conditions
 */
export class WomensHealthSentinel {
    private patientData: VitalsData;
    private symptoms: string[];
    private medicalHistory: string[];

    constructor(vitals: VitalsData, symptoms: string[] = [], history: string[] = []) {
        this.patientData = vitals;
        this.symptoms = symptoms;
        this.medicalHistory = history;
    }

    /**
     * Main triage analysis - called when patient is female
     */
    analyze(): WomensHealthAnalysis {
        const result: WomensHealthAnalysis = {
            isFemaleSentinelActive: true,
            detectedConditions: [],
            riskElevation: 0,
            recommendations: [],
            emergencyProtocolTriggered: false,
            agentNotes: []
        };

        // Check for each female-specific condition
        this.checkSCAD(result);
        this.checkPeripartumCardiomyopathy(result);
        this.checkTakotsubo(result);
        this.checkMicrovascularDisease(result);
        this.checkPreeclampsiaCVDLink(result);

        // Calculate overall risk elevation
        result.riskElevation = this.calculateRiskElevation(result.detectedConditions);

        // Determine if emergency protocol needed
        if (result.detectedConditions.some(c => c.urgency === 'CRITICAL')) {
            result.emergencyProtocolTriggered = true;
            result.recommendations.unshift("🚨 CRITICAL: Immediate cardiology consultation required. Do not delay.");
        }

        // Add agent processing notes
        result.agentNotes.push(`Women's Health Sentinel analyzed ${this.symptoms.length} symptoms`);
        result.agentNotes.push(`Age group: ${this.patientData.age} years`);
        result.agentNotes.push(`Conditions screened: ${Object.keys(FEMALE_CVD_CONDITIONS).length}`);

        return result;
    }

    private checkSCAD(result: WomensHealthAnalysis) {
        const condition = FEMALE_CVD_CONDITIONS.SCAD;
        const age = this.patientData.age;
        const symptoms = this.symptoms.map(s => s.toLowerCase());
        const history = this.medicalHistory.map(h => h.toLowerCase());

        // SCAD criteria: young to middle-aged women with sudden onset chest pain
        let matchScore = 0;

        if (age >= 30 && age <= 55) matchScore += 2;

        condition.symptoms.forEach(s => {
            if (symptoms.some(sym => sym.includes(s))) matchScore += 2;
        });

        condition.riskFactors.forEach(rf => {
            if (history.some(h => h.includes(rf)) || symptoms.some(s => s.includes(rf))) matchScore += 1.5;
        });

        if (matchScore >= 4) {
            result.detectedConditions.push({
                condition: condition.name,
                confidence: Math.min(matchScore * 12, 95),
                urgency: condition.urgency,
                action: "Urgent cardiology referral - request coronary angiography",
                clinicalNote: "SCAD often occurs in healthy women without traditional CVD risk factors"
            });
            result.recommendations.push("Cardiac imaging recommended - standard stress tests may miss SCAD");
        }
    }

    private checkPeripartumCardiomyopathy(result: WomensHealthAnalysis) {
        const condition = FEMALE_CVD_CONDITIONS.PERIPARTUM_CARDIOMYOPATHY;
        const symptoms = this.symptoms.map(s => s.toLowerCase());
        const history = this.medicalHistory.map(h => h.toLowerCase());
        const age = this.patientData.age;

        let matchScore = 0;

        // Check for pregnancy/postpartum indicators
        const pregnancyIndicators = ['pregnant', 'pregnancy', 'postpartum', 'after delivery', 'just had baby', 'weeks after birth'];
        if (history.some(h => pregnancyIndicators.some(p => h.includes(p))) ||
            symptoms.some(s => pregnancyIndicators.some(p => s.includes(p)))) {
            matchScore += 3;
        }

        if (age >= 25 && age <= 45) matchScore += 1;

        condition.symptoms.forEach(s => {
            if (symptoms.some(sym => sym.includes(s))) matchScore += 2;
        });

        if (matchScore >= 5) {
            result.detectedConditions.push({
                condition: condition.name,
                confidence: Math.min(matchScore * 10, 90),
                urgency: condition.urgency,
                action: "Immediate echocardiogram to assess left ventricular function",
                clinicalNote: "PPCM can present as 'normal pregnancy fatigue' - high index of suspicion needed"
            });
            result.recommendations.push("Echocardiogram and BNP test urgently needed");
        }
    }

    private checkTakotsubo(result: WomensHealthAnalysis) {
        const condition = FEMALE_CVD_CONDITIONS.TAKOTSUBO_STRESS;
        const symptoms = this.symptoms.map(s => s.toLowerCase());
        const history = this.medicalHistory.map(h => h.toLowerCase());
        const age = this.patientData.age;

        let matchScore = 0;

        // Post-menopausal women are the primary group
        if (age >= 50) matchScore += 2;

        // Check for emotional stress triggers
        const stressTriggers = ['grief', 'loss', 'death of', 'divorce', 'stress', 'emotional', 'traumatic'];
        if (history.some(h => stressTriggers.some(t => h.includes(t))) ||
            symptoms.some(s => stressTriggers.some(t => s.includes(t)))) {
            matchScore += 3;
        }

        condition.symptoms.forEach(s => {
            if (symptoms.some(sym => sym.includes(s))) matchScore += 1.5;
        });

        if (matchScore >= 4) {
            result.detectedConditions.push({
                condition: condition.name,
                confidence: Math.min(matchScore * 12, 88),
                urgency: condition.urgency,
                action: "Differentiate from acute MI - coronary angiography may show clean arteries",
                clinicalNote: "Takotsubo mimics MI but requires different management approach"
            });
            result.recommendations.push("Cardiac catheterization to rule out coronary occlusion");
        }
    }

    private checkMicrovascularDisease(result: WomensHealthAnalysis) {
        const condition = FEMALE_CVD_CONDITIONS.MVD;
        const symptoms = this.symptoms.map(s => s.toLowerCase());
        const age = this.patientData.age;

        let matchScore = 0;

        if (age >= 40) matchScore += 1;
        if (this.patientData.hasDiabetes) matchScore += 2;
        if (this.patientData.systolicBP >= 140) matchScore += 1;

        // Chronic nature of symptoms
        const chronicIndicators = ['persistent', 'ongoing', 'chronic', 'months', 'years', 'always tired'];
        if (symptoms.some(s => chronicIndicators.some(c => s.includes(c)))) matchScore += 1.5;

        condition.symptoms.forEach(s => {
            if (symptoms.some(sym => sym.includes(s))) matchScore += 1;
        });

        if (matchScore >= 4) {
            result.detectedConditions.push({
                condition: condition.name,
                confidence: Math.min(matchScore * 10, 75),
                urgency: condition.urgency,
                action: "Consider cardiac PET or MRI - standard angiography may appear normal",
                clinicalNote: "MVD is often invisible on standard tests - high index of suspicion in women"
            });
            result.recommendations.push("Advanced cardiac imaging recommended if standard tests negative");
        }
    }

    private checkPreeclampsiaCVDLink(result: WomensHealthAnalysis) {
        const history = this.medicalHistory.map(h => h.toLowerCase());
        const age = this.patientData.age;

        // Check for preeclampsia history
        const preeclampsia = history.some(h =>
            h.includes('preeclampsia') ||
            h.includes('pre-eclampsia') ||
            h.includes('toxemia') ||
            h.includes('pregnancy hypertension')
        );

        if (preeclampsia) {
            result.detectedConditions.push({
                condition: FEMALE_CVD_CONDITIONS.PREECLAMPSIA_CVD_LINK.name,
                confidence: 85,
                urgency: 'SURVEILLANCE',
                action: "Lifetime cardiovascular monitoring recommended",
                clinicalNote: "Preeclampsia history indicates 2-4x higher long-term CVD risk"
            });
            result.recommendations.push("Annual cardiovascular screening recommended");
            result.recommendations.push("Aggressive management of BP, cholesterol, and glucose");
        }
    }

    private calculateRiskElevation(conditions: DetectedCondition[]): number {
        if (conditions.length === 0) return 0;

        let elevation = 0;
        conditions.forEach(c => {
            if (c.urgency === 'CRITICAL') elevation += 25;
            else if (c.urgency === 'HIGH') elevation += 15;
            else if (c.urgency === 'MODERATE') elevation += 10;
            else if (c.urgency === 'SURVEILLANCE') elevation += 5;
        });

        return Math.min(elevation, 50); // Cap at 50% elevation
    }
}

// Types for the Women's Health Sentinel output
export interface DetectedCondition {
    condition: string;
    confidence: number;
    urgency: string;
    action: string;
    clinicalNote: string;
}

export interface WomensHealthAnalysis {
    isFemaleSentinelActive: boolean;
    detectedConditions: DetectedCondition[];
    riskElevation: number;
    recommendations: string[];
    emergencyProtocolTriggered: boolean;
    agentNotes: string[];
}

/**
 * Triage handover function - called by main assessment flow
 */
export const triageToWomensSentinel = (
    vitals: VitalsData,
    symptoms: string[],
    history: string[]
): WomensHealthAnalysis | null => {
    // Only activate for female patients
    if (vitals.gender !== 'female') {
        return null;
    }

    console.log("🩺 Triage System: Handover to Women's Health Sentinel Agent");
    const sentinel = new WomensHealthSentinel(vitals, symptoms, history);
    return sentinel.analyze();
};

/**
 * Emergency protocol trigger for critical female-specific conditions
 */
export const triggerFemaleEmergencyProtocol = (analysis: WomensHealthAnalysis): void => {
    if (analysis.emergencyProtocolTriggered) {
        console.log("🚨 WOMEN'S HEALTH EMERGENCY PROTOCOL ACTIVATED");
        console.log("Critical conditions detected:", analysis.detectedConditions.filter(c => c.urgency === 'CRITICAL'));
        // In production, this would trigger SMS/push notifications to emergency contacts
    }
};
