/**
 * CardioGuard AI - Wearable Connectivity Service
 * © 2026 CardioGuard AI / TCH Medical
 * 
 * Web Bluetooth API integration for connecting to medical-grade wearables
 * Supports: Heart rate monitors, BP monitors, SpO2 sensors, and fitness trackers
 */

// Web Bluetooth API Type Declarations (not yet in standard TS lib)
declare global {
    interface Navigator {
        bluetooth: Bluetooth;
    }

    interface Bluetooth {
        requestDevice(options: RequestDeviceOptions): Promise<BluetoothDevice>;
        getAvailability(): Promise<boolean>;
    }

    interface RequestDeviceOptions {
        filters?: BluetoothLEScanFilter[];
        optionalServices?: BluetoothServiceUUID[];
        acceptAllDevices?: boolean;
    }

    interface BluetoothLEScanFilter {
        services?: BluetoothServiceUUID[];
        name?: string;
        namePrefix?: string;
    }

    type BluetoothServiceUUID = number | string;
    type BluetoothCharacteristicUUID = number | string;

    interface BluetoothDevice extends EventTarget {
        id: string;
        name?: string;
        gatt?: BluetoothRemoteGATTServer;
        watchAdvertisements(): Promise<void>;
        unwatchAdvertisements(): void;
    }

    interface BluetoothRemoteGATTServer {
        device: BluetoothDevice;
        connected: boolean;
        connect(): Promise<BluetoothRemoteGATTServer>;
        disconnect(): void;
        getPrimaryService(service: BluetoothServiceUUID): Promise<BluetoothRemoteGATTService>;
        getPrimaryServices(service?: BluetoothServiceUUID): Promise<BluetoothRemoteGATTService[]>;
    }

    interface BluetoothRemoteGATTService {
        device: BluetoothDevice;
        uuid: string;
        isPrimary: boolean;
        getCharacteristic(characteristic: BluetoothCharacteristicUUID): Promise<BluetoothRemoteGATTCharacteristic>;
        getCharacteristics(characteristic?: BluetoothCharacteristicUUID): Promise<BluetoothRemoteGATTCharacteristic[]>;
    }

    interface BluetoothRemoteGATTCharacteristic extends EventTarget {
        service: BluetoothRemoteGATTService;
        uuid: string;
        properties: BluetoothCharacteristicProperties;
        value?: DataView;
        readValue(): Promise<DataView>;
        writeValue(value: BufferSource): Promise<void>;
        writeValueWithResponse(value: BufferSource): Promise<void>;
        writeValueWithoutResponse(value: BufferSource): Promise<void>;
        startNotifications(): Promise<BluetoothRemoteGATTCharacteristic>;
        stopNotifications(): Promise<BluetoothRemoteGATTCharacteristic>;
    }

    interface BluetoothCharacteristicProperties {
        broadcast: boolean;
        read: boolean;
        writeWithoutResponse: boolean;
        write: boolean;
        notify: boolean;
        indicate: boolean;
        authenticatedSignedWrites: boolean;
        reliableWrite: boolean;
        writableAuxiliaries: boolean;
    }
}

// Bluetooth GATT Service UUIDs (Standard Health Device Profiles)
export const BLE_SERVICES = {
    HEART_RATE: '0000180d-0000-1000-8000-00805f9b34fb',
    BLOOD_PRESSURE: '00001810-0000-1000-8000-00805f9b34fb',
    HEALTH_THERMOMETER: '00001809-0000-1000-8000-00805f9b34fb',
    PULSE_OXIMETER: '00001822-0000-1000-8000-00805f9b34fb',
    BATTERY: '0000180f-0000-1000-8000-00805f9b34fb',
    DEVICE_INFO: '0000180a-0000-1000-8000-00805f9b34fb'
};

// Characteristic UUIDs
export const BLE_CHARACTERISTICS = {
    HEART_RATE_MEASUREMENT: '00002a37-0000-1000-8000-00805f9b34fb',
    BLOOD_PRESSURE_MEASUREMENT: '00002a35-0000-1000-8000-00805f9b34fb',
    TEMPERATURE_MEASUREMENT: '00002a1c-0000-1000-8000-00805f9b34fb',
    SPO2_MEASUREMENT: '00002a5f-0000-1000-8000-00805f9b34fb',
    BATTERY_LEVEL: '00002a19-0000-1000-8000-00805f9b34fb'
};

// Supported wearable device profiles
export const DEVICE_PROFILES = {
    POLAR_H10: { name: 'Polar H10', services: ['HEART_RATE'], type: 'chest_strap' },
    POLAR_VERITY: { name: 'Polar Verity Sense', services: ['HEART_RATE', 'PULSE_OXIMETER'], type: 'arm_band' },
    APPLE_WATCH: { name: 'Apple Watch', services: ['HEART_RATE'], type: 'smartwatch' },
    SAMSUNG_GALAXY_WATCH: { name: 'Galaxy Watch', services: ['HEART_RATE'], type: 'smartwatch' },
    FITBIT: { name: 'Fitbit', services: ['HEART_RATE'], type: 'fitness_band' },
    OMRON_BP: { name: 'Omron BP Monitor', services: ['BLOOD_PRESSURE'], type: 'bp_monitor' },
    WITHINGS_BP: { name: 'Withings BPM', services: ['BLOOD_PRESSURE'], type: 'bp_monitor' },
    GENERIC_HRM: { name: 'Generic Heart Rate Monitor', services: ['HEART_RATE'], type: 'hrm' }
};

export interface WearableDevice {
    id: string;
    name: string;
    type: string;
    connected: boolean;
    batteryLevel?: number;
    lastSync?: number;
    device?: BluetoothDevice;
    server?: BluetoothRemoteGATTServer;
}

export interface VitalsReading {
    timestamp: number;
    heartRate?: number;
    systolicBP?: number;
    diastolicBP?: number;
    spo2?: number;
    temperature?: number;
    source: string;
}

type VitalsCallback = (reading: VitalsReading) => void;
type ConnectionCallback = (device: WearableDevice) => void;
type ErrorCallback = (error: string) => void;

class WearableConnectivityService {
    private devices: Map<string, WearableDevice> = new Map();
    private vitalsListeners: Set<VitalsCallback> = new Set();
    private connectionListeners: Set<ConnectionCallback> = new Set();
    private errorListeners: Set<ErrorCallback> = new Set();
    private isSupported: boolean;

    constructor() {
        this.isSupported = typeof navigator !== 'undefined' && 'bluetooth' in navigator;
        if (!this.isSupported) {
            console.warn('⚠️ Web Bluetooth API not supported in this browser');
        }
    }

    // Check if Bluetooth is supported
    isBluetoothSupported(): boolean {
        return this.isSupported;
    }

    // Request connection to a heart rate monitor
    async connectHeartRateMonitor(): Promise<WearableDevice | null> {
        return this.connectDevice([BLE_SERVICES.HEART_RATE], 'Heart Rate Monitor');
    }

    // Request connection to a blood pressure monitor
    async connectBloodPressureMonitor(): Promise<WearableDevice | null> {
        return this.connectDevice([BLE_SERVICES.BLOOD_PRESSURE], 'Blood Pressure Monitor');
    }

    // Request connection to a pulse oximeter
    async connectPulseOximeter(): Promise<WearableDevice | null> {
        return this.connectDevice([BLE_SERVICES.PULSE_OXIMETER], 'Pulse Oximeter');
    }

    // Generic device connection
    async connectDevice(services: string[], deviceType: string): Promise<WearableDevice | null> {
        if (!this.isSupported) {
            this.notifyError('Web Bluetooth is not supported in this browser. Please use Chrome, Edge, or Opera.');
            return null;
        }

        try {
            console.log(`🔍 Scanning for ${deviceType}...`);

            const device = await navigator.bluetooth.requestDevice({
                filters: services.map(service => ({ services: [service] })),
                optionalServices: [BLE_SERVICES.BATTERY, BLE_SERVICES.DEVICE_INFO]
            });

            if (!device) {
                throw new Error('No device selected');
            }

            console.log(`📱 Connecting to ${device.name}...`);

            const server = await device.gatt?.connect();
            if (!server) {
                throw new Error('Failed to connect to GATT server');
            }

            const wearableDevice: WearableDevice = {
                id: device.id,
                name: device.name || 'Unknown Device',
                type: deviceType,
                connected: true,
                lastSync: Date.now(),
                device,
                server
            };

            // Get battery level if available
            try {
                const batteryService = await server.getPrimaryService(BLE_SERVICES.BATTERY);
                const batteryChar = await batteryService.getCharacteristic(BLE_CHARACTERISTICS.BATTERY_LEVEL);
                const batteryValue = await batteryChar.readValue();
                wearableDevice.batteryLevel = batteryValue.getUint8(0);
            } catch (e) {
                console.log('Battery level not available');
            }

            // Store device
            this.devices.set(device.id, wearableDevice);

            // Set up disconnect handler
            device.addEventListener('gattserverdisconnected', () => {
                this.handleDisconnection(device.id);
            });

            // Start listening for data based on device type
            await this.startListening(wearableDevice, services);

            // Notify listeners
            this.notifyConnection(wearableDevice);

            console.log(`✅ Connected to ${device.name}`);
            return wearableDevice;

        } catch (error: any) {
            console.error('Connection error:', error);
            if (error.message.includes('User cancelled')) {
                this.notifyError('Device selection cancelled');
            } else {
                this.notifyError(`Failed to connect: ${error.message}`);
            }
            return null;
        }
    }

    // Start listening for vitals data
    private async startListening(device: WearableDevice, services: string[]): Promise<void> {
        if (!device.server) return;

        for (const serviceUUID of services) {
            try {
                const service = await device.server.getPrimaryService(serviceUUID);

                if (serviceUUID === BLE_SERVICES.HEART_RATE) {
                    const characteristic = await service.getCharacteristic(BLE_CHARACTERISTICS.HEART_RATE_MEASUREMENT);
                    await characteristic.startNotifications();
                    characteristic.addEventListener('characteristicvaluechanged', (event: Event) => {
                        const value = (event.target as BluetoothRemoteGATTCharacteristic).value;
                        if (value) {
                            const heartRate = this.parseHeartRate(value);
                            this.notifyVitals({
                                timestamp: Date.now(),
                                heartRate,
                                source: device.name
                            });
                        }
                    });
                    console.log('💓 Heart rate monitoring started');
                }

                if (serviceUUID === BLE_SERVICES.BLOOD_PRESSURE) {
                    const characteristic = await service.getCharacteristic(BLE_CHARACTERISTICS.BLOOD_PRESSURE_MEASUREMENT);
                    await characteristic.startNotifications();
                    characteristic.addEventListener('characteristicvaluechanged', (event: Event) => {
                        const value = (event.target as BluetoothRemoteGATTCharacteristic).value;
                        if (value) {
                            const bp = this.parseBloodPressure(value);
                            this.notifyVitals({
                                timestamp: Date.now(),
                                systolicBP: bp.systolic,
                                diastolicBP: bp.diastolic,
                                source: device.name
                            });
                        }
                    });
                    console.log('🩺 Blood pressure monitoring started');
                }

                if (serviceUUID === BLE_SERVICES.PULSE_OXIMETER) {
                    const characteristic = await service.getCharacteristic(BLE_CHARACTERISTICS.SPO2_MEASUREMENT);
                    await characteristic.startNotifications();
                    characteristic.addEventListener('characteristicvaluechanged', (event: Event) => {
                        const value = (event.target as BluetoothRemoteGATTCharacteristic).value;
                        if (value) {
                            const spo2 = this.parseSpO2(value);
                            this.notifyVitals({
                                timestamp: Date.now(),
                                spo2,
                                source: device.name
                            });
                        }
                    });
                    console.log('💨 SpO2 monitoring started');
                }

            } catch (e) {
                console.warn(`Service ${serviceUUID} not available:`, e);
            }
        }
    }

    // Parse heart rate from Bluetooth data
    private parseHeartRate(value: DataView): number {
        const flags = value.getUint8(0);
        const rate16Bits = (flags & 0x01) !== 0;

        if (rate16Bits) {
            return value.getUint16(1, true);
        }
        return value.getUint8(1);
    }

    // Parse blood pressure from Bluetooth data
    private parseBloodPressure(value: DataView): { systolic: number; diastolic: number } {
        // IEEE 11073 float format parsing
        const systolic = value.getUint16(1, true);
        const diastolic = value.getUint16(3, true);
        return { systolic, diastolic };
    }

    // Parse SpO2 from Bluetooth data
    private parseSpO2(value: DataView): number {
        return value.getUint8(1);
    }

    // Handle device disconnection
    private handleDisconnection(deviceId: string): void {
        const device = this.devices.get(deviceId);
        if (device) {
            device.connected = false;
            this.notifyConnection(device);
            console.log(`📴 ${device.name} disconnected`);
        }
    }

    // Disconnect a device
    async disconnectDevice(deviceId: string): Promise<void> {
        const device = this.devices.get(deviceId);
        if (device?.device?.gatt?.connected) {
            device.device.gatt.disconnect();
        }
        this.devices.delete(deviceId);
    }

    // Disconnect all devices
    async disconnectAll(): Promise<void> {
        for (const [id] of this.devices) {
            await this.disconnectDevice(id);
        }
    }

    // Get connected devices
    getConnectedDevices(): WearableDevice[] {
        return Array.from(this.devices.values()).filter(d => d.connected);
    }

    // Subscribe to vitals updates
    onVitals(callback: VitalsCallback): () => void {
        this.vitalsListeners.add(callback);
        return () => this.vitalsListeners.delete(callback);
    }

    // Subscribe to connection updates
    onConnection(callback: ConnectionCallback): () => void {
        this.connectionListeners.add(callback);
        return () => this.connectionListeners.delete(callback);
    }

    // Subscribe to errors
    onError(callback: ErrorCallback): () => void {
        this.errorListeners.add(callback);
        return () => this.errorListeners.delete(callback);
    }

    // Notify vitals listeners
    private notifyVitals(reading: VitalsReading): void {
        this.vitalsListeners.forEach(cb => cb(reading));
    }

    // Notify connection listeners
    private notifyConnection(device: WearableDevice): void {
        this.connectionListeners.forEach(cb => cb(device));
    }

    // Notify error listeners
    private notifyError(error: string): void {
        this.errorListeners.forEach(cb => cb(error));
    }

    // Simulate wearable data (for demo/testing purposes)
    startSimulation(): () => void {
        console.log('🔄 Starting wearable simulation mode...');

        const interval = setInterval(() => {
            // Simulate heart rate with realistic variation
            const baseHR = 72;
            const variation = Math.sin(Date.now() / 5000) * 8;
            const noise = (Math.random() - 0.5) * 4;

            this.notifyVitals({
                timestamp: Date.now(),
                heartRate: Math.round(baseHR + variation + noise),
                spo2: 97 + Math.floor(Math.random() * 3),
                source: 'Simulated Wearable'
            });
        }, 1000);

        return () => {
            clearInterval(interval);
            console.log('⏹️ Wearable simulation stopped');
        };
    }
}

// Singleton instance
const wearableService = new WearableConnectivityService();

// Export convenience functions
export const isBluetoothSupported = () => wearableService.isBluetoothSupported();
export const connectHeartRateMonitor = () => wearableService.connectHeartRateMonitor();
export const connectBloodPressureMonitor = () => wearableService.connectBloodPressureMonitor();
export const connectPulseOximeter = () => wearableService.connectPulseOximeter();
export const getConnectedDevices = () => wearableService.getConnectedDevices();
export const disconnectDevice = (id: string) => wearableService.disconnectDevice(id);
export const disconnectAll = () => wearableService.disconnectAll();
export const onVitalsUpdate = (cb: VitalsCallback) => wearableService.onVitals(cb);
export const onDeviceConnection = (cb: ConnectionCallback) => wearableService.onConnection(cb);
export const onWearableError = (cb: ErrorCallback) => wearableService.onError(cb);
export const startWearableSimulation = () => wearableService.startSimulation();

export default wearableService;
