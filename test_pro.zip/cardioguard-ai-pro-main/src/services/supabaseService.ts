
/**
 * CardioGuard AI - Unified Supabase Service
 * 
 * This is the "Superior Version" of the Supabase service, consolidating
 * client initialization, authentication settings, and clinical data functions.
 */

import { createClient } from '@supabase/supabase-js';
import { MedicalDocument, AccessGrant, Doctor } from '../types';

// Supabase project credentials
const SUPABASE_URL = import.meta.env.VITE_SUPABASE_URL || 'YOUR_SUPABASE_URL';
const SUPABASE_ANON_KEY = import.meta.env.VITE_SUPABASE_ANON_KEY || 'YOUR_SUPABASE_ANON_KEY';

// Initialize the "Superior" Client with optimized auth persistence
export const supabase = createClient(SUPABASE_URL, SUPABASE_ANON_KEY, {
    auth: {
        autoRefreshToken: true,
        persistSession: true,
        detectSessionInUrl: true,
        storage: localStorage,
    },
});

// Export configuration status for high-level safety checks
export const isSupabaseConfigured =
    SUPABASE_URL !== 'YOUR_SUPABASE_URL' &&
    SUPABASE_ANON_KEY !== 'YOUR_SUPABASE_ANON_KEY';

// --- Clinical Data & Medical Documents ---

/** Uploads medical imaging files to clinical storage buckets */
export const uploadMedicalDocument = async (file: File, patientId: string): Promise<string | null> => {
    try {
        const fileExt = file.name.split('.').pop();
        const fileName = `${patientId}/${Date.now()}.${fileExt}`;
        const filePath = `${fileName}`;

        const { error: uploadError } = await supabase.storage
            .from('medical-imaging')
            .upload(filePath, file);

        if (uploadError) throw uploadError;
        return filePath;
    } catch (error) {
        console.error('Clinical Upload Error:', error);
        return null;
    }
};

/** Creates a persistent database record for analyzed medical findings */
export const createDocumentRecord = async (doc: Omit<MedicalDocument, 'id'>, patientId: string) => {
    const { data, error } = await supabase
        .from('medical_documents')
        .insert([
            {
                patient_id: patientId,
                file_name: doc.fileName,
                file_type: doc.type,
                storage_path: (doc as any).storagePath,
                analysis_summary: doc.analysis?.summary,
                criticality_score: doc.analysis?.criticality
            }
        ])
        .select()
        .single();

    if (error) {
        console.error('Data Integrity Error (Document):', error);
        throw error;
    }
    return data;
};

/** Retrieves all clinical documents for a specific patient context */
export const getPatientDocuments = async (patientId: string) => {
    const { data, error } = await supabase
        .from('medical_documents')
        .select('*')
        .eq('patient_id', patientId)
        .order('created_at', { ascending: false });

    if (error) {
        console.error('Data Fetch Error (Clinical History):', error);
        return [];
    }
    return data;
};

// --- Secure Access & Emergency Grants ---

/** Generates a high-security emergency access token for physicians */
export const createEmergencyAccess = async (patientId: string): Promise<AccessGrant | null> => {
    const token = crypto.randomUUID().split('-')[0].toUpperCase();
    const expiresAt = new Date(Date.now() + 24 * 60 * 60 * 1000);

    const { data, error } = await supabase
        .from('access_grants')
        .insert([
            {
                patient_id: patientId,
                token: token,
                access_type: 'EMERGENCY',
                expires_at: expiresAt.toISOString()
            }
        ])
        .select()
        .single();

    if (error) {
        console.error('Security Protocol Error (Access Grant):', error);
        return null;
    }

    return {
        id: data.id,
        patientId: data.patient_id,
        token: data.token,
        accessType: data.access_type,
        expiresAt: new Date(data.expires_at).getTime()
    };
};

/** Verifies physician tokens against active clinical security sessions */
export const verifyAccessToken = async (token: string) => {
    const { data, error } = await supabase
        .from('access_grants')
        .select('*, patient:patient_id(*)')
        .eq('token', token)
        .gt('expires_at', new Date().toISOString())
        .single();

    if (error || !data) return null;
    return data;
};

// --- Physician Profile Management ---

/** Retrieves verified physician credentials for the Doctor Dashboard */
export const getDoctorProfile = async (doctorId: string) => {
    const { data, error } = await supabase
        .from('doctors')
        .select('*')
        .eq('id', doctorId)
        .single();

    if (error) return null;
    return data;
};

// --- Vitals & Assessments ---

/** Saves a heart risk assessment and its associated vitals */
export const saveAssessment = async (assessment: any, vitalsInput: any, patientId: string) => {
    // 1. Log the vitals first
    const { data: vitalsData, error: vitalsError } = await supabase
        .from('vitals')
        .insert([
            {
                patient_id: patientId,
                systolic_bp: vitalsInput.systolicBP,
                diastolic_bp: vitalsInput.diastolicBP,
                heart_rate: vitalsInput.heartRate,
                spo2: vitalsInput.spO2,
                hrv: vitalsInput.hrv,
                blood_sugar: vitalsInput.bloodSugar,
                is_smoker: vitalsInput.isSmoker === 'Yes',
                has_diabetes: vitalsInput.hasDiabetes === 'Yes'
            }
        ])
        .select()
        .single();

    if (vitalsError) throw vitalsError;

    // 2. Log the risk assessment referencing the vitals node
    const { data, error } = await supabase
        .from('risk_assessments')
        .insert([
            {
                patient_id: patientId,
                vitals_id: vitalsData.id,
                risk_score: assessment.riskScore,
                risk_level: assessment.riskCategory,
                summary: assessment.summary,
                recommendations: assessment.recommendations,
                timeline: assessment.timeline,
                created_at: new Date().toISOString()
            }
        ])
        .select()
        .single();

    if (error) {
        console.error('Save Assessment Error:', error);
        throw error;
    }
    return data;
};

/** Retrieves assessment history for a patient */
export const getAssessmentHistory = async (patientId: string) => {
    const { data, error } = await supabase
        .from('risk_assessments')
        .select('*, vitals:vitals_id(*)')
        .eq('patient_id', patientId)
        .order('created_at', { ascending: false });

    if (error) {
        console.error('Fetch Assessment History Error:', error);
        return [];
    }
    return data;
};

// --- Aggregate Analytics ---

/** Retrieves regional health statistics (using RPC or fallback to View) */
export const getDistrictStats = async () => {
    const { data, error } = await supabase
        .from('district_stats_view')
        .select('*');

    if (error) {
        // Fallback for demo/dev environments without the view
        console.warn('District Stats View missing, using simulated data path');
        return null;
    }
    return data;
};

// --- Sensor Scans ---

/** Logs a raw optical PPG scan or biosensor capture */
export const savePPGScan = async (patientId: string, bpm: number, rawDataUrl?: string) => {
    const { data, error } = await supabase
        .from('scans')
        .insert([
            {
                patient_id: patientId,
                scan_type: 'PPG',
                result_value: bpm,
                raw_data_url: rawDataUrl
            }
        ])
        .select()
        .single();

    if (error) {
        console.error('Sensor Log Error:', error);
        return null;
    }
    return data;
};

// --- Emergency Response ---

/** Logs a critical SOS event to the backend dispatch system */
export const triggerSOS = async (patientId: string, location: { lat: number; lng: number }, context: string) => {
    const { data, error } = await supabase
        .from('emergency_alerts')
        .insert([
            {
                patient_id: patientId,
                latitude: location.lat,
                longitude: location.lng,
                context_data: context,
                status: 'DISPATCHED',
                created_at: new Date().toISOString()
            }
        ])
        .select()
        .single();

    if (error) {
        console.error('SOS Log Failure:', error);
        // We do typically NOT throw here so the UI can still proceed to 911
        return null;
    }
    return data;
};

export default supabase;
