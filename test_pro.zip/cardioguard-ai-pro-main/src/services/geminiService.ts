import { GoogleGenAI, Type } from "@google/genai";
import { VitalsData, AssessmentResult, MedicalDocument, SupportedLanguage } from "../types";
import { triageToWomensSentinel, triggerFemaleEmergencyProtocol, WomensHealthAnalysis } from "./womensHealthSentinel";
import { getEvidenceBasedRiskAnalysis } from "./researchService";
import { calculateFraminghamRisk, calculateXGBoostScore, detectRapidEscalation } from "../utils/riskCalculators";
import { predictRiskVector } from "./backendService";

const apiKey = import.meta.env.VITE_GEMINI_API_KEY || '';
if (!apiKey) console.error("Missing Gemini API Key: check .env VITE_GEMINI_API_KEY");
const ai = new GoogleGenAI({ apiKey });

export const assessHeartRisk = async (vitals: VitalsData, language: SupportedLanguage = 'English', symptoms: string[] = [], medicalHistory: string[] = []): Promise<AssessmentResult> => {

  // 1. DATA PULL & FAST-TRIAGE
  const framinghamResult = calculateFraminghamRisk(vitals);
  const xgboostScore = calculateXGBoostScore(vitals);
  const scientificEvidence = getEvidenceBasedRiskAnalysis(vitals);
  const escalationTriage = detectRapidEscalation(vitals, symptoms);

  // 1.5. REMOTE ML INFERENCE (FastAPI)
  const remotePrediction = await predictRiskVector(vitals, symptoms);
  const backendContext = remotePrediction.success ?
    `FASTAPI XGBOOST VECTOR: Score=${remotePrediction.data?.riskScore}%, Category=${remotePrediction.data?.riskCategory}, MACE_Window=${remotePrediction.data?.mace_window}, Algorithm=${remotePrediction.data?.algorithm}` :
    `FASTAPI_OFFLINE: Falling back to local XGBoost approximation.`;

  // TRIAGE STEP: Check if patient is female and needs specialized analysis
  let womensHealthAnalysis: WomensHealthAnalysis | null = null;
  if (vitals.gender === 'female') {
    womensHealthAnalysis = triageToWomensSentinel(vitals, symptoms, medicalHistory);
    if (womensHealthAnalysis?.emergencyProtocolTriggered) {
      triggerFemaleEmergencyProtocol(womensHealthAnalysis);
    }
  }

  const escalationContext = `
    BIO-FORENSIC ESCALATION STATUS:
    - Urgency Level: ${escalationTriage.level}
    - Trigger SOS: ${escalationTriage.triggerSOS ? 'YES - IMMEDIATE ACTION' : 'NO'}
    - Triage Notes: ${escalationTriage.notes.join('; ')}
  `;

  const scientificContext = `
    LIVE SCIENTIFIC CONTEXT (PULLED FROM PUBMED/CLINICAL GUIDELINES):
    - Framingham Risk Score (ATP III Baseline): ${framinghamResult.score} pts, ${framinghamResult.riskPercent}% 10-year risk.
    - XGBoost ML Projection (Non-linear ensemble): ${xgboostScore}% probability of acute/present CVD.
    - Insight: XGBoost captures interactions (e.g. Smoker+Age+HRV) that Framingham misses.
    - Citations: ${scientificEvidence.citations.slice(0, 3).join('; ')}.
  `;

  const prompt = `
    You are the CardioGuard AI Ensemble. Synthesize multiple models into a FINAL clinical assessment.
    
    INPUT DATA:
    - Patient: ${vitals.age}y ${vitals.gender}, ${vitals.heightCm}cm/${vitals.weightKg}kg.
    - Hemodynamics: BP ${vitals.systolicBP}/${vitals.diastolicBP}, HR ${vitals.heartRate} bpm.
    - Bio-Signals: HRV ${vitals.hrv}ms, SpO2 ${vitals.spO2}%.
    ${symptoms.length > 0 ? `- Symptoms: ${symptoms.join(', ')}` : ''}

    ${scientificContext}
    ${backendContext}
    ${escalationContext}
    ${womensHealthAnalysis ? 'WOMENS_HEALTH_GUARD: Priority Active.' : ''}

    ENSEMBLE INSTRUCTIONS:
    1. PRIORITIZE XGBoost (${xgboostScore}%) over Framingham (${framinghamResult.riskPercent}%) for current risk, as it handles non-linear synergistic factors.
    2. If ESCALATION STATUS is CRITICAL, the summary MUST start with "EMERGENCY ALERT" and direct the user to trigger SOS.
    3. CLINICAL TIMELINE: Predict *how and when* the user will likely feel symptoms if no intervention occurs (e.g. 'Symptoms likely in 12-24 hours', 'Stable for 5+ years').
    4. HIGHLIGHT XGBOOST: In the "Key Factors", explicitly mention if XGBoost detected a synergistic interaction.
    5. LANGUAGE: Provide all output in ${language}.
    
    Return JSON matching the AssessmentResult schema.
  `;

  const response = await ai.models.generateContent({
    model: 'gemini-pro',
    contents: [{ role: 'user', parts: [{ text: prompt }] }],
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          riskScore: { type: Type.NUMBER },
          riskCategory: { type: Type.STRING },
          summary: { type: Type.STRING },
          consistencyScore: { type: Type.NUMBER, description: "0-100 truthfulness/consistency score" },
          consistencyAlert: { type: Type.STRING, description: "Warning if data looks fake or suspicious" },
          keyFactors: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                factor: { type: Type.STRING },
                impact: { type: Type.STRING },
                description: { type: Type.STRING }
              },
              required: ["factor", "impact", "description"]
            }
          },
          recommendations: { type: Type.ARRAY, items: { type: Type.STRING } },
          disclaimer: { type: Type.STRING },
          timeline: {
            type: Type.OBJECT,
            properties: {
              expectedOnsetHours: { type: Type.STRING },
              severityProgression: { type: Type.STRING, enum: ['Stable', 'Slow', 'Rapid', 'Acute'] },
              clinicalMilestones: { type: Type.ARRAY, items: { type: Type.STRING } }
            },
            required: ["expectedOnsetHours", "severityProgression", "clinicalMilestones"]
          }
        },
        required: ["riskScore", "riskCategory", "summary", "consistencyScore", "keyFactors", "recommendations", "disclaimer", "timeline"]
      }
    }
  });

  const result = JSON.parse(response.text || '{}') as AssessmentResult;

  // Merge Women's Health Sentinel recommendations if applicable
  if (womensHealthAnalysis && womensHealthAnalysis.detectedConditions.length > 0) {
    // Elevate risk score based on sentinel findings
    result.riskScore = Math.min(result.riskScore + womensHealthAnalysis.riskElevation, 100);

    // Add sentinel recommendations
    result.recommendations = [
      ...womensHealthAnalysis.recommendations,
      ...result.recommendations
    ];

    // Add female-specific key factors
    womensHealthAnalysis.detectedConditions.forEach(condition => {
      result.keyFactors.unshift({
        factor: `🩺 ${condition.condition}`,
        impact: 'negative',
        description: `${condition.clinicalNote} (Confidence: ${condition.confidence}%)`
      });
    });

    // Update risk category if elevated
    if (womensHealthAnalysis.emergencyProtocolTriggered) {
      result.riskCategory = 'Very High';
    } else if (womensHealthAnalysis.riskElevation >= 15 && result.riskCategory === 'Low') {
      result.riskCategory = 'Moderate';
    } else if (womensHealthAnalysis.riskElevation >= 20 && result.riskCategory === 'Moderate') {
      result.riskCategory = 'High';
    }
  }

  return result;
};


export const analyzeMedicalDocument = async (doc: MedicalDocument, language: SupportedLanguage = 'English'): Promise<MedicalDocument['analysis']> => {
  if (!doc.base64Data) throw new Error("No data found");

  const response = await ai.models.generateContent({
    model: 'gemini-pro',
    contents: [
      {
        role: 'user',
        parts: [
          { inlineData: { mimeType: 'image/jpeg', data: doc.base64Data } },
          {
            text: `Analyze this ${doc.type}. Develop a 'Theory of Criticality'. 
          1. Provide a technical summary for a Doctor in ${language}.
          2. List 3-5 critical pointers in ${language}.
          3. Rate criticality 0-100.
          4. Is it urgent? (True/False). 
          Return JSON format.` }
        ]
      }
    ],
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          criticality: { type: Type.NUMBER },
          summary: { type: Type.STRING },
          pointers: { type: Type.ARRAY, items: { type: Type.STRING } },
          isUrgent: { type: Type.BOOLEAN }
        },
        required: ["criticality", "summary", "pointers", "isUrgent"]
      }
    }
  });

  return JSON.parse(response.text || '{}');
};

export const predictHealthCycle = async (history: any[], vitals: VitalsData, language: SupportedLanguage = 'English'): Promise<{
  trajectory: { month: string; risk: number; status: string }[];
  cycleAnalysis: string;
  preventiveBenchmarks: string[];
}> => {
  const prompt = `
    Analyze this patient's cardiovascular health history and current vitals to predict their health cycle for the next 12 months.
    
    PATIENT HISTORY (Last Assessment):
    ${history.length > 0 ? JSON.stringify(history[history.length - 1]) : 'No previous history'}
    
    CURRENT VITALS:
    ${JSON.stringify(vitals)}
    
    TASKS:
    1. Generate a 12-month trajectory of 'Risk Probability' (0-100).
    2. Provide a 'Cycle Analysis' summary in ${language}.
    3. Suggest 'Preventive Benchmarks' (actions to keep risk low).
    
    Return JSON format.
  `;

  const response = await ai.models.generateContent({
    model: 'gemini-pro',
    contents: [{ role: 'user', parts: [{ text: prompt }] }],
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          trajectory: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                month: { type: Type.STRING },
                risk: { type: Type.NUMBER },
                status: { type: Type.STRING }
              }
            }
          },
          cycleAnalysis: { type: Type.STRING },
          preventiveBenchmarks: { type: Type.ARRAY, items: { type: Type.STRING } }
        },
        required: ["trajectory", "cycleAnalysis", "preventiveBenchmarks"]
      }
    }
  });

  return JSON.parse(response.text || '{}');
};

export const getConciergeResponse = async (
  message: string,
  profile: any = null,
  recentRisk: any = null,
  history: { role: 'user' | 'model'; content: string }[] = []
): Promise<string> => {
  // 1. Try Backend First (Render/Production)
  try {
    const backendUrl = import.meta.env.VITE_BACKEND_URL || 'http://localhost:8000';
    const response = await fetch(`${backendUrl}/api/gemini-chat`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        message,
        history,
        profile,
        recent_risk: recentRisk
      })
    });

    if (response.ok) {
      const data = await response.json();
      return data.response;
    }
  } catch (backendError) {
    console.warn("Backend chat unavailable, falling back to client-side AI.");
  }

  // 2. Client-side Fallback (Using local API key)
  const systemPrompt = `
    You are a helpful, professional cardiovascular health assistant for CardioGuard AI.
    Your role is preventive guidance ONLY:
    - Use evidence-based advice from AHA/ESC guidelines.
    - Never diagnose, prescribe, or give medical advice.
    - If question is non-health related or urgent, say: "I'm focused on preventive heart health. For emergencies, call local services. For medical concerns, consult a doctor."
    - Be concise, empathetic, actionable.
    - Reference user data if provided to personalize prevention tips.
    - Always end with: "This is not medical advice – see a healthcare professional."

    User profile: ${JSON.stringify(profile || 'Not provided')}
    Recent risk: ${JSON.stringify(recentRisk || 'Not provided')}
  `;

  try {
    const contents = [
      { role: 'user', parts: [{ text: systemPrompt }] },
      { role: 'model', parts: [{ text: "Understood. I will provide preventive cardiovascular guidance using AHA/ESC guidelines, maintaining strict clinical boundaries and ending with the required medical advice disclaimer." }] },
      ...history.map(h => ({ role: h.role === 'user' ? 'user' : 'model', parts: [{ text: h.content }] })),
      { role: 'user', parts: [{ text: message }] }
    ];

    const modelResponse = await ai.models.generateContent({
      model: 'gemini-1.5-flash',
      contents: contents as any
    });

    return modelResponse.text || "I'm sorry, I couldn't process that request.";
  } catch (error) {
    console.error("Concierge Error:", error);
    return "I'm currently experiencing a connection issue with my medical knowledge base. Please try again in a moment.";
  }
};
