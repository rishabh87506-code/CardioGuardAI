/**
 * CardioGuard AI - Symptom Memory & Validation Service
 * © 2026 CardioGuard AI / TCH Medical
 * 
 * Remembers patient symptom history and validates symptom progression
 * Alerts when symptoms worsen or new concerning patterns emerge
 */

const MEMORY_KEY = 'cardioguard_symptom_memory_v1';
const USER_PROFILE_KEY = 'cardioguard_user_profile_v1';

// Symptom severity levels
export enum SymptomSeverity {
    NONE = 0,
    MILD = 1,
    MODERATE = 2,
    SEVERE = 3,
    CRITICAL = 4
}

// Symptom categories for tracking
export const SYMPTOM_CATEGORIES = {
    CHEST: ['chest pain', 'chest pressure', 'chest tightness', 'burning sensation'],
    RESPIRATORY: ['shortness of breath', 'difficulty breathing', 'wheezing', 'cough'],
    CARDIAC: ['palpitations', 'irregular heartbeat', 'racing heart', 'skipped beats'],
    FATIGUE: ['fatigue', 'extreme tiredness', 'weakness', 'exhaustion'],
    PAIN: ['arm pain', 'jaw pain', 'back pain', 'neck pain', 'shoulder pain'],
    NEUROLOGICAL: ['dizziness', 'lightheadedness', 'fainting', 'near-fainting', 'confusion'],
    GASTROINTESTINAL: ['nausea', 'vomiting', 'indigestion', 'abdominal discomfort'],
    EDEMA: ['leg swelling', 'ankle swelling', 'foot swelling', 'weight gain'],
    OTHER: ['sweating', 'cold sweat', 'anxiety', 'sense of doom']
};

export interface SymptomEntry {
    id: string;
    symptom: string;
    category: string;
    severity: SymptomSeverity;
    timestamp: number;
    notes?: string;
    duration?: string;
    triggers?: string[];
}

export interface UserProfile {
    id: string;
    name?: string;
    age?: number;
    gender?: string;
    knownConditions: string[];
    medications: string[];
    allergies: string[];
    emergencyContact?: {
        name: string;
        phone: string;
        relationship: string;
    };
    lastUpdated: number;
    createdAt: number;
}

export interface SymptomValidation {
    isWorsening: boolean;
    isNew: boolean;
    isRecurring: boolean;
    trend: 'IMPROVING' | 'STABLE' | 'WORSENING' | 'NEW';
    previousOccurrences: number;
    lastSeen?: number;
    daysSinceLastOccurrence?: number;
    concernLevel: 'LOW' | 'MODERATE' | 'HIGH' | 'CRITICAL';
    recommendations: string[];
    alerts: string[];
}

export interface MemorySnapshot {
    symptoms: SymptomEntry[];
    profile: UserProfile | null;
    lastAssessment: number | null;
    riskTrend: 'DECREASING' | 'STABLE' | 'INCREASING';
    totalAssessments: number;
}

class SymptomMemoryService {
    private symptoms: SymptomEntry[] = [];
    private profile: UserProfile | null = null;
    private lastAssessmentTime: number | null = null;
    private assessmentCount: number = 0;

    constructor() {
        this.loadFromStorage();
    }

    // Load data from localStorage
    private loadFromStorage(): void {
        try {
            const savedMemory = localStorage.getItem(MEMORY_KEY);
            if (savedMemory) {
                const data = JSON.parse(savedMemory);
                this.symptoms = data.symptoms || [];
                this.lastAssessmentTime = data.lastAssessment || null;
                this.assessmentCount = data.assessmentCount || 0;
            }

            const savedProfile = localStorage.getItem(USER_PROFILE_KEY);
            if (savedProfile) {
                this.profile = JSON.parse(savedProfile);
            }
        } catch (e) {
            console.error('Failed to load symptom memory:', e);
        }
    }

    // Save data to localStorage
    private saveToStorage(): void {
        try {
            localStorage.setItem(MEMORY_KEY, JSON.stringify({
                symptoms: this.symptoms,
                lastAssessment: this.lastAssessmentTime,
                assessmentCount: this.assessmentCount
            }));

            if (this.profile) {
                localStorage.setItem(USER_PROFILE_KEY, JSON.stringify(this.profile));
            }
        } catch (e) {
            console.error('Failed to save symptom memory:', e);
        }
    }

    // Record a new symptom
    recordSymptom(symptom: string, severity: SymptomSeverity, notes?: string, triggers?: string[]): SymptomEntry {
        const category = this.categorizeSymptom(symptom);

        const entry: SymptomEntry = {
            id: crypto.randomUUID(),
            symptom: symptom.toLowerCase(),
            category,
            severity,
            timestamp: Date.now(),
            notes,
            triggers
        };

        this.symptoms.push(entry);
        this.saveToStorage();

        console.log(`📝 Symptom recorded: ${symptom} (${SymptomSeverity[severity]})`);
        return entry;
    }

    // Record multiple symptoms at once
    recordSymptoms(symptoms: string[], severity: SymptomSeverity = SymptomSeverity.MODERATE): SymptomEntry[] {
        return symptoms.map(s => this.recordSymptom(s, severity));
    }

    // Categorize a symptom
    private categorizeSymptom(symptom: string): string {
        const lower = symptom.toLowerCase();
        for (const [category, keywords] of Object.entries(SYMPTOM_CATEGORIES)) {
            if (keywords.some(k => lower.includes(k))) {
                return category;
            }
        }
        return 'OTHER';
    }

    // Validate if user is feeling same/different
    validateSymptomChange(currentSymptoms: string[]): SymptomValidation[] {
        const validations: SymptomValidation[] = [];

        for (const symptom of currentSymptoms) {
            const validation = this.validateSingleSymptom(symptom);
            validations.push(validation);
        }

        return validations;
    }

    // Validate a single symptom against history
    private validateSingleSymptom(symptom: string): SymptomValidation {
        const lower = symptom.toLowerCase();
        const now = Date.now();
        const oneDay = 24 * 60 * 60 * 1000;
        const oneWeek = 7 * oneDay;

        // Find previous occurrences
        const previousOccurrences = this.symptoms.filter(s =>
            s.symptom.includes(lower) || lower.includes(s.symptom)
        );

        const lastOccurrence = previousOccurrences.length > 0
            ? previousOccurrences[previousOccurrences.length - 1]
            : null;

        const daysSinceLastOccurrence = lastOccurrence
            ? Math.floor((now - lastOccurrence.timestamp) / oneDay)
            : undefined;

        // Determine trend
        let trend: SymptomValidation['trend'] = 'NEW';
        let isWorsening = false;
        let concernLevel: SymptomValidation['concernLevel'] = 'LOW';
        const recommendations: string[] = [];
        const alerts: string[] = [];

        if (previousOccurrences.length === 0) {
            trend = 'NEW';
            recommendations.push('New symptom detected - monitor closely for progression');
        } else if (daysSinceLastOccurrence !== undefined && daysSinceLastOccurrence <= 1) {
            // Check severity trend
            const recentSeverities = previousOccurrences
                .filter(s => now - s.timestamp < oneWeek)
                .map(s => s.severity);

            const avgSeverity = recentSeverities.length > 0
                ? recentSeverities.reduce((a, b) => a + b, 0) / recentSeverities.length
                : 0;

            if (recentSeverities.length >= 3 && recentSeverities[recentSeverities.length - 1] > avgSeverity) {
                trend = 'WORSENING';
                isWorsening = true;
                concernLevel = 'HIGH';
                alerts.push(`⚠️ ${symptom} appears to be worsening over the past week`);
                recommendations.push('Consider medical consultation if symptom persists');
            } else {
                trend = 'STABLE';
            }
        } else if (daysSinceLastOccurrence !== undefined && daysSinceLastOccurrence > 7) {
            trend = 'IMPROVING';
            recommendations.push('Symptom was absent for over a week - good progress');
        } else {
            trend = 'STABLE';
        }

        // Check for concerning recurring patterns
        const recentWeekOccurrences = previousOccurrences.filter(s => now - s.timestamp < oneWeek).length;
        if (recentWeekOccurrences >= 5) {
            concernLevel = concernLevel === 'LOW' ? 'MODERATE' : concernLevel;
            alerts.push(`📊 ${symptom} has occurred ${recentWeekOccurrences} times this week`);
            recommendations.push('Frequent recurrence suggests need for medical evaluation');
        }

        // Check category-specific concerns
        const category = this.categorizeSymptom(symptom);
        if (category === 'CHEST' || category === 'CARDIAC') {
            concernLevel = concernLevel === 'LOW' ? 'MODERATE' : 'HIGH';
            recommendations.push('Cardiac symptoms warrant prompt evaluation');
        }

        return {
            isWorsening,
            isNew: previousOccurrences.length === 0,
            isRecurring: previousOccurrences.length > 2,
            trend,
            previousOccurrences: previousOccurrences.length,
            lastSeen: lastOccurrence?.timestamp,
            daysSinceLastOccurrence,
            concernLevel,
            recommendations,
            alerts
        };
    }

    // Update user profile
    updateProfile(updates: Partial<UserProfile>): void {
        if (!this.profile) {
            this.profile = {
                id: crypto.randomUUID(),
                knownConditions: [],
                medications: [],
                allergies: [],
                createdAt: Date.now(),
                lastUpdated: Date.now(),
                ...updates
            };
        } else {
            this.profile = {
                ...this.profile,
                ...updates,
                lastUpdated: Date.now()
            };
        }
        this.saveToStorage();
    }

    // Get user profile
    getProfile(): UserProfile | null {
        return this.profile;
    }

    // Record an assessment
    recordAssessment(): void {
        this.lastAssessmentTime = Date.now();
        this.assessmentCount++;
        this.saveToStorage();
    }

    // Get symptom history for a time period
    getSymptomHistory(days: number = 30): SymptomEntry[] {
        const cutoff = Date.now() - (days * 24 * 60 * 60 * 1000);
        return this.symptoms.filter(s => s.timestamp >= cutoff);
    }

    // Get symptom frequency report
    getSymptomFrequencyReport(days: number = 30): Map<string, number> {
        const history = this.getSymptomHistory(days);
        const frequency = new Map<string, number>();

        for (const entry of history) {
            const current = frequency.get(entry.symptom) || 0;
            frequency.set(entry.symptom, current + 1);
        }

        return frequency;
    }

    // Check if user should be prompted to assess current state
    shouldPromptAssessment(): { shouldPrompt: boolean; reason: string } {
        const now = Date.now();
        const oneDay = 24 * 60 * 60 * 1000;

        if (!this.lastAssessmentTime) {
            return { shouldPrompt: true, reason: 'No previous assessment recorded' };
        }

        const daysSinceLastAssessment = (now - this.lastAssessmentTime) / oneDay;

        if (daysSinceLastAssessment >= 7) {
            return { shouldPrompt: true, reason: 'Weekly check-in recommended' };
        }

        // Check if there were recent high-severity symptoms
        const recentSevere = this.symptoms.filter(
            s => s.timestamp > this.lastAssessmentTime! && s.severity >= SymptomSeverity.SEVERE
        );

        if (recentSevere.length > 0) {
            return { shouldPrompt: true, reason: 'Follow-up on recent severe symptoms' };
        }

        return { shouldPrompt: false, reason: 'Assessment up to date' };
    }

    // Get memory snapshot for AI context
    getMemorySnapshot(): MemorySnapshot {
        const recentSymptoms = this.getSymptomHistory(30);

        // Calculate risk trend
        const weekAgoSymptoms = this.symptoms.filter(
            s => s.timestamp > Date.now() - 14 * 24 * 60 * 60 * 1000 &&
                s.timestamp < Date.now() - 7 * 24 * 60 * 60 * 1000
        );
        const thisWeekSymptoms = this.symptoms.filter(
            s => s.timestamp > Date.now() - 7 * 24 * 60 * 60 * 1000
        );

        let riskTrend: MemorySnapshot['riskTrend'] = 'STABLE';
        if (thisWeekSymptoms.length > weekAgoSymptoms.length * 1.5) {
            riskTrend = 'INCREASING';
        } else if (thisWeekSymptoms.length < weekAgoSymptoms.length * 0.5) {
            riskTrend = 'DECREASING';
        }

        return {
            symptoms: recentSymptoms,
            profile: this.profile,
            lastAssessment: this.lastAssessmentTime,
            riskTrend,
            totalAssessments: this.assessmentCount
        };
    }

    // Clear all data (for testing/reset)
    clearAll(): void {
        this.symptoms = [];
        this.profile = null;
        this.lastAssessmentTime = null;
        this.assessmentCount = 0;
        localStorage.removeItem(MEMORY_KEY);
        localStorage.removeItem(USER_PROFILE_KEY);
    }
}

// Singleton instance
const symptomMemory = new SymptomMemoryService();

// Export convenience functions
export const recordSymptom = (symptom: string, severity: SymptomSeverity, notes?: string) =>
    symptomMemory.recordSymptom(symptom, severity, notes);
export const recordSymptoms = (symptoms: string[], severity?: SymptomSeverity) =>
    symptomMemory.recordSymptoms(symptoms, severity);
export const validateSymptomChange = (symptoms: string[]) =>
    symptomMemory.validateSymptomChange(symptoms);
export const updateUserProfile = (updates: Partial<UserProfile>) =>
    symptomMemory.updateProfile(updates);
export const getUserProfile = () => symptomMemory.getProfile();
export const getSymptomHistory = (days?: number) => symptomMemory.getSymptomHistory(days);
export const getSymptomFrequency = (days?: number) => symptomMemory.getSymptomFrequencyReport(days);
export const shouldPromptAssessment = () => symptomMemory.shouldPromptAssessment();
export const getMemorySnapshot = () => symptomMemory.getMemorySnapshot();
export const recordAssessment = () => symptomMemory.recordAssessment();
export const clearSymptomMemory = () => symptomMemory.clearAll();

export default symptomMemory;
