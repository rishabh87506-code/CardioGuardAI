/**
 * CardioGuard AI - CVD Research & Evidence Service
 * © 2026 CardioGuard AI / TCH Medical
 * 
 * Integration with PubMed and scientific literature for evidence-based CVD analysis
 * Provides latest research trends and worst-case CVD risk patterns
 */

// PubMed E-utilities API endpoints
const PUBMED_BASE = 'https://eutils.ncbi.nlm.nih.gov/entrez/eutils';
const PUBMED_SEARCH = `${PUBMED_BASE}/esearch.fcgi`;
const PUBMED_FETCH = `${PUBMED_BASE}/efetch.fcgi`;
const PUBMED_SUMMARY = `${PUBMED_BASE}/esummary.fcgi`;

// High-priority CVD research topics
export const CVD_RESEARCH_TOPICS = [
    'cardiovascular disease risk factors 2024',
    'heart attack symptoms women',
    'SCAD spontaneous coronary artery dissection',
    'sudden cardiac death prevention',
    'atypical myocardial infarction presentation',
    'heart failure early detection biomarkers',
    'cardiovascular disease machine learning prediction',
    'remote patient monitoring cardiology'
];

// Evidence-based worst CVD risks (from major studies)
export const WORST_CVD_RISKS = {
    FRAMINGHAM_RISK_FACTORS: {
        source: 'Framingham Heart Study',
        pmid: '9603539',
        factors: [
            { name: 'Age', impact: 'HIGH', notes: 'Risk doubles every decade after 45 for men, 55 for women' },
            { name: 'Male Sex', impact: 'HIGH', notes: 'Men have higher risk until women reach menopause' },
            { name: 'Smoking', impact: 'VERY_HIGH', notes: '2-4x increased risk, reversible within 5-15 years of quit' },
            { name: 'Total Cholesterol >240', impact: 'HIGH', notes: '2x risk compared to <200' },
            { name: 'HDL <40', impact: 'HIGH', notes: 'Each 1mg/dL increase reduces risk by 2-3%' },
            { name: 'Systolic BP >180', impact: 'VERY_HIGH', notes: '3x risk compared to <120' },
            { name: 'Diabetes', impact: 'VERY_HIGH', notes: '2-4x increased risk, higher in women' }
        ]
    },
    INTERHEART_MODIFIABLE: {
        source: 'INTERHEART Study (52 countries)',
        pmid: '15364185',
        factors: [
            { name: 'Smoking', populationRisk: '35.7%', odds: 2.87 },
            { name: 'Abnormal Lipids', populationRisk: '49.2%', odds: 3.25 },
            { name: 'Hypertension', populationRisk: '17.9%', odds: 1.91 },
            { name: 'Diabetes', populationRisk: '9.9%', odds: 2.37 },
            { name: 'Abdominal Obesity', populationRisk: '20.1%', odds: 1.12 },
            { name: 'Psychosocial Factors', populationRisk: '32.5%', odds: 2.67 },
            { name: 'Low Fruit/Vegetable', populationRisk: '13.7%', odds: 0.70 },
            { name: 'Physical Inactivity', populationRisk: '12.2%', odds: 0.86 },
            { name: 'Alcohol Excess', populationRisk: '6.7%', odds: 0.91 }
        ]
    },
    WOMENS_SPECIFIC_RISKS: {
        source: 'AHA Go Red for Women',
        factors: [
            { name: 'Pregnancy Complications', notes: 'Preeclampsia increases lifetime CVD risk 2-4x' },
            { name: 'PCOS', notes: 'Associated with metabolic syndrome and increased CVD' },
            { name: 'Autoimmune Diseases', notes: 'RA, Lupus increase CVD risk significantly' },
            { name: 'Mental Health', notes: 'Depression more strongly linked to CVD in women' },
            { name: 'Hormone Therapy', notes: 'Complex relationship, timing matters' }
        ]
    }
};

// Critical symptom patterns from clinical literature
export const CRITICAL_SYMPTOM_PATTERNS = {
    CLASSIC_MI: {
        name: 'Classic Myocardial Infarction',
        symptoms: ['crushing chest pain', 'left arm pain', 'jaw pain', 'sweating', 'nausea'],
        urgency: 'CALL_911',
        timeWindow: 'Golden hour - treatment within 60 minutes critical'
    },
    ATYPICAL_MI: {
        name: 'Atypical MI (Common in Women/Elderly/Diabetics)',
        symptoms: ['fatigue', 'shortness of breath', 'back pain', 'indigestion', 'dizziness'],
        urgency: 'CALL_911',
        notes: '30% of MIs present atypically, especially in women'
    },
    UNSTABLE_ANGINA: {
        name: 'Unstable Angina',
        symptoms: ['new chest pain', 'chest pain at rest', 'increasing frequency of angina'],
        urgency: 'EMERGENCY',
        notes: 'High risk of progression to MI within 48 hours'
    },
    HEART_FAILURE: {
        name: 'Acute Decompensated Heart Failure',
        symptoms: ['severe shortness of breath', 'unable to lie flat', 'leg swelling', 'rapid weight gain', 'persistent cough'],
        urgency: 'EMERGENCY',
        notes: '90-day mortality 10-20% if untreated'
    },
    AORTIC_DISSECTION: {
        name: 'Aortic Dissection',
        symptoms: ['sudden severe chest pain', 'tearing sensation', 'pain radiating to back', 'blood pressure difference between arms'],
        urgency: 'CALL_911',
        notes: '1% mortality per hour if untreated - surgical emergency'
    },
    ARRHYTHMIA_CRISIS: {
        name: 'Life-threatening Arrhythmia',
        symptoms: ['palpitations', 'syncope', 'near-syncope', 'chest discomfort'],
        urgency: 'EMERGENCY',
        notes: 'VT/VF can lead to sudden cardiac death within minutes'
    }
};

export interface ResearchArticle {
    pmid: string;
    title: string;
    authors: string;
    journal: string;
    pubDate: string;
    abstract?: string;
    doi?: string;
    relevance: string;
}

export interface ResearchSummary {
    topic: string;
    articles: ResearchArticle[];
    lastUpdated: number;
    keyFindings: string[];
}

/**
 * Fetch latest CVD research from PubMed
 */
export const fetchPubMedArticles = async (query: string, maxResults: number = 5): Promise<ResearchArticle[]> => {
    try {
        // Search for article IDs
        const searchUrl = `${PUBMED_SEARCH}?db=pubmed&term=${encodeURIComponent(query)}&retmax=${maxResults}&sort=relevance&retmode=json`;
        const searchResponse = await fetch(searchUrl);
        const searchData = await searchResponse.json();

        const ids = searchData?.esearchresult?.idlist || [];
        if (ids.length === 0) return [];

        // Fetch article summaries
        const summaryUrl = `${PUBMED_SUMMARY}?db=pubmed&id=${ids.join(',')}&retmode=json`;
        const summaryResponse = await fetch(summaryUrl);
        const summaryData = await summaryResponse.json();

        const articles: ResearchArticle[] = [];
        const result = summaryData?.result || {};

        for (const id of ids) {
            const article = result[id];
            if (article) {
                articles.push({
                    pmid: id,
                    title: article.title || 'Untitled',
                    authors: article.authors?.map((a: any) => a.name).join(', ') || 'Unknown',
                    journal: article.source || 'Unknown Journal',
                    pubDate: article.pubdate || 'Unknown Date',
                    doi: article.elocationid || undefined,
                    relevance: query
                });
            }
        }

        return articles;
    } catch (error) {
        console.error('PubMed fetch error:', error);
        return [];
    }
};

/**
 * Get curated CVD research summary with key findings
 */
export const getCVDResearchSummary = async (): Promise<ResearchSummary[]> => {
    const summaries: ResearchSummary[] = [];

    // Fetch research for priority topics
    for (const topic of CVD_RESEARCH_TOPICS.slice(0, 4)) { // Limit to avoid rate limits
        const articles = await fetchPubMedArticles(topic, 3);

        summaries.push({
            topic,
            articles,
            lastUpdated: Date.now(),
            keyFindings: extractKeyFindings(topic, articles)
        });

        // Respect PubMed rate limits (3 requests per second without API key)
        await new Promise(resolve => setTimeout(resolve, 350));
    }

    return summaries;
};

/**
 * Extract key findings based on topic
 */
const extractKeyFindings = (topic: string, articles: ResearchArticle[]): string[] => {
    // Generate contextual key findings based on topic and article count
    const findings: string[] = [];

    if (topic.includes('women')) {
        findings.push('Women often present with atypical MI symptoms');
        findings.push('SCAD is a leading cause of heart attacks in young women');
        findings.push('Pregnancy complications are lifetime CVD risk markers');
    } else if (topic.includes('sudden')) {
        findings.push('SCD often occurs without prior symptoms');
        findings.push('Early CPR and defibrillation are critical within 10 minutes');
        findings.push('Family history of SCD significantly increases risk');
    } else if (topic.includes('machine learning')) {
        findings.push('AI models can predict CVD events with 85%+ accuracy');
        findings.push('Wearable data improves real-time risk stratification');
        findings.push('Multi-modal AI outperforms single-factor risk scores');
    } else {
        findings.push('Modifiable risk factors account for >90% of CVD risk');
        findings.push('Early detection and intervention significantly reduce mortality');
        findings.push(`${articles.length} recent publications found on this topic`);
    }

    return findings;
};

/**
 * Get evidence-based risk analysis for a patient profile
 */
export const getEvidenceBasedRiskAnalysis = (vitals: {
    age: number;
    gender: string;
    systolicBP: number;
    totalCholesterol: number;
    hdlCholesterol: number;
    isSmoker: boolean;
    hasDiabetes: boolean;
}): {
    riskFactors: string[];
    citations: string[];
    recommendations: string[];
    worstCaseScenarios: string[];
} => {
    const riskFactors: string[] = [];
    const citations: string[] = [];
    const recommendations: string[] = [];
    const worstCaseScenarios: string[] = [];

    // Age-based risk (Framingham)
    if ((vitals.gender === 'male' && vitals.age >= 45) || (vitals.gender === 'female' && vitals.age >= 55)) {
        riskFactors.push(`Age ${vitals.age} - significant CVD risk factor`);
        citations.push('Framingham Heart Study, PMID: 9603539');
    }

    // Smoking (INTERHEART)
    if (vitals.isSmoker) {
        riskFactors.push('Current smoker - 2.87x increased MI risk');
        citations.push('INTERHEART Study, PMID: 15364185');
        recommendations.push('Smoking cessation is the single most effective intervention');
        worstCaseScenarios.push('Smokers have 2-4x higher risk of sudden cardiac death');
    }

    // Blood Pressure
    if (vitals.systolicBP >= 180) {
        riskFactors.push('Severe hypertension (Stage 2) - 3x CVD risk');
        citations.push('JNC 8 Hypertension Guidelines');
        worstCaseScenarios.push('Severe HTN increases stroke and aortic dissection risk');
        recommendations.push('Immediate medical consultation recommended');
    } else if (vitals.systolicBP >= 140) {
        riskFactors.push('Hypertension - significant CVD risk factor');
        recommendations.push('Blood pressure control target <130/80 for high-risk patients');
    }

    // Cholesterol
    if (vitals.totalCholesterol > 240) {
        riskFactors.push('High total cholesterol - 2x CVD risk');
        citations.push('ATP III Guidelines, PMID: 11368702');
        recommendations.push('Lipid-lowering therapy evaluation recommended');
    }

    if (vitals.hdlCholesterol < 40) {
        riskFactors.push('Low HDL cholesterol - independent CVD risk factor');
        recommendations.push('Lifestyle modifications: exercise, omega-3, smoking cessation');
    }

    // Diabetes (INTERHEART)
    if (vitals.hasDiabetes) {
        riskFactors.push('Diabetes - 2.37x increased MI risk');
        citations.push('INTERHEART Study, PMID: 15364185');
        worstCaseScenarios.push('Diabetics often have silent MIs due to neuropathy');
        recommendations.push('Enhanced glucose control and cardiovascular monitoring essential');
    }

    // Women-specific considerations
    if (vitals.gender === 'female') {
        citations.push('AHA Go Red for Women Scientific Statement');
        recommendations.push('Consider sex-specific risk factors (pregnancy history, PCOS, autoimmune)');
    }

    return { riskFactors, citations, recommendations, worstCaseScenarios };
};

export default {
    fetchPubMedArticles,
    getCVDResearchSummary,
    getEvidenceBasedRiskAnalysis,
    WORST_CVD_RISKS,
    CRITICAL_SYMPTOM_PATTERNS,
    CVD_RESEARCH_TOPICS
};
