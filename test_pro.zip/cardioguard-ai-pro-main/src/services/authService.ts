/**
 * CardioGuard AI - Authentication Service
 * 
 * Handles user authentication via Supabase Auth.
 * Provides email/password authentication with session persistence.
 */

import { supabase, isSupabaseConfigured } from './supabaseService';
import type { User, Session, AuthError } from '@supabase/supabase-js';

export interface AuthResult {
    success: boolean;
    user?: User | null;
    session?: Session | null;
    error?: string;
    message?: string;
}

/**
 * Sign up a new user with email and password
 */
export async function signUp(email: string, password: string): Promise<AuthResult> {
    if (!isSupabaseConfigured) {
        return { success: false, error: 'Supabase not configured. Please add your credentials.' };
    }

    try {
        const { data, error } = await supabase.auth.signUp({
            email,
            password,
        });

        if (error) {
            return { success: false, error: error.message };
        }

        return {
            success: true,
            user: data.user,
            session: data.session,
        };
    } catch (err: any) {
        return { success: false, error: err.message || 'Sign up failed' };
    }
}

/**
 * Sign in an existing user with email and password
 */
export async function signIn(email: string, password: string): Promise<AuthResult> {
    if (!isSupabaseConfigured) {
        return { success: false, error: 'Supabase not configured. Please add your credentials.' };
    }

    try {
        const { data, error } = await supabase.auth.signInWithPassword({
            email,
            password,
        });

        if (error) {
            return { success: false, error: error.message };
        }

        return {
            success: true,
            user: data.user,
            session: data.session,
        };
    } catch (err: any) {
        return { success: false, error: err.message || 'Sign in failed' };
    }
}

/**
 * Sign in using Magic Link (Email only)
 */
export async function signInWithMagicLink(email: string): Promise<AuthResult> {
    if (!isSupabaseConfigured) {
        return { success: false, error: 'Supabase not configured.' };
    }

    try {
        const { error } = await supabase.auth.signInWithOtp({
            email,
            options: {
                emailRedirectTo: `${window.location.origin}/app/dashboard`,
            },
        });

        if (error) {
            return { success: false, error: error.message };
        }

        return {
            success: true,
            message: 'Check your email for the login link.'
        };
    } catch (err: any) {
        return { success: false, error: err.message || 'Magic link request failed' };
    }
}

/**
 * Sign in with Google OAuth
 */
export async function signInWithGoogle(): Promise<AuthResult> {
    if (!isSupabaseConfigured) {
        return { success: false, error: 'Supabase not configured.' };
    }

    try {
        const { data, error } = await supabase.auth.signInWithOAuth({
            provider: 'google',
            options: {
                redirectTo: `${window.location.origin}/app/dashboard`,
            },
        });

        if (error) {
            return { success: false, error: error.message };
        }

        return { success: true };
    } catch (err: any) {
        return { success: false, error: err.message || 'Google sign in failed' };
    }
}

/**
 * Sign out the current user
 */
export async function signOut(): Promise<{ success: boolean; error?: string }> {
    if (!isSupabaseConfigured) {
        // Clear local auth state even if Supabase isn't configured
        localStorage.removeItem('cardioguard_auth_state');
        return { success: true };
    }

    try {
        const { error } = await supabase.auth.signOut();

        if (error) {
            return { success: false, error: error.message };
        }

        return { success: true };
    } catch (err: any) {
        return { success: false, error: err.message || 'Sign out failed' };
    }
}

/**
 * Get the current user session
 */
export async function getCurrentSession(): Promise<{ user: User | null; session: Session | null }> {
    if (!isSupabaseConfigured) {
        return { user: null, session: null };
    }

    try {
        const { data: { session } } = await supabase.auth.getSession();
        return {
            user: session?.user || null,
            session,
        };
    } catch {
        return { user: null, session: null };
    }
}

/**
 * Get the current user
 */
export async function getCurrentUser(): Promise<User | null> {
    if (!isSupabaseConfigured) {
        return null;
    }

    try {
        const { data: { user } } = await supabase.auth.getUser();
        return user;
    } catch {
        return null;
    }
}

/**
 * Listen to authentication state changes
 */
export function onAuthStateChange(
    callback: (event: string, session: Session | null) => void
): () => void {
    if (!isSupabaseConfigured) {
        return () => { }; // Return no-op cleanup function
    }

    const { data: { subscription } } = supabase.auth.onAuthStateChange((event, session) => {
        callback(event, session);
    });

    return () => {
        subscription.unsubscribe();
    };
}

/**
 * Send password reset email
 */
export async function resetPassword(email: string): Promise<{ success: boolean; error?: string }> {
    if (!isSupabaseConfigured) {
        return { success: false, error: 'Supabase not configured' };
    }

    try {
        const { error } = await supabase.auth.resetPasswordForEmail(email, {
            redirectTo: `${window.location.origin}/reset-password`,
        });

        if (error) {
            return { success: false, error: error.message };
        }

        return { success: true };
    } catch (err: any) {
        return { success: false, error: err.message || 'Password reset failed' };
    }
}

/**
 * Check if Supabase auth is available
 */
export function isAuthAvailable(): boolean {
    return isSupabaseConfigured;
}

export default {
    signUp,
    signIn,
    signInWithMagicLink,
    signInWithGoogle,
    signOut,
    getCurrentSession,
    getCurrentUser,
    onAuthStateChange,
    resetPassword,
    isAuthAvailable,
};
