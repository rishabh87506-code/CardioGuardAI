
import { MarketingDraft, SocialChannel } from '../types';

// Mock context for generation - in real app would take user stats
export const generateMarketingDrafts = async (): Promise<MarketingDraft[]> => {
    // Simulate AI delay
    await new Promise(resolve => setTimeout(resolve, 1500));

    return [
        {
            id: crypto.randomUUID(),
            channel: 'twitter',
            content: "Just hit a new streak on CardioGuard AI! 🚀 My HRV is trending up and my Risk Analyst says I'm in the green. Prevention is the new cure. #HealthTech #Longevity",
            status: 'draft',
            predictedEngagement: 'High',
            hashtags: ['#CardioGuard', '#Biohacking'],
            timestamp: Date.now()
        },
        {
            id: crypto.randomUUID(),
            channel: 'linkedin',
            content: "I've been using CardioGuard AI to monitor my cardiovascular health with clinical precision. The 'Agentic' approach to health monitoring is a game changer. It's not just data; it's actionable intelligence. excited to see where this technology goes. #DigitalHealth #AI #MedTech",
            status: 'draft',
            predictedEngagement: 'Medium',
            hashtags: ['#Innovation', '#Healthcare'],
            timestamp: Date.now()
        },
        {
            id: crypto.randomUUID(),
            channel: 'instagram',
            content: "POV: You have a clinical team in your pocket. 🫀✨ aesthetic charts + peace of mind. #CardioGuardAI #HealthAesthetic",
            status: 'draft',
            predictedEngagement: 'High',
            hashtags: ['#MorningRoutine', '#Wellness'],
            timestamp: Date.now()
        }
    ];
};

export const approveDraft = async (draft: MarketingDraft): Promise<MarketingDraft> => {
    // Simulate posting API call
    await new Promise(resolve => setTimeout(resolve, 1000));
    return { ...draft, status: 'posted' };
};
