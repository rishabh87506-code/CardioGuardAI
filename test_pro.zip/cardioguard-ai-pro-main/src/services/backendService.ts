/**
 * CardioGuard AI - Backend Microservice Integration
 * 
 * Interacts with the FastAPI XGBoost prediction node.
 */

import { VitalsData } from '../types';

const BACKEND_URL = import.meta.env.VITE_BACKEND_URL || 'http://localhost:8000';

export interface PredictionResult {
    success: boolean;
    data?: {
        riskScore: number;
        riskCategory: string;
        algorithm: string;
        accuracy_target: number;
        SHAP_explainability: Record<string, string>;
        timestamp: string;
        disclaimer: string;
        mace_window: string;
    };
    error?: string;
}

/**
 * Executes high-precision risk prediction via the XGBoost microservice.
 */
export const predictRiskVector = async (vitals: VitalsData, symptoms: string[] = []): Promise<PredictionResult> => {
    try {
        const response = await fetch(`${BACKEND_URL}/api/predict`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                ...vitals,
                symptoms: symptoms.join(', '),
            }),
        });

        if (!response.ok) {
            const errorData = await response.json();
            throw new Error(errorData.detail || 'Prediction request failed');
        }

        return await response.json();
    } catch (error: any) {
        console.error('Backend Prediction Error:', error);
        return { success: false, error: error.message };
    }
};

/**
 * Verifies backend node status and algorithm accuracy benchmarks.
 */
export const checkBackendHealth = async () => {
    try {
        const response = await fetch(`${BACKEND_URL}/api/health`);
        return await response.json();
    } catch {
        return { status: 'offline' };
    }
};
