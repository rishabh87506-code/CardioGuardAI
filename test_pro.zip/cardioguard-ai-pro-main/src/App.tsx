import React, { useState, useEffect, Suspense } from 'react';
import './index.css';
import GlobalStyles from './components/GlobalStyles';
import { BrowserRouter as Router, Routes, Route, useNavigate, useLocation, Navigate } from 'react-router-dom';
import {
  Heart, Activity, ShieldCheck, Home,
  BarChart, Lock, User, Menu, X, Stethoscope, Radio, Cpu,
  ChevronRight, Bell, Search, Zap, Loader2, Database, Globe, Clock, ShieldAlert
} from 'lucide-react';

// Optimized Component Imports
import LandingPage from './components/LandingPage';
import Login from './components/Login';
import PrivacyPolicy from './components/PrivacyPolicy';
import TermsOfService from './components/TermsOfService';
import VitalsForm from './components/VitalsForm';
import RiskResult from './components/RiskResult';
import HistoryView from './components/HistoryView';
import TrendDashboard from './components/TrendDashboard';
import MedicalLocker from './components/MedicalLocker';
import MedicalDisclaimer from './components/MedicalDisclaimer';
import DiagnosticLab from './components/DiagnosticLab';
import AgentsView from './components/AgentsView';
import AuditSuite from './components/AuditSuite';
import DoctorDashboard from './components/DoctorDashboard';
import HealthcareDashboard from './components/HealthcareDashboard';
import VitalStream from './components/VitalStream';
import Dashboard from './components/Dashboard';
import DistrictAnalytics from './components/DistrictAnalytics';
import HealthCycleView from './components/HealthCycleView';
import DoctorBooking from './components/DoctorBooking';
import { assessHeartRisk } from './services/geminiService';
import { calculateFraminghamRisk } from './utils/riskCalculators';
import { supabase, getAssessmentHistory, saveAssessment, triggerSOS as triggerSOSService } from './services/supabaseService';
import { RealtimePostgresInsertPayload } from '@supabase/supabase-js';
import authService from './services/authService';
import { VitalsData, AssessmentResult } from './types';

// Feature Components
import EmergencySOS from './components/EmergencySOS';
import CardioConcierge from './components/CardioConcierge';
import MedicalID from './components/MedicalID';
import Subscription from './components/Subscription';
import PPGScanner from './components/PPGScanner';
import CardioChat from './components/CardioChat';

function App() {
  return (
    <Router>
      <GlobalStyles />
      <MainApp />
    </Router>
  );
}

function MainApp() {
  const [user, setUser] = useState<any>(null);
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [isGuestMode, setIsGuestMode] = useState(false);
  const [assessment, setAssessment] = useState<(AssessmentResult & { vitals?: VitalsData }) | null>(() => {
    const saved = localStorage.getItem('last_assessment');
    return saved ? JSON.parse(saved) : null;
  });
  const [history, setHistory] = useState<any[]>([]);
  const navigate = useNavigate();
  const location = useLocation();
  const [statusMessage, setStatusMessage] = useState("Bio-Core Online");
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  const [isConciergeOpen, setIsConciergeOpen] = useState(false);
  const [isSOSOpen, setIsSOSOpen] = useState(false);
  const [isPPGOpen, setIsPPGOpen] = useState(false);
  const [isChatOpen, setIsChatOpen] = useState(false);
  const [language, setLanguage] = useState<'English' | 'Spanish' | 'Hindi'>('English');

  useEffect(() => {
    (window as any).navigate = navigate;
  }, [navigate]);

  const fetchHistory = async (userId: string, isGlobal = false) => {
    try {
      const data = isGlobal
        ? (await supabase.from('assessments').select('*').order('created_at', { ascending: false })).data || []
        : await getAssessmentHistory(userId);

      const formattedData = data.map((item: any) => ({
        ...item,
        riskScore: item.risk_score,
        riskCategory: item.risk_level,
        vitals: item.vitals_snapshot,
        timestamp: new Date(item.created_at).getTime()
      }));

      setHistory(formattedData);
    } catch (err) {
      console.error("Clinical History Fetch Failure:", err);
    }
  };

  useEffect(() => {
    const isPhysicianView = location.pathname.includes('doctor') || location.pathname.includes('health-hq') || location.pathname.includes('stream');

    const cleanup = authService.onAuthStateChange((_event, session) => {
      const currentUser = session?.user || null;
      setUser(currentUser);
      setIsAuthenticated(!!currentUser);
      if (currentUser) fetchHistory(currentUser.id, isPhysicianView);
    });

    authService.getCurrentSession().then(({ user }) => {
      setUser(user);
      setIsAuthenticated(!!user);
      if (user) fetchHistory(user.id, isPhysicianView);
    });

    return cleanup;
  }, [location.pathname]);

  useEffect(() => {
    if (!isAuthenticated || !user) return;

    const isPhysician = location.pathname.includes('doctor') || location.pathname.includes('health-hq') || location.pathname.includes('stream');

    const channel = supabase
      .channel('clinical_realtime_feed')
      .on(
        'postgres_changes',
        {
          event: 'INSERT',
          schema: 'public',
          table: 'assessments',
          ...(isPhysician ? {} : { filter: `patient_id=eq.${user.id}` })
        },
        (payload: RealtimePostgresInsertPayload<any>) => {
          const formattedNew = {
            ...payload.new,
            riskScore: payload.new.risk_score,
            riskCategory: payload.new.risk_level,
            vitals: payload.new.vitals_snapshot
          };

          setHistory(prev => [formattedNew, ...prev]);

          if (payload.new.patient_id === user.id) {
            setAssessment(formattedNew);
          }
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [isAuthenticated, user, location.pathname]);

  const triggerSOS = async () => {
    if (!user) return;
    setStatusMessage("EMERGENCY: Dispatching SOS...");
    const location = { lat: 28.6139, lng: 77.2090 };
    await triggerSOSService(user.id, location, "Rapid Bio-Escalation Detected via AI Forensic Scan");
    alert("🚨 EMERGENCY SOS DISPATCHED: Medical teams have been alerted.");
  };

  useEffect(() => {
    (window as any).triggerSOS = triggerSOS;
    return () => { delete (window as any).triggerSOS; };
  }, [user]);

  useEffect(() => {
    const path = location.pathname;
    if (path.includes('analyze')) setStatusMessage("Assessment: In Progress");
    else if (path.includes('result')) setStatusMessage("Assessment: Complete");
    else if (path.includes('lab')) setStatusMessage("System: Benchmarking");
    else setStatusMessage("System: Ready");
    setIsSidebarOpen(false);
  }, [location.pathname]);

  const handleUpdateAssessment = (res: AssessmentResult, vitals: VitalsData) => {
    const finalRes = { ...res, vitals };
    setAssessment(finalRes);
    localStorage.setItem('last_assessment', JSON.stringify(finalRes));
  };

  const handleLogin = () => { navigate('/app/login'); };
  const handleGuestAccess = () => { setIsGuestMode(true); navigate('/analyze'); };

  if (!isAuthenticated && !isGuestMode && !location.pathname.startsWith('/app') && location.pathname !== '/doctor') {
    return <LandingPage onLogin={handleLogin} onLaunch={handleGuestAccess} />;
  }

  return (
    <div className="min-h-screen bg-slate-50 text-slate-800 selection:bg-cyan-500/10 font-inter">
      {/* GLOBAL SYSTEM TICKER */}
      <div className="fixed top-0 left-0 w-full z-[100] bg-white/80 backdrop-blur-md border-b border-slate-200 h-8 flex items-center overflow-hidden px-4">
        <div className="flex gap-12 whitespace-nowrap animate-marquee text-[9px] font-black tracking-[0.2em] text-slate-400 uppercase">
          <span className="flex items-center gap-2"><div className="w-1.5 h-1.5 bg-emerald-500 rounded-full animate-pulse"></div> System Status: Operational</span>
          <span className="text-rose-600">Safety Notice: Not FDA-cleared for diagnosis. Research Use Only.</span>
          <span>Target Accuracy: 99.1% (XGBoost Ensemble)</span>
          <span>Security: AES-256 Encrypted</span>
          <span className="text-cyan-600">{statusMessage}</span>
        </div>
      </div>

      <div className="flex pt-8 h-screen overflow-hidden">
        {/* SIDE NAV */}
        <aside className="hidden lg:flex w-72 flex-col border-r border-slate-200 bg-white p-6 relative">
          <div className="mb-12 px-2 cursor-pointer flex items-center gap-3" onClick={() => navigate('/')}>
            <div className="bg-cyan-600 p-2 rounded-xl text-white shadow-lg shadow-cyan-900/10">
              <Activity size={20} />
            </div>
            <span className="font-black text-2xl tracking-tighter text-slate-900">CardioGuard<span className="text-cyan-600">AI</span></span>
          </div>

          <nav className="flex-1 space-y-2">
            <NavMenuLink to="/" icon={<Home size={18} />} label="Overview" active={location.pathname === '/' || location.pathname === '/app/dashboard'} />
            <NavMenuLink to="/analyze" icon={<Activity size={18} />} label="New Assessment" active={location.pathname === '/analyze'} />
            <div className="pt-8 pb-4 px-4 text-[10px] font-black text-slate-400 uppercase tracking-widest">Medical Intelligence</div>
            <NavMenuLink to="/trends" icon={<BarChart size={18} />} label="Health Trends" active={location.pathname === '/trends'} />
            <NavMenuLink to="/cycle" icon={<Activity size={18} />} label="12-Month Projection" active={location.pathname === '/cycle'} />
            <NavMenuLink to="/locker" icon={<Lock size={18} />} label="Medical Locker" active={location.pathname === '/locker'} />
            <NavMenuLink to="/stream" icon={<Radio size={18} />} label="Live Monitor" active={location.pathname === '/stream'} />
            <div className="pt-8 pb-4 px-4 text-[10px] font-black text-slate-400 uppercase tracking-widest">System Tools</div>
            <NavMenuLink to="/lab" icon={<Stethoscope size={18} />} label="Accuracy Lab" active={location.pathname === '/lab'} />
            <NavMenuLink to="/audit" icon={<ShieldCheck size={18} />} label="Security Audit" active={location.pathname === '/audit'} />
            <NavMenuLink to="/agents" icon={<Cpu size={18} />} label="AI Agents" active={location.pathname === '/agents'} />
          </nav>

          <footer className="pt-6 border-t border-slate-100">
            {isAuthenticated ? (
              <div className="flex items-center gap-4 p-3 rounded-2xl bg-slate-50 border border-slate-200 group hover:border-cyan-500 transition-all cursor-pointer" onClick={() => authService.signOut()}>
                <div className="w-10 h-10 rounded-full bg-white flex items-center justify-center border border-slate-200">
                  <User size={20} className="text-slate-400" />
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-xs font-black text-slate-900 truncate">{user.email?.split('@')[0]}</p>
                  <p className="text-[9px] font-bold text-slate-400 uppercase tracking-widest">Sign Out</p>
                </div>
              </div>
            ) : (
              <button onClick={() => navigate('/app/login')} className="w-full py-4 bg-slate-900 hover:bg-slate-800 text-white rounded-2xl text-[10px] font-black uppercase tracking-widest transition-all">
                Clinician Portal
              </button>
            )}
          </footer>
        </aside>

        <main className="flex-1 overflow-y-auto no-scrollbar relative p-4 md:p-12">
          <div className="max-w-6xl mx-auto pb-24">
            <Suspense fallback={<div className="flex h-[50vh] items-center justify-center"><Loader2 className="w-10 h-10 animate-spin text-cyan-500" /></div>}>
              <Routes>
                <Route path="/" element={
                  <div className="space-y-12 animate-in fade-in slide-in-from-bottom-4 duration-700">
                    <header>
                      <h2 className="text-6xl font-black tracking-tighter text-slate-900 mb-4 leading-none">Hello, <span className="text-cyan-600">{user?.email?.split('@')[0] || 'Explorer'}</span></h2>
                      <p className="text-slate-500 text-xl font-medium max-w-2xl">High-fidelity cardiovascular intelligence workstation. Powered by Neuro-Symbolic Ensembles.</p>
                    </header>

                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                      <HeroCard title="New Assessment" desc="Start a new high-precision heart risk evaluation." icon={<Activity size={24} className="text-white" />} onClick={() => navigate('/analyze')} variant="primary" />
                      <HeroCard title="Emergency SOS" desc="Location-aware clinical dispatch protocol." icon={<Bell size={24} className="text-rose-600" />} onClick={() => setIsSOSOpen(true)} />
                      <HeroCard title="AI Concierge" desc="24/7 Generative cardiology assistant." icon={<Cpu size={24} className="text-cyan-600" />} onClick={() => setIsChatOpen(true)} />
                    </div>

                    <section className="space-y-6">
                      <div className="flex items-center justify-between">
                        <h3 className="text-[10px] font-black uppercase tracking-[0.4em] text-slate-400 flex items-center gap-3">
                          <Database size={14} className="text-cyan-500" /> Clinical Data Nodes
                        </h3>
                        <button onClick={() => navigate('/trends')} className="text-[10px] font-black uppercase tracking-widest text-cyan-600 hover:text-cyan-500">Audit Full Matrix &rarr;</button>
                      </div>

                      {assessment ? (
                        <div className="bg-white p-10 rounded-[3rem] border border-slate-200 shadow-2xl shadow-slate-900/5 relative overflow-hidden group">
                          <div className="flex flex-col md:flex-row md:items-center justify-between gap-10 relative z-10">
                            <div>
                              <div className="flex items-center gap-3 mb-6">
                                <div className={`px-4 py-1.5 rounded-full text-[10px] font-black uppercase tracking-widest ${assessment.riskCategory === 'High' || assessment.riskCategory === 'Very High' ? 'bg-rose-600 text-white' : 'bg-emerald-500 text-white'}`}>
                                  {assessment.riskCategory} Risk Verified
                                </div>
                                <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Precision Score: {assessment.riskScore}%</span>
                              </div>
                              <h4 className="text-3xl font-black text-slate-900 mb-4 tracking-tight">Active Assessment Matrix</h4>
                              <p className="text-slate-500 text-sm font-medium max-w-xl mb-8 leading-relaxed">{assessment.summary}</p>
                              <div className="flex gap-4">
                                <button onClick={() => navigate('/result')} className="px-8 py-4 bg-slate-900 text-white rounded-2xl font-black text-[10px] uppercase tracking-widest hover:bg-slate-800 transition-all shadow-lg active:scale-95">Review Full Report</button>
                                <button onClick={() => navigate('/analyze')} className="px-8 py-4 bg-slate-50 border border-slate-200 text-slate-600 rounded-2xl font-black text-[10px] uppercase tracking-widest hover:bg-white transition-all active:scale-95">Re-Triage Patient</button>
                              </div>
                            </div>
                            <div className="flex gap-12 border-l border-slate-100 pl-12">
                              <div>
                                <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-2">Hemodynamics</p>
                                <p className="text-3xl font-black text-slate-900">{assessment.vitals?.systolicBP}/{assessment.vitals?.diastolicBP}</p>
                                <p className="text-[9px] font-bold text-slate-400 uppercase mt-1">SYS / DIA (mmHg)</p>
                              </div>
                              <div>
                                <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-2">Heart Rate</p>
                                <p className="text-3xl font-black text-slate-900">{assessment.vitals?.heartRate}</p>
                                <p className="text-[9px] font-bold text-slate-400 uppercase mt-1">BPM (Resting)</p>
                              </div>
                            </div>
                          </div>
                        </div>
                      ) : (
                        <div className="bg-slate-50 border-2 border-dashed border-slate-200 flex flex-col items-center justify-center py-20 rounded-[3rem]">
                          <Zap size={40} className="mb-6 text-slate-200" />
                          <p className="text-xs font-black uppercase tracking-widest text-slate-400">No Biometric Nodes Detected</p>
                          <button onClick={() => navigate('/analyze')} className="mt-6 px-10 py-4 bg-white border border-slate-200 rounded-2xl text-[10px] font-black text-cyan-600 uppercase tracking-widest hover:shadow-md transition-all">Initialize First Scan</button>
                        </div>
                      )}
                    </section>
                  </div>
                } />

                <Route path="/analyze" element={
                  <div className="bg-white border border-slate-200 rounded-[3rem] p-10 shadow-sm">
                    <VitalsForm
                      onSubmit={async (data, symptoms) => {
                        const historyContext = history.map(h => h.summary).slice(0, 3);
                        const pastFramingham = history.map(h => calculateFraminghamRisk(h.vitals).riskPercent);
                        const trendContext = pastFramingham.length > 0 ? `Trend: ${pastFramingham[0] > calculateFraminghamRisk(data).riskPercent ? 'IMPROVING' : 'DECLINING'}` : 'New Baseline';
                        const res = await assessHeartRisk(data, 'English', symptoms, [trendContext, ...historyContext]);
                        handleUpdateAssessment(res, data);
                        if (user) await saveAssessment(res, data, user.id);
                        navigate('/result');
                      }}
                      language={language}
                    />
                  </div>
                } />

                <Route path="/result" element={assessment ? <RiskResult assessment={assessment} onReset={() => navigate('/')} meds={[]} vitals={assessment.vitals || null} language={language} /> : <Navigate to="/" />} />
                <Route path="/trends" element={<TrendDashboard history={history} onBack={() => navigate('/')} language={language} />} />
                <Route path="/locker" element={<MedicalLocker onBack={() => navigate('/')} language={language} storageMode="cloud" onToggleStorage={() => { }} />} />
                <Route path="/lab" element={<DiagnosticLab onShowResult={(res) => { handleUpdateAssessment(res, {} as any); navigate('/result'); }} onNavigate={(v) => navigate('/' + v)} />} />
                <Route path="/app/login" element={<Login />} />
                <Route path="/app/dashboard" element={<Dashboard />} />
                <Route path="/privacy" element={<PrivacyPolicy onBack={() => navigate('/')} />} />
                <Route path="/terms" element={<TermsOfService onBack={() => navigate('/')} />} />
                <Route path="*" element={<Navigate to="/" />} />
              </Routes>
            </Suspense>
          </div>
        </main>
      </div>

      {/* FLOATING ACTION OVERLAYS */}
      <div className="fixed bottom-10 right-10 z-[150] flex flex-col gap-4 items-end">
        <button onClick={() => setIsSOSOpen(true)} className="w-16 h-16 bg-rose-600 text-white rounded-full shadow-2xl flex items-center justify-center hover:scale-110 transition-all group">
          <Bell className="w-8 h-8 group-hover:animate-ring" />
        </button>
        <button onClick={() => setIsConciergeOpen(true)} className="w-16 h-16 bg-cyan-600 text-white rounded-full shadow-2xl flex items-center justify-center hover:scale-110 transition-all">
          <Cpu className="w-8 h-8" />
        </button>
      </div>

      {isSOSOpen && <EmergencySOS autoPrompt={true} onClose={() => setIsSOSOpen(false)} patientId={user?.id} />}
      {isChatOpen && <CardioChat onClose={() => setIsChatOpen(false)} currentAssessment={assessment} />}
      {isConciergeOpen && <CardioConcierge language={language} currentAssessment={assessment} onBack={() => setIsConciergeOpen(false)} onClose={() => setIsConciergeOpen(false)} />}
      {isPPGOpen && <PPGScanner onClose={() => setIsPPGOpen(false)} onComplete={(bpm) => { setIsPPGOpen(false); navigate('/analyze', { state: { heartRate: bpm } }); }} />}
    </div>
  );
}

function NavMenuLink({ to, icon, label, active }: any) {
  const navigate = useNavigate();
  return (
    <button onClick={() => navigate(to)} className={`w-full flex items-center gap-4 px-4 py-4 rounded-2xl text-xs font-black transition-all group ${active ? 'bg-cyan-50 text-cyan-600 border border-cyan-100' : 'text-slate-400 hover:text-slate-800 hover:bg-slate-50'}`}>
      <div className={`${active ? 'text-cyan-600' : 'text-slate-300 group-hover:text-cyan-500'} transition-colors`}>{icon}</div>
      <span className="uppercase tracking-widest">{label}</span>
    </button>
  );
}

function HeroCard({ title, desc, icon, onClick, variant }: any) {
  return (
    <div onClick={onClick} className={`p-10 rounded-[2.5rem] bg-white border border-slate-100 shadow-sm cursor-pointer group flex flex-col gap-8 hover:shadow-xl hover:border-cyan-100 transition-all ${variant === 'primary' ? 'bg-gradient-to-br from-cyan-600 to-blue-700 border-none' : ''}`}>
      <div className={`w-16 h-16 rounded-2xl flex items-center justify-center shadow-lg transition-transform group-hover:scale-110 ${variant === 'primary' ? 'bg-white/20' : 'bg-slate-50'}`}>{icon}</div>
      <div>
        <h3 className={`text-2xl font-black tracking-tight mb-3 ${variant === 'primary' ? 'text-white' : 'text-slate-900'}`}>{title}</h3>
        <p className={`text-sm font-medium leading-relaxed ${variant === 'primary' ? 'text-cyan-50' : 'text-slate-500'}`}>{desc}</p>
      </div>
      <div className={`mt-auto flex items-center gap-2 text-[10px] font-black uppercase tracking-widest ${variant === 'primary' ? 'text-white' : 'text-cyan-600'}`}>Execute Protocol <ChevronRight size={12} className="group-hover:translate-x-1 transition-transform" /></div>
    </div>
  );
}

export default App;