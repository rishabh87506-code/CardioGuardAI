import React from 'react';

interface HealthRingsProps {
  riskScore: number;
  bpScore: number; // Percentage relative to 'normal'
  activityScore: number; // 0-100
}

const HealthRings: React.FC<HealthRingsProps> = ({ riskScore, bpScore, activityScore }) => {
  const size = 160;
  const stroke = 14;
  const center = size / 2;
  const radii = [65, 48, 31];
  
  const getCircumference = (r: number) => 2 * Math.PI * r;
  
  const Ring = ({ r, progress, color, delay }: { r: number; progress: number; color: string; delay: string }) => {
    const c = getCircumference(r);
    const offset = c - (progress / 100) * c;
    
    return (
      <circle
        cx={center}
        cy={center}
        r={r}
        fill="transparent"
        stroke={color}
        strokeWidth={stroke}
        strokeDasharray={c}
        strokeDashoffset={c} // Start empty
        strokeLinecap="round"
        className="transition-all duration-1000 ease-out"
        style={{ 
          filter: `drop-shadow(0 0 4px ${color}44)`,
          animation: `fillRing 1.5s ${delay} forwards ease-in-out`
        }}
        transform={`rotate(-90 ${center} ${center})`}
      />
    );
  };

  const BackgroundRing = ({ r }: { r: number; key?: React.Key }) => (
    <circle
      cx={center}
      cy={center}
      r={r}
      fill="transparent"
      stroke="currentColor"
      strokeWidth={stroke}
      className="text-slate-100"
    />
  );

  return (
    <div className="relative inline-flex items-center justify-center">
      <svg width={size} height={size}>
        <style>
          {`
            @keyframes fillRing {
              to { stroke-dashoffset: var(--target-offset); }
            }
          `}
        </style>
        {radii.map((r, i) => <BackgroundRing key={`bg-${i}`} r={r} />)}
        
        <g style={{ ['--target-offset' as any]: getCircumference(radii[0]) - (Math.min(100, riskScore * 5) / 100) * getCircumference(radii[0]) }}>
           <Ring r={radii[0]} progress={Math.min(100, riskScore * 5)} color="#ff2d55" delay="0s" />
        </g>
        <g style={{ ['--target-offset' as any]: getCircumference(radii[1]) - (bpScore / 100) * getCircumference(radii[1]) }}>
           <Ring r={radii[1]} progress={bpScore} color="#34c759" delay="0.2s" />
        </g>
        <g style={{ ['--target-offset' as any]: getCircumference(radii[2]) - (activityScore / 100) * getCircumference(radii[2]) }}>
           <Ring r={radii[2]} progress={activityScore} color="#007aff" delay="0.4s" />
        </g>
      </svg>
      
      <div className="absolute flex flex-col items-center">
        <span className="text-2xl font-black text-slate-900 leading-none">{riskScore}%</span>
        <span className="text-[8px] font-black text-slate-400 uppercase tracking-widest mt-1">Risk</span>
      </div>
    </div>
  );
};

export default HealthRings;