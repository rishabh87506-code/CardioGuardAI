
import React from 'react';
import { HistoricalAssessment, SupportedLanguage } from '../types';
import { Calendar, ChevronRight, Trash2, History, ClipboardList, Sparkles, Lock, ShieldCheck } from 'lucide-react';
import SecurityVault from './SecurityVault';
import MedicalDisclaimer from './MedicalDisclaimer';

interface HistoryViewProps {
  history: HistoricalAssessment[];
  onSelect: (assessment: HistoricalAssessment) => void;
  onBack: () => void; // Added
  language: SupportedLanguage; // Added
  onClear: () => void;
  onDeleteOne: (id: string) => void;
  isVaultLocked: boolean;
  onToggleVault: (pass: string) => void;
}

const HistoryView: React.FC<HistoryViewProps> = ({ history, onBack, language, onSelect, onClear, onDeleteOne, isVaultLocked, onToggleVault }) => {
  const formatDate = (timestamp: number) => {
    return new Date(timestamp).toLocaleDateString(undefined, {
      month: 'short', day: 'numeric', year: 'numeric', hour: '2-digit', minute: '2-digit'
    });
  };

  const getCategoryColor = (cat: string) => {
    const colors = {
      'Low': 'text-emerald-600 border-emerald-100',
      'Moderate': 'text-amber-600 border-amber-100',
      'High': 'text-rose-600 border-rose-100',
      'Very High': 'text-red-700 border-red-200'
    };
    return colors[cat as keyof typeof colors] || 'text-slate-600 border-slate-100';
  };

  return (
    <div className="space-y-6 animate-in fade-in slide-in-from-bottom-4 duration-500">
      <SecurityVault isLocked={isVaultLocked} onToggle={onToggleVault} />

      <div className="flex items-center justify-between px-1">
        <h2 className="text-2xl font-black text-slate-900 flex items-center gap-2">
          <History className="w-6 h-6 text-blue-600" />
          Medical Archive
        </h2>
        {history.length > 0 && (
          <button
            onClick={onClear}
            className="text-[10px] font-black text-rose-600 hover:text-rose-700 tracking-widest uppercase px-3 py-2 rounded-lg hover:bg-rose-50 transition-all"
          >
            Clear Archive
          </button>
        )}
      </div>

      {history.length === 0 ? (
        <div className="flex flex-col items-center justify-center py-16 text-center space-y-4 bg-white rounded-3xl border border-dashed border-slate-200">
          <ClipboardList className="w-12 h-12 text-slate-300" />
          <div>
            <h3 className="text-lg font-bold text-slate-900">Archive Empty</h3>
            <p className="text-sm text-slate-500 mt-1 max-w-[200px]">Perform your first analysis to begin tracking your heart health.</p>
          </div>
        </div>
      ) : (
        <div className="space-y-4">
          {history.map((item, index) => {
            const isLatest = index === 0;
            return (
              <div
                key={item.id}
                className={`group relative bg-white border rounded-[2rem] p-5 shadow-sm transition-all cursor-pointer flex items-center gap-5 ${isVaultLocked ? 'opacity-70 blur-[1px]' : 'hover:shadow-xl hover:border-blue-200'
                  } ${isLatest && !isVaultLocked ? 'border-blue-600 ring-4 ring-blue-600/5' : 'border-slate-100'}`}
                onClick={() => !isVaultLocked && onSelect(item)}
              >
                {isLatest && !isVaultLocked && (
                  <div className="absolute -top-3 left-8 bg-blue-600 text-white text-[9px] font-black px-3 py-1 rounded-full shadow-lg flex items-center gap-1.5 z-10">
                    <Sparkles className="w-3 h-3" />
                    LATEST SCAN
                  </div>
                )}

                {isVaultLocked ? (
                  <div className="w-12 h-12 bg-slate-50 rounded-2xl flex items-center justify-center shrink-0 border border-slate-100">
                    <Lock className="w-6 h-6 text-slate-300" />
                  </div>
                ) : (
                  <div className={`w-14 h-14 rounded-2xl flex items-center justify-center shrink-0 font-black text-xl bg-slate-50 border ${getCategoryColor(item.riskCategory)}`}>
                    {item.riskScore}%
                  </div>
                )}

                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 mb-1">
                    <span className={`text-[10px] font-black uppercase tracking-wider px-2 py-0.5 rounded-full border bg-white ${isVaultLocked ? 'text-slate-400 border-slate-100' : getCategoryColor(item.riskCategory)}`}>
                      {isVaultLocked ? 'ENCRYPTED' : item.riskCategory}
                    </span>
                    <span className="text-[10px] font-bold text-slate-400 flex items-center gap-1">
                      <Calendar className="w-3 h-3" />
                      {formatDate(item.timestamp)}
                    </span>
                  </div>
                  <h4 className="text-sm font-black text-slate-800 truncate">
                    {isVaultLocked ? "••••••••••••••••" : `${item.vitals.age}y ${item.vitals.gender} • BP ${item.vitals.systolicBP}/${item.vitals.diastolicBP} • SpO2 ${item.vitals.spO2}%`}
                  </h4>
                </div>

                {!isVaultLocked && (
                  <div className="flex items-center gap-1">
                    <button
                      onClick={(e) => { e.stopPropagation(); onDeleteOne(item.id); }}
                      className="opacity-0 group-hover:opacity-100 p-2 text-slate-300 hover:text-rose-500 transition-all rounded-full hover:bg-rose-50"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                    <ChevronRight className="w-6 h-6 text-slate-300 group-hover:text-slate-900 transition-colors" />
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}

      <div className="p-4 bg-white rounded-2xl border border-slate-100 flex items-center gap-3">
        <ShieldCheck className="w-5 h-5 text-blue-600 shrink-0" />
        <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest leading-relaxed">
          Powered by TCH Advanced Encryption & Core Health Data Engine
        </p>
      </div>

      <MedicalDisclaimer />
    </div>
  );
};

export default HistoryView;
