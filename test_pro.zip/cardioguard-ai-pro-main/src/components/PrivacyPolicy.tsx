import React from 'react';
import { Shield, Heart, Lock, Database, Mail, AlertTriangle, CheckCircle } from 'lucide-react';

const PrivacyPolicy: React.FC<{ onBack: () => void }> = ({ onBack }) => {
    return (
        <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-purple-50 py-12 px-4 sm:px-6 lg:px-8">
            <div className="max-w-4xl mx-auto">
                {/* Header */}
                <div className="text-center mb-12">
                    <button
                        onClick={onBack}
                        className="mb-6 inline-flex items-center text-blue-600 hover:text-blue-800 transition-colors"
                    >
                        ← Back to App
                    </button>
                    <div className="flex justify-center mb-4">
                        <Shield className="w-16 h-16 text-purple-600" />
                    </div>
                    <h1 className="text-4xl font-bold text-slate-900 mb-4">Privacy Policy</h1>
                    <p className="text-slate-600">Last Updated: February 9, 2026</p>
                </div>

                {/* Content */}
                <div className="bg-white/80 backdrop-blur-sm rounded-2xl shadow-xl p-8 space-y-8">

                    {/* Introduction */}
                    <section>
                        <h2 className="text-2xl font-semibold text-slate-900 mb-4 flex items-center gap-2">
                            <Heart className="w-6 h-6 text-red-500" />
                            Introduction
                        </h2>
                        <p className="text-slate-700 leading-relaxed">
                            CardioGuard AI ("we," "our," or "us") is committed to protecting your privacy and ensuring the security of your personal health information. This Privacy Policy explains how we collect, use, disclose, and safeguard your information when you use our cardiovascular health assessment platform.
                        </p>
                    </section>

                    {/* Data Collection */}
                    <section>
                        <h2 className="text-2xl font-semibold text-slate-900 mb-4 flex items-center gap-2">
                            <Database className="w-6 h-6 text-blue-500" />
                            Information We Collect
                        </h2>
                        <div className="space-y-4">
                            <div className="bg-blue-50 p-4 rounded-lg">
                                <h3 className="font-semibold text-slate-900 mb-2">Health Data</h3>
                                <ul className="list-disc list-inside text-slate-700 space-y-1">
                                    <li>Vital signs (blood pressure, heart rate, oxygen levels)</li>
                                    <li>Medical imaging data (ECG scans, cardiac images)</li>
                                    <li>rPPG camera-based measurements</li>
                                    <li>Self-reported symptoms and health history</li>
                                    <li>Wearable device data (when connected)</li>
                                </ul>
                            </div>
                            <div className="bg-purple-50 p-4 rounded-lg">
                                <h3 className="font-semibold text-slate-900 mb-2">Technical Data</h3>
                                <ul className="list-disc list-inside text-slate-700 space-y-1">
                                    <li>Device information and browser type</li>
                                    <li>IP address and location data</li>
                                    <li>Usage patterns and interaction data</li>
                                    <li>Session information and cookies</li>
                                </ul>
                            </div>
                        </div>
                    </section>

                    {/* Data Storage */}
                    <section>
                        <h2 className="text-2xl font-semibold text-slate-900 mb-4 flex items-center gap-2">
                            <Lock className="w-6 h-6 text-green-500" />
                            Data Storage & Security
                        </h2>
                        <div className="bg-green-50 p-4 rounded-lg space-y-3">
                            <p className="text-slate-700">
                                <strong>Local Storage:</strong> Your health data is primarily stored locally on your device using encrypted browser storage. We use AES-256 encryption to protect your sensitive information.
                            </p>
                            <p className="text-slate-700">
                                <strong>Cloud Processing:</strong> When you use AI-powered features, anonymized data may be processed through secure cloud services (Google Gemini API) with end-to-end encryption.
                            </p>
                            <p className="text-slate-700">
                                <strong>HIPAA Compliance:</strong> Our platform is designed with HIPAA-compliant security standards to protect your protected health information (PHI).
                            </p>
                        </div>
                    </section>

                    {/* GDPR Rights */}
                    <section>
                        <h2 className="text-2xl font-semibold text-slate-900 mb-4 flex items-center gap-2">
                            <CheckCircle className="w-6 h-6 text-purple-500" />
                            Your Rights (GDPR)
                        </h2>
                        <div className="grid md:grid-cols-2 gap-4">
                            {[
                                { title: 'Right to Access', desc: 'Request copies of your personal data' },
                                { title: 'Right to Rectification', desc: 'Correct inaccurate or incomplete data' },
                                { title: 'Right to Erasure', desc: 'Request deletion of your data' },
                                { title: 'Right to Portability', desc: 'Receive your data in a portable format' },
                                { title: 'Right to Object', desc: 'Object to processing of your data' },
                                { title: 'Right to Restrict', desc: 'Limit how we use your data' },
                            ].map((right, i) => (
                                <div key={i} className="bg-slate-50 p-3 rounded-lg">
                                    <h4 className="font-semibold text-slate-900">{right.title}</h4>
                                    <p className="text-sm text-slate-600">{right.desc}</p>
                                </div>
                            ))}
                        </div>
                    </section>

                    {/* Third Parties */}
                    <section>
                        <h2 className="text-2xl font-semibold text-slate-900 mb-4 flex items-center gap-2">
                            <AlertTriangle className="w-6 h-6 text-amber-500" />
                            Third-Party Services
                        </h2>
                        <p className="text-slate-700 mb-4">
                            We may share anonymized, non-identifiable data with:
                        </p>
                        <ul className="list-disc list-inside text-slate-700 space-y-2">
                            <li><strong>Google Gemini API:</strong> For AI-powered health assessments</li>
                            <li><strong>Vercel:</strong> For hosting and infrastructure</li>
                            <li><strong>Analytics providers:</strong> For improving our service (anonymized)</li>
                        </ul>
                    </section>

                    {/* Data Sharing Protocol */}
                    <section>
                        <h2 className="text-2xl font-semibold text-slate-900 mb-4 flex items-center gap-2">
                            <Shield className="w-6 h-6 text-cyan-600" />
                            Data Sharing Protocol: CONSENT-ONLY
                        </h2>
                        <div className="bg-cyan-50 border border-cyan-100 p-6 rounded-2xl">
                            <p className="text-slate-800 font-bold leading-relaxed mb-4">
                                ABSOLUTE ZERO SHARING: We do not sell, rent, or lease your personal health data to third parties. Your data remains your property.
                            </p>
                            <p className="text-slate-700 text-sm leading-relaxed">
                                Information is only shared with clinical partners or emergency services when EXPLICITLY triggered by you (e.g., Physician Handover or SOS Dispatch). Anonymized metrics may be used to improve algorithmic accuracy (99.1% target), but never linked back to your identity without your prior authorization.
                            </p>
                        </div>
                    </section>

                </div>

                {/* Footer */}
                <div className="text-center mt-8 text-slate-500 text-sm">
                    <p>© 2026 CardioGuard AI. All rights reserved.</p>
                    <p className="mt-2">This policy is effective as of February 9, 2026</p>
                </div>
            </div>
        </div>
    );
};

export default PrivacyPolicy;
