
import React, { useState, useEffect } from 'react';
import {
    AlertTriangle, ShieldAlert, HeartPulse,
    FileWarning, Phone, MapPin, Clock, CheckCircle2
} from 'lucide-react';
import { useSearchParams } from 'react-router-dom';
import { verifyAccessToken } from '../services/supabaseService';
import { AccessGrant } from '../types';

const EmergencyAccess: React.FC = () => {
    const [searchParams] = useSearchParams();
    const token = searchParams.get('token');

    const [grant, setGrant] = useState<AccessGrant | null>(null);
    const [isLoading, setIsLoading] = useState(true);
    const [error, setError] = useState<string | null>(null);

    // Mock data for demo
    const emergencyData = {
        name: "Alex Doe",
        dob: "1980-05-15",
        bloodType: "O+",
        allergies: ["Penicillin", "Peanuts"],
        conditions: ["Hypertension", "Asthma"],
        medications: [
            { name: "Lisinopril", dose: "10mg", freq: "Daily" },
            { name: "Albuterol", dose: "90mcg", freq: "As needed" }
        ],
        emergencyContact: {
            name: "Jane Doe",
            relation: "Spouse",
            phone: "+1 (555) 123-4567"
        }
    };

    useEffect(() => {
        const checkAccess = async () => {
            if (!token) {
                setError("No access token provided.");
                setIsLoading(false);
                return;
            }

            try {
                // In a real app, verify against Supabase
                // const validGrant = await verifyAccessToken(token);
                // For demo, we simulate success if token exists

                await new Promise(r => setTimeout(r, 1000)); // Simulate net delay

                if (token.length > 5) {
                    setGrant({
                        id: 'emergency-grant',
                        patientId: 'user-123',
                        token: token,
                        accessType: 'EMERGENCY',
                        expiresAt: Date.now() + 3600000
                    });
                } else {
                    setError("Invalid or expired emergency token.");
                }
            } catch (err) {
                setError("System error verifying access.");
            } finally {
                setIsLoading(false);
            }
        };

        checkAccess();
    }, [token]);

    if (isLoading) {
        return (
            <div className="min-h-screen bg-slate-950 flex flex-col items-center justify-center text-white">
                <HeartPulse className="w-16 h-16 text-red-600 animate-pulse" />
                <p className="mt-4 text-xs font-black uppercase tracking-[0.3em]">Establishing Secure Link...</p>
            </div>
        );
    }

    if (error || !grant) {
        return (
            <div className="min-h-screen bg-slate-50 flex flex-col items-center justify-center p-6 text-center">
                <div className="w-20 h-20 bg-rose-100 rounded-full flex items-center justify-center mb-6">
                    <ShieldAlert className="w-10 h-10 text-rose-600" />
                </div>
                <h1 className="text-2xl font-black text-slate-900">Access Denied</h1>
                <p className="text-slate-500 font-bold mt-2">{error || "Unauthorized access attempt logged."}</p>
            </div>
        );
    }

    return (
        <div className="min-h-screen bg-slate-50 pb-12 animate-in fade-in">
            {/* Critical Header */}
            <div className="bg-rose-600 text-white p-6 pb-12 rounded-b-[3rem] shadow-xl relative overflow-hidden">
                <div className="absolute top-0 right-0 p-6 opacity-20">
                    <AlertTriangle className="w-32 h-32" />
                </div>
                <div className="max-w-3xl mx-auto relative z-10">
                    <div className="flex items-center gap-3 mb-4">
                        <div className="p-2 bg-white/20 rounded-lg backdrop-blur-md">
                            <HeartPulse className="w-6 h-6 text-white" />
                        </div>
                        <span className="text-[10px] font-black uppercase tracking-[0.3em]">First Responder View</span>
                    </div>
                    <h1 className="text-4xl font-black tracking-tight mb-2">{emergencyData.name}</h1>
                    <div className="flex flex-wrap gap-4 text-sm font-bold opacity-90">
                        <span className="flex items-center gap-1"><Calendar /> DOB: {emergencyData.dob}</span>
                        <span className="flex items-center gap-1">Blood: {emergencyData.bloodType}</span>
                    </div>
                </div>
            </div>

            <div className="max-w-3xl mx-auto -mt-8 px-6 space-y-6">
                {/* Critical Alerts Card */}
                <div className="bg-white p-6 rounded-3xl shadow-lg border-l-8 border-rose-500 flex flex-col md:flex-row gap-6">
                    <div className="flex-1 space-y-3">
                        <h3 className="text-xs font-black text-rose-600 uppercase tracking-widest flex items-center gap-2">
                            <FileWarning className="w-4 h-4" /> Critical Allergies
                        </h3>
                        <div className="flex flex-wrap gap-2">
                            {emergencyData.allergies.map(a => (
                                <span key={a} className="px-3 py-1 bg-rose-50 text-rose-700 rounded-lg text-sm font-black border border-rose-100">
                                    {a}
                                </span>
                            ))}
                        </div>
                    </div>
                    <div className="w-px bg-slate-100 hidden md:block" />
                    <div className="flex-1 space-y-3">
                        <h3 className="text-xs font-black text-amber-600 uppercase tracking-widest flex items-center gap-2">
                            <Activity className="w-4 h-4" /> Conditions
                        </h3>
                        <div className="flex flex-wrap gap-2">
                            {emergencyData.conditions.map(c => (
                                <span key={c} className="px-3 py-1 bg-amber-50 text-amber-700 rounded-lg text-sm font-black border border-amber-100">
                                    {c}
                                </span>
                            ))}
                        </div>
                    </div>
                </div>

                {/* Medications */}
                <div className="bg-white p-6 rounded-3xl shadow-sm border border-slate-100">
                    <h3 className="text-lg font-black text-slate-900 mb-4 flex items-center gap-2">
                        <Pill className="w-5 h-5 text-blue-600" /> Active Medications
                    </h3>
                    <div className="space-y-3">
                        {emergencyData.medications.map((m, i) => (
                            <div key={i} className="flex justify-between items-center p-3 bg-slate-50 rounded-xl border border-slate-100">
                                <div>
                                    <p className="font-black text-slate-800">{m.name}</p>
                                    <p className="text-xs font-bold text-slate-500">{m.dose}</p>
                                </div>
                                <span className="text-[10px] font-black uppercase tracking-widest text-blue-600 bg-blue-50 px-2 py-1 rounded-lg">
                                    {m.freq}
                                </span>
                            </div>
                        ))}
                    </div>
                </div>

                {/* Emergency Contact */}
                <a href={`tel:${emergencyData.emergencyContact.phone}`} className="block">
                    <div className="bg-emerald-600 text-white p-6 rounded-3xl shadow-lg flex items-center justify-between hover:bg-emerald-500 transition-colors cursor-pointer">
                        <div>
                            <p className="text-[10px] font-black uppercase tracking-widest opacity-80 mb-1">Emergency Contact</p>
                            <h3 className="text-2xl font-black">{emergencyData.emergencyContact.name}</h3>
                            <p className="text-sm font-bold opacity-90">{emergencyData.emergencyContact.relation}</p>
                        </div>
                        <div className="w-12 h-12 bg-white/20 rounded-full flex items-center justify-center backdrop-blur-sm">
                            <Phone className="w-6 h-6 text-white" />
                        </div>
                    </div>
                </a>

                <div className="text-center pt-8 pb-4">
                    <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">
                        Secure Emergency Access • Session ID: {grant.token}
                    </p>
                    <p className="text-[9px] font-bold text-slate-300 mt-1">
                        Access is monitored and logged. Unauthorized use is a federal offense.
                    </p>
                </div>
            </div>
        </div>
    );
};

// Missing icons helper
function Calendar() { return <Clock className="w-3 h-3" /> }
import { Pill, Activity } from 'lucide-react'; // Ensure imports

export default EmergencyAccess;
