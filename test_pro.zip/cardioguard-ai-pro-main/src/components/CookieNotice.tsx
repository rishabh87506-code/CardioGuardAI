import React, { useState, useEffect } from 'react';
import { Cookie, X, Settings, CheckCircle } from 'lucide-react';

interface CookiePreferences {
    necessary: boolean;
    analytics: boolean;
    marketing: boolean;
}

const CookieNotice: React.FC = () => {
    const [showBanner, setShowBanner] = useState(false);
    const [showSettings, setShowSettings] = useState(false);
    const [preferences, setPreferences] = useState<CookiePreferences>({
        necessary: true,
        analytics: false,
        marketing: false,
    });

    useEffect(() => {
        const consent = localStorage.getItem('cardioguard_cookie_consent');
        if (!consent) {
            setShowBanner(true);
        }
    }, []);

    const acceptAll = () => {
        const consent = { necessary: true, analytics: true, marketing: true, timestamp: Date.now() };
        localStorage.setItem('cardioguard_cookie_consent', JSON.stringify(consent));
        setShowBanner(false);
    };

    const acceptNecessary = () => {
        const consent = { necessary: true, analytics: false, marketing: false, timestamp: Date.now() };
        localStorage.setItem('cardioguard_cookie_consent', JSON.stringify(consent));
        setShowBanner(false);
    };

    const savePreferences = () => {
        const consent = { ...preferences, timestamp: Date.now() };
        localStorage.setItem('cardioguard_cookie_consent', JSON.stringify(consent));
        setShowBanner(false);
        setShowSettings(false);
    };

    if (!showBanner) return null;

    return (
        <>
            {/* Cookie Banner */}
            <div className="fixed bottom-0 left-0 right-0 z-50 p-4 bg-slate-900/95 backdrop-blur-lg border-t border-slate-700 shadow-2xl">
                <div className="max-w-6xl mx-auto">
                    <div className="flex flex-col md:flex-row items-start md:items-center gap-4">
                        {/* Icon & Text */}
                        <div className="flex items-start gap-3 flex-1">
                            <div className="bg-purple-500/20 p-2 rounded-lg">
                                <Cookie className="w-6 h-6 text-purple-400" />
                            </div>
                            <div>
                                <h3 className="text-white font-semibold mb-1">🍪 Cookie Preferences</h3>
                                <p className="text-slate-300 text-sm leading-relaxed">
                                    We use cookies to enhance your experience, analyze site traffic, and for personalized content.
                                    Your health data is never shared through cookies.
                                    <button
                                        onClick={() => setShowSettings(true)}
                                        className="text-purple-400 hover:text-purple-300 ml-1 underline"
                                    >
                                        Manage preferences
                                    </button>
                                </p>
                            </div>
                        </div>

                        {/* Buttons */}
                        <div className="flex gap-3 flex-shrink-0">
                            <button
                                onClick={acceptNecessary}
                                className="px-4 py-2 text-sm font-medium text-slate-300 bg-slate-700 hover:bg-slate-600 rounded-lg transition-colors"
                            >
                                Necessary Only
                            </button>
                            <button
                                onClick={acceptAll}
                                className="px-4 py-2 text-sm font-medium text-white bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700 rounded-lg transition-colors flex items-center gap-2"
                            >
                                <CheckCircle className="w-4 h-4" />
                                Accept All
                            </button>
                        </div>
                    </div>
                </div>
            </div>

            {/* Settings Modal */}
            {showSettings && (
                <div className="fixed inset-0 z-[60] flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm">
                    <div className="bg-white rounded-2xl shadow-2xl max-w-md w-full max-h-[90vh] overflow-y-auto">
                        {/* Header */}
                        <div className="flex items-center justify-between p-6 border-b">
                            <div className="flex items-center gap-3">
                                <Settings className="w-6 h-6 text-purple-600" />
                                <h2 className="text-xl font-semibold text-slate-900">Cookie Settings</h2>
                            </div>
                            <button
                                onClick={() => setShowSettings(false)}
                                className="text-slate-400 hover:text-slate-600"
                            >
                                <X className="w-6 h-6" />
                            </button>
                        </div>

                        {/* Content */}
                        <div className="p-6 space-y-4">
                            {/* Necessary Cookies */}
                            <div className="flex items-start justify-between p-4 bg-green-50 rounded-lg">
                                <div>
                                    <h3 className="font-semibold text-slate-900">Necessary Cookies</h3>
                                    <p className="text-sm text-slate-600 mt-1">
                                        Essential for the website to function. Cannot be disabled.
                                    </p>
                                </div>
                                <div className="bg-green-500 text-white text-xs px-2 py-1 rounded">Required</div>
                            </div>

                            {/* Analytics Cookies */}
                            <div className="flex items-start justify-between p-4 bg-slate-50 rounded-lg">
                                <div>
                                    <h3 className="font-semibold text-slate-900">Analytics Cookies</h3>
                                    <p className="text-sm text-slate-600 mt-1">
                                        Help us understand how visitors interact with our website.
                                    </p>
                                </div>
                                <label className="relative inline-flex items-center cursor-pointer">
                                    <input
                                        type="checkbox"
                                        checked={preferences.analytics}
                                        onChange={(e) => setPreferences({ ...preferences, analytics: e.target.checked })}
                                        className="sr-only peer"
                                    />
                                    <div className="w-11 h-6 bg-slate-300 peer-focus:outline-none peer-focus:ring-2 peer-focus:ring-purple-300 rounded-full peer peer-checked:bg-purple-600 after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:after:translate-x-full"></div>
                                </label>
                            </div>

                            {/* Marketing Cookies */}
                            <div className="flex items-start justify-between p-4 bg-slate-50 rounded-lg">
                                <div>
                                    <h3 className="font-semibold text-slate-900">Marketing Cookies</h3>
                                    <p className="text-sm text-slate-600 mt-1">
                                        Used to deliver personalized advertisements.
                                    </p>
                                </div>
                                <label className="relative inline-flex items-center cursor-pointer">
                                    <input
                                        type="checkbox"
                                        checked={preferences.marketing}
                                        onChange={(e) => setPreferences({ ...preferences, marketing: e.target.checked })}
                                        className="sr-only peer"
                                    />
                                    <div className="w-11 h-6 bg-slate-300 peer-focus:outline-none peer-focus:ring-2 peer-focus:ring-purple-300 rounded-full peer peer-checked:bg-purple-600 after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:after:translate-x-full"></div>
                                </label>
                            </div>

                            {/* GDPR Notice */}
                            <div className="text-xs text-slate-500 mt-4">
                                <p>
                                    Your choices are saved locally and comply with GDPR regulations.
                                    You can change your preferences at any time.
                                    <a href="/privacy-policy" className="text-purple-600 hover:underline ml-1">
                                        Read our Privacy Policy
                                    </a>
                                </p>
                            </div>
                        </div>

                        {/* Footer */}
                        <div className="flex gap-3 p-6 border-t">
                            <button
                                onClick={() => setShowSettings(false)}
                                className="flex-1 px-4 py-2 text-sm font-medium text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-lg transition-colors"
                            >
                                Cancel
                            </button>
                            <button
                                onClick={savePreferences}
                                className="flex-1 px-4 py-2 text-sm font-medium text-white bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700 rounded-lg transition-colors"
                            >
                                Save Preferences
                            </button>
                        </div>
                    </div>
                </div>
            )}
        </>
    );
};

export default CookieNotice;
