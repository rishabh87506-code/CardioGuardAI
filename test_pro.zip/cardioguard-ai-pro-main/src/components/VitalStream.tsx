import React, { useState, useEffect } from 'react';
import {
  Sparkles,
  Flame,
  Activity,
  Heart,
  ChevronRight,
  Trophy,
  ArrowRight,
  RefreshCw,
  ShieldCheck,
  Sun,
  Brain,
  Utensils,
  Stethoscope,
  Zap,
  Users
} from 'lucide-react';
import { GoogleGenAI } from '@google/genai';
import { HistoricalAssessment, ViewState, SupportedLanguage, VitalsData } from '../types';
import { connectHeartRateMonitor, onVitalsUpdate, isBluetoothSupported } from '../services/wearableService';

interface VitalStreamProps {
  history: HistoricalAssessment[];
  onNavigate: (view: string) => void;
  language: SupportedLanguage;
  onBack: () => void;
  storageMode: 'cloud' | 'local';
  fusionStatus?: any;
}

const VitalStream: React.FC<VitalStreamProps> = ({ history, onNavigate, language, onBack, storageMode, fusionStatus }) => {
  const [dailyInsight, setDailyInsight] = useState<string | null>(null);
  const [isLoadingInsight, setIsLoadingInsight] = useState(false);
  const [streak, setStreak] = useState(0);

  // Live Wearable State
  const [liveHeartRate, setLiveHeartRate] = useState<number | null>(null);
  const [isConnecting, setIsConnecting] = useState(false);
  const [deviceConnected, setDeviceConnected] = useState(false);



  useEffect(() => {
    if (history.length > 0) {
      const now = Date.now();
      const oneDay = 24 * 60 * 60 * 1000;
      const recentDates = new Set(
        history
          .filter(h => now - h.timestamp < 7 * oneDay)
          .map(h => new Date(h.timestamp).toDateString())
      );
      setStreak(recentDates.size);
    } else {
      setStreak(0);
    }
  }, [history]);

  useEffect(() => {
    const fetchInsight = async () => {
      if (history.length === 0) {
        setDailyInsight("Initialize your clinical profile to receive AI-powered health intelligence and proactive guidance.");
        return;
      }

      setIsLoadingInsight(true);
      try {
        const last = history[0];
        const ai = new GoogleGenAI({ apiKey: import.meta.env.VITE_GEMINI_API_KEY });
        const prompt = `Based on a patient with a ${last.riskCategory} cardiovascular risk and a score of ${last.riskScore}%, 
        provide a concise 2-sentence clinical morning health tip in ${language}. 
        Tone: Professional, authoritative, yet supportive. 
        Focus: One area among heart-rate variability, hydration, or nitric oxide-rich foods. 
        Strictly refer to the system as CardioGuard.`;

        const response = await ai.models.generateContent({
          model: 'gemini-1.5-flash',
          contents: [{ role: 'user', parts: [{ text: prompt }] }],
        });

        const text = typeof (response as any).text === 'function'
          ? (response as any).text()
          : (response as any).response?.text?.();

        setDailyInsight(text || "Optimal rhythm detected. Maintain consistent monitoring.");
      } catch (e) {
        setDailyInsight("Consistency is the foundation of cardiac health. Your commitment to monitoring is your best preventive measure.");
      } finally {
        setIsLoadingInsight(false);
      }
    };

    fetchInsight();
    fetchInsight();
  }, [history, language]);

  // Wearable Connection Handler
  const handleConnect = async () => {
    if (!isBluetoothSupported()) {
      alert("Bluetooth not supported in this browser.");
      return;
    }
    setIsConnecting(true);
    try {
      const device = await connectHeartRateMonitor();
      if (device) {
        setDeviceConnected(true);
        onVitalsUpdate((data) => {
          if (data.heartRate) setLiveHeartRate(data.heartRate);
        });
      }
    } catch (e) {
      console.error(e);
    } finally {
      setIsConnecting(false);
    }
  };

  const feedItems = [
    {
      id: 1,
      type: 'NUTRITION',
      title: 'Lipid Stability Protocol',
      desc: 'Optimizing omega-3 intake for arterial inflammation reduction.',
      icon: Utensils,
      color: 'text-emerald-600',
      bg: 'bg-emerald-50',
      target: ViewState.SCAN
    },
    {
      id: 2,
      type: 'PHYSIOLOGY',
      title: 'Zone 2 Metabolic Efficiency',
      desc: 'Brisk aerobic sessions as a primary driver for mitochondrial repair.',
      icon: Activity,
      color: 'text-blue-600',
      bg: 'bg-blue-50',
      target: ViewState.SCAN
    }
  ];

  return (
    <div className="space-y-8 animate-in fade-in zoom-in duration-500 pb-12">

      {/* REFINED CLINICAL HERO - RECTIFIED SCHEME */}
      <div className="relative rounded-[3rem] overflow-hidden border border-sky-100 bg-gradient-to-br from-white via-sky-50 to-white shadow-sm group">
        <div className="relative z-10 p-10 md:p-16 flex flex-col md:flex-row items-center gap-16">
          <div className="text-center md:text-left space-y-8 flex-1">
            <div className="space-y-4">
              <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-cyan-100/50 border border-cyan-200 text-cyan-700 text-[10px] font-black uppercase tracking-[0.4em] mb-4">
                <Sparkles className="w-3.5 h-3.5" /> High Precision Cardiac Care
              </div>
              <h1 className="text-3xl md:text-7xl font-black tracking-tighter text-slate-800 leading-[0.9]">
                CardioGuard <span className="text-cyan-600">AI</span>
              </h1>
              <p className="text-slate-500 font-medium text-lg md:text-xl max-w-xl leading-relaxed">
                Empowering your heart health with advanced clinical intelligence and proactive analysis.
              </p>
            </div>

            <div className="flex flex-wrap justify-center md:justify-start gap-4">
              <button
                onClick={handleConnect}
                disabled={deviceConnected || isConnecting}
                className={`px-8 py-5 bg-cyan-600 text-white rounded-[1.25rem] font-black text-xs uppercase tracking-widest hover:bg-cyan-500 transition-all flex items-center gap-3 shadow-xl shadow-cyan-600/20 group ${deviceConnected ? 'opacity-50 cursor-default' : ''}`}
              >
                {isConnecting ? 'Scanning...' : deviceConnected ? 'Monitor Active' : 'Connect Wearable'}
                {!deviceConnected && !isConnecting && <Activity className="w-4 h-4 group-hover:scale-110 transition-transform" />}
              </button>
              <button
                onClick={() => onNavigate('trends')}
                className="px-8 py-5 bg-white border border-sky-100 text-slate-600 rounded-[1.25rem] font-black text-xs uppercase tracking-widest hover:bg-sky-50 transition-all"
              >
                View History
              </button>
            </div>
          </div>

          <div className="hidden lg:block w-72 h-72 relative">
            <div className="absolute inset-0 bg-cyan-100 blur-3xl rounded-full opacity-50"></div>
            <div className={`relative w-full h-full border border-sky-100 bg-white/80 backdrop-blur-xl rounded-full flex items-center justify-center shadow-lg transition-all ${liveHeartRate ? 'scale-110 border-cyan-200' : ''}`}>
              {liveHeartRate ? (
                <div className="text-center">
                  <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1">Live BPM</p>
                  <span className="text-6xl font-black text-slate-800 tracking-tighter animate-pulse">{liveHeartRate}</span>
                </div>
              ) : (
                <Heart className="w-32 h-32 text-cyan-600 fill-cyan-50 stroke-[2.5] animate-heartbeat" />
              )}
            </div>
          </div>
        </div>
      </div>

      {/* REFINED CLINICAL HUB - REAL SYSTEM STATUS */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <div className="md:col-span-3 bg-white rounded-[2.5rem] border border-sky-100 p-8 shadow-sm">
          <div className="flex items-center justify-between mb-8">
            <div className="flex items-center gap-3">
              <div className={`w-2 h-2 rounded-full ${deviceConnected ? 'bg-emerald-500 animate-pulse' : 'bg-slate-300'}`}></div>
              <h3 className="text-[10px] font-black text-slate-400 uppercase tracking-[0.3em]">System Status Node</h3>
            </div>
            <span className="text-[9px] font-bold text-slate-400 uppercase tracking-widest">{deviceConnected ? 'Data Stream Active' : 'Standby Mode'}</span>
          </div>

          <div className="flex items-center gap-6 p-5 bg-sky-50/30 rounded-2xl border border-sky-50">
            <div className={`p-3 rounded-2xl ${deviceConnected ? 'bg-emerald-50 text-emerald-600' : 'bg-slate-100 text-slate-400'}`}>
              <Activity className="w-6 h-6" />
            </div>
            <div>
              <p className="text-[10px] font-black uppercase tracking-widest text-slate-400 mb-1">{deviceConnected ? 'LIVE FEED MONITOR' : 'SYSEM NOTIFICATION'}</p>
              <p className="text-base font-bold text-slate-700">
                {deviceConnected
                  ? "Real-time biometric data is being encrypted and analyzed by the CardioGuard Neural Engine."
                  : "Connect a supported wearable device to begin real-time telemetry streaming."}
              </p>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-[2.5rem] border border-sky-100 p-8 flex flex-col justify-center items-center text-center gap-4 shadow-sm">
          <div className="p-4 bg-amber-50 rounded-2xl border border-amber-100">
            <Flame className="w-8 h-8 text-amber-500" />
          </div>
          <div>
            <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1">Health Streak</p>
            <p className="text-4xl font-black text-slate-800 tracking-tighter">{streak} DAYS</p>
          </div>
        </div>
      </div>

      <div className="space-y-6">
        <div className="flex items-center justify-between px-2">
          <h3 className="flex items-center gap-3 text-lg font-black text-slate-800 uppercase tracking-wider">
            <Sparkles className="w-5 h-5 text-cyan-600" /> Clinical Focus Protocols
          </h3>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {feedItems.concat([
            {
              id: 3,
              type: 'DIAGNOSTICS',
              title: 'Autonomic Signal Sweep',
              desc: 'Deep analysis of HRV and sympathetic neural balance indices.',
              icon: Zap,
              color: 'text-cyan-600',
              bg: 'bg-cyan-50',
              target: ViewState.SCAN
            }
          ]).map(item => (
            <div
              key={item.id}
              className="group relative bg-white border border-sky-50 rounded-[2rem] p-8 hover:border-cyan-200 transition-all duration-300 cursor-pointer overflow-hidden shadow-sm hover:shadow-md"
              onClick={() => onNavigate(item.target)}
            >
              <div className={`w-14 h-14 rounded-2xl ${item.bg} flex items-center justify-center mb-6 transition-transform group-hover:rotate-6`}>
                <item.icon className={`w-7 h-7 ${item.color}`} />
              </div>

              <div className="space-y-3">
                <span className={`text-[10px] font-black uppercase tracking-[0.2em] ${item.color}`}>
                  {item.type}
                </span>
                <div>
                  <h4 className="text-xl font-bold text-slate-800 mb-2 group-hover:text-cyan-600 transition-colors">
                    {item.title}
                  </h4>
                  <p className="text-sm text-slate-500 font-medium leading-relaxed">
                    {item.desc}
                  </p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default VitalStream;
