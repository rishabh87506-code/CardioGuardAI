
import React, { useState, useEffect } from 'react';
import {
    Bluetooth, Watch, Activity, RefreshCw, Smartphone, Check, X,
    Heart, Battery, Zap, Signal, AlertCircle, CheckCircle2, BluetoothConnected, BluetoothSearching, BluetoothOff, Droplets
} from 'lucide-react';
import {
    isBluetoothSupported,
    connectHeartRateMonitor,
    connectBloodPressureMonitor,
    connectPulseOximeter,
    getConnectedDevices,
    disconnectDevice,
    onVitalsUpdate,
    onDeviceConnection,
    onWearableError,
    startWearableSimulation,
    WearableDevice,
    VitalsReading
} from '../services/wearableService';
import { SupportedLanguage } from '../types';

interface WearableConnectorProps {
    onBack: () => void;
    language: SupportedLanguage;
    compact?: boolean;
}

const WearableConnector: React.FC<WearableConnectorProps> = ({ onBack, language, compact = false }) => {
    const [supported, setSupported] = useState(true);
    const [scanning, setScanning] = useState(false);
    const [devices, setDevices] = useState<WearableDevice[]>([]);
    const [latestVitals, setLatestVitals] = useState<VitalsReading | null>(null);
    const [error, setError] = useState<string | null>(null);
    const [simulationActive, setSimulationActive] = useState(false);
    const [stopSimulation, setStopSimulation] = useState<(() => void) | null>(null);

    useEffect(() => {
        setSupported(isBluetoothSupported());

        // Subscribe to vitals updates
        const unsubVitals = onVitalsUpdate((reading) => {
            setLatestVitals(reading);
        });

        // Subscribe to device connections
        const unsubConnection = onDeviceConnection((device) => {
            setDevices(getConnectedDevices());
        });

        // Subscribe to errors
        const unsubError = onWearableError((err) => {
            setError(err);
            setTimeout(() => setError(null), 5000);
        });

        // Initial device list
        setDevices(getConnectedDevices());

        return () => {
            unsubVitals();
            unsubConnection();
            unsubError();
            stopSimulation?.();
        };
    }, [stopSimulation]);

    const handleConnect = async (type: 'hrm' | 'bp' | 'spo2') => {
        setScanning(true);
        setError(null);

        try {
            let device: WearableDevice | null = null;
            switch (type) {
                case 'hrm':
                    device = await connectHeartRateMonitor();
                    break;
                case 'bp':
                    device = await connectBloodPressureMonitor();
                    break;
                case 'spo2':
                    device = await connectPulseOximeter();
                    break;
            }

            if (device) {
                setDevices(getConnectedDevices());
            }
        } finally {
            setScanning(false);
        }
    };

    const handleDisconnect = async (id: string) => {
        await disconnectDevice(id);
        setDevices(getConnectedDevices());
    };

    const toggleSimulation = () => {
        if (simulationActive && stopSimulation) {
            stopSimulation();
            setStopSimulation(null);
            setSimulationActive(false);
        } else {
            const stop = startWearableSimulation();
            setStopSimulation(() => stop);
            setSimulationActive(true);
        }
    };

    if (compact) {
        return (
            <div className="bg-white rounded-2xl border border-slate-200 p-4 shadow-sm">
                <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                        {devices.length > 0 ? (
                            <BluetoothConnected className="w-5 h-5 text-blue-600" />
                        ) : (
                            <Bluetooth className="w-5 h-5 text-slate-400" />
                        )}
                        <div>
                            <p className="text-sm font-black text-slate-900">
                                {devices.length > 0 ? `${devices.length} Device${devices.length > 1 ? 's' : ''} Connected` : 'No Wearables'}
                            </p>
                            {latestVitals?.heartRate && (
                                <p className="text-[10px] font-bold text-slate-500">
                                    HR: {latestVitals.heartRate} BPM • {latestVitals.source}
                                </p>
                            )}
                        </div>
                    </div>
                    <button
                        onClick={() => handleConnect('hrm')}
                        disabled={scanning}
                        className="px-3 py-1.5 bg-blue-600 text-white rounded-lg text-[10px] font-black uppercase tracking-widest hover:bg-blue-700 transition-all disabled:opacity-50"
                    >
                        {scanning ? <RefreshCw className="w-3 h-3 animate-spin" /> : '+ Connect'}
                    </button>
                </div>
            </div>
        );
    }

    return (
        <div className="fixed inset-0 z-[100] bg-slate-950/95 backdrop-blur-xl flex items-center justify-center p-6 animate-in fade-in duration-300">
            <div className="max-w-lg w-full bg-white rounded-[3rem] shadow-2xl overflow-hidden">
                {/* Header */}
                <div className="bg-gradient-to-br from-blue-600 to-indigo-700 p-8 text-white">
                    <div className="flex items-center justify-between mb-6">
                        <div className="flex items-center gap-4">
                            <div className="p-3 bg-white/20 rounded-2xl backdrop-blur-sm">
                                <Bluetooth className="w-6 h-6" />
                            </div>
                            <div>
                                <h2 className="text-2xl font-black tracking-tight">Wearable Hub</h2>
                                <p className="text-[10px] font-bold text-white/70 uppercase tracking-widest">Medical Device Connectivity</p>
                            </div>
                        </div>
                        {onBack && (
                            <button onClick={onBack} className="p-2 text-white/50 hover:text-white transition-colors">
                                <X className="w-6 h-6" />
                            </button>
                        )}
                    </div>

                    {!supported && (
                        <div className="flex items-center gap-3 p-4 bg-rose-500/20 rounded-2xl border border-rose-500/30">
                            <BluetoothOff className="w-5 h-5 text-rose-300" />
                            <p className="text-sm font-bold text-rose-100">
                                Bluetooth not supported. Use Chrome, Edge, or Opera on a compatible device.
                            </p>
                        </div>
                    )}

                    {error && (
                        <div className="flex items-center gap-3 p-4 bg-amber-500/20 rounded-2xl border border-amber-500/30 mt-4">
                            <AlertCircle className="w-5 h-5 text-amber-300" />
                            <p className="text-sm font-bold text-amber-100">{error}</p>
                        </div>
                    )}
                </div>

                <div className="p-8 space-y-8">
                    {/* Connected Devices */}
                    {devices.length > 0 && (
                        <div className="space-y-4">
                            <h3 className="text-[10px] font-black text-slate-500 uppercase tracking-widest">Connected Devices</h3>
                            {devices.map((device) => (
                                <div key={device.id} className="flex items-center justify-between p-4 bg-emerald-50 rounded-2xl border border-emerald-200">
                                    <div className="flex items-center gap-4">
                                        <div className="p-2 bg-emerald-100 rounded-xl">
                                            <Watch className="w-5 h-5 text-emerald-600" />
                                        </div>
                                        <div>
                                            <p className="font-black text-slate-900">{device.name}</p>
                                            <div className="flex items-center gap-3 mt-1">
                                                <span className="flex items-center gap-1 text-[9px] font-bold text-emerald-600 uppercase tracking-widest">
                                                    <CheckCircle2 className="w-3 h-3" /> Connected
                                                </span>
                                                {device.batteryLevel !== undefined && (
                                                    <span className="flex items-center gap-1 text-[9px] font-bold text-slate-400">
                                                        <Battery className="w-3 h-3" /> {device.batteryLevel}%
                                                    </span>
                                                )}
                                            </div>
                                        </div>
                                    </div>
                                    <button
                                        onClick={() => handleDisconnect(device.id)}
                                        className="px-3 py-1.5 bg-rose-100 text-rose-600 rounded-lg text-[10px] font-black uppercase tracking-widest hover:bg-rose-200 transition-all"
                                    >
                                        Disconnect
                                    </button>
                                </div>
                            ))}
                        </div>
                    )}

                    {/* Live Vitals */}
                    {latestVitals && (
                        <div className="bg-slate-900 rounded-2xl p-6 text-white">
                            <div className="flex items-center gap-2 mb-4">
                                <Signal className="w-4 h-4 text-emerald-500 animate-pulse" />
                                <span className="text-[10px] font-black uppercase tracking-widest text-emerald-500">Live Stream</span>
                            </div>
                            <div className="grid grid-cols-3 gap-4">
                                {latestVitals.heartRate && (
                                    <div className="text-center">
                                        <Heart className="w-6 h-6 text-rose-500 mx-auto mb-2 animate-pulse" />
                                        <p className="text-3xl font-black">{latestVitals.heartRate}</p>
                                        <p className="text-[9px] font-bold text-slate-400 uppercase tracking-widest">BPM</p>
                                    </div>
                                )}
                                {latestVitals.spo2 && (
                                    <div className="text-center">
                                        <Droplets className="w-6 h-6 text-blue-400 mx-auto mb-2" />
                                        <p className="text-3xl font-black">{latestVitals.spo2}%</p>
                                        <p className="text-[9px] font-bold text-slate-400 uppercase tracking-widest">SpO2</p>
                                    </div>
                                )}
                                {latestVitals.systolicBP && (
                                    <div className="text-center">
                                        <Activity className="w-6 h-6 text-amber-400 mx-auto mb-2" />
                                        <p className="text-3xl font-black">{latestVitals.systolicBP}/{latestVitals.diastolicBP}</p>
                                        <p className="text-[9px] font-bold text-slate-400 uppercase tracking-widest">BP</p>
                                    </div>
                                )}
                            </div>
                        </div>
                    )}

                    {/* Connection Options */}
                    <div className="space-y-4">
                        <h3 className="text-[10px] font-black text-slate-500 uppercase tracking-widest">Connect a Device</h3>
                        <div className="grid grid-cols-3 gap-4">
                            <button
                                onClick={() => handleConnect('hrm')}
                                disabled={scanning || !supported}
                                className="p-5 bg-white rounded-2xl border-2 border-slate-200 hover:border-rose-300 hover:bg-rose-50 transition-all text-center disabled:opacity-50 disabled:cursor-not-allowed group"
                            >
                                <Heart className="w-8 h-8 text-rose-500 mx-auto mb-3 group-hover:scale-110 transition-transform" />
                                <p className="text-[10px] font-black text-slate-900 uppercase tracking-widest">Heart Rate</p>
                            </button>

                            <button
                                onClick={() => handleConnect('bp')}
                                disabled={scanning || !supported}
                                className="p-5 bg-white rounded-2xl border-2 border-slate-200 hover:border-amber-300 hover:bg-amber-50 transition-all text-center disabled:opacity-50 disabled:cursor-not-allowed group"
                            >
                                <Activity className="w-8 h-8 text-amber-500 mx-auto mb-3 group-hover:scale-110 transition-transform" />
                                <p className="text-[10px] font-black text-slate-900 uppercase tracking-widest">Blood Pressure</p>
                            </button>

                            <button
                                onClick={() => handleConnect('spo2')}
                                disabled={scanning || !supported}
                                className="p-5 bg-white rounded-2xl border-2 border-slate-200 hover:border-blue-300 hover:bg-blue-50 transition-all text-center disabled:opacity-50 disabled:cursor-not-allowed group"
                            >
                                <Droplets className="w-8 h-8 text-blue-500 mx-auto mb-3 group-hover:scale-110 transition-transform" />
                                <p className="text-[10px] font-black text-slate-900 uppercase tracking-widest">Pulse Ox</p>
                            </button>
                        </div>
                    </div>

                    {/* Scanning Indicator */}
                    {scanning && (
                        <div className="flex items-center justify-center gap-4 p-5 bg-blue-50 rounded-2xl border border-blue-200">
                            <BluetoothSearching className="w-6 h-6 text-blue-600 animate-pulse" />
                            <p className="font-black text-blue-900">Scanning for devices...</p>
                        </div>
                    )}

                    {/* Simulation Mode */}
                    <div className="pt-6 border-t border-slate-100">
                        <button
                            onClick={toggleSimulation}
                            className={`w-full py-4 rounded-2xl font-black text-sm uppercase tracking-widest transition-all flex items-center justify-center gap-3 ${simulationActive
                                ? 'bg-amber-100 text-amber-700 border-2 border-amber-300'
                                : 'bg-slate-100 text-slate-600 hover:bg-slate-200 border-2 border-slate-200'
                                }`}
                        >
                            <Zap className={`w-5 h-5 ${simulationActive ? 'animate-pulse' : ''}`} />
                            {simulationActive ? 'Stop Simulation' : 'Start Demo Mode'}
                        </button>
                        <p className="text-[9px] font-bold text-slate-400 text-center mt-3 uppercase tracking-widest">
                            Demo mode simulates wearable data for testing
                        </p>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default WearableConnector;
