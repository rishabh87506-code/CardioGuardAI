import React, { useState, useEffect } from 'react';
import { useLocation } from 'react-router-dom';
import { Shield, Activity, ArrowRight, Heart, Thermometer, Droplets, Watch, Loader2, Link2 } from 'lucide-react';
import { VitalsData } from '../types';
import { connectHeartRateMonitor, onVitalsUpdate, isBluetoothSupported } from '../services/wearableService';
import MedicalDisclaimer from './MedicalDisclaimer';

interface VitalsFormProps {
    onSubmit: (data: VitalsData, symptoms: string[]) => void | Promise<void>;
    language?: string;
}

const VitalsForm: React.FC<VitalsFormProps> = ({ onSubmit }) => {
    const location = useLocation();
    const stateHeartRate = (location.state as any)?.heartRate;

    const [formData, setFormData] = useState({
        patientName: 'John Doe',
        identificationId: 'CG-AI-' + Math.floor(1000 + Math.random() * 9000),
        age: '45',
        gender: 'Male',
        systolicBP: '120',
        diastolicBP: '80',
        heartRate: stateHeartRate?.toString() || '72',
        cholesterol: '190',
        bloodSugar: '95',
        spO2: '98',
        temperature: '36.6',
        respiratoryRate: '16',
        hrv: '45',
        symptoms: '',
        heightCm: '175',
        weightKg: '78',
        activityLevel: 'moderate' as 'sedentary' | 'moderate' | 'active',
        isSmoker: 'No',
        hasDiabetes: 'No'
    });

    const [isConnecting, setIsConnecting] = useState(false);
    const [wearableConnected, setWearableConnected] = useState(false);
    const [isSubmitting, setIsSubmitting] = useState(false);
    const [scanProgress, setScanProgress] = useState(0);

    useEffect(() => {
        const unsubscribe = onVitalsUpdate((reading) => {
            if (reading.heartRate) {
                setFormData(prev => ({ ...prev, heartRate: reading.heartRate!.toString() }));
            }
        });
        return () => unsubscribe();
    }, []);

    const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
        setFormData({ ...formData, [e.target.name]: e.target.value });
    };

    const handleConnectWearable = async () => {
        if (!isBluetoothSupported()) {
            alert("Bluetooth is not supported in this browser.");
            return;
        }
        setIsConnecting(true);
        try {
            const device = await connectHeartRateMonitor();
            if (device) setWearableConnected(true);
        } catch (e) {
            console.error(e);
        } finally {
            setIsConnecting(false);
        }
    };

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        setIsSubmitting(true);

        // Mocking a "Deep Scan" progress
        for (let i = 0; i <= 100; i += 5) {
            setScanProgress(i);
            await new Promise(r => setTimeout(r, 80));
        }

        try {
            const vitals: VitalsData = {
                age: parseInt(formData.age),
                gender: (formData.gender.toLowerCase() as any),
                systolicBP: parseInt(formData.systolicBP),
                diastolicBP: parseInt(formData.diastolicBP),
                heartRate: parseInt(formData.heartRate),
                totalCholesterol: parseInt(formData.cholesterol),
                hdlCholesterol: 50,
                bloodSugar: parseInt(formData.bloodSugar),
                spO2: parseInt(formData.spO2),
                temperature: parseFloat(formData.temperature),
                isSmoker: formData.isSmoker === 'Yes',
                hasDiabetes: formData.hasDiabetes === 'Yes',
                heightCm: parseInt(formData.heightCm),
                weightKg: parseInt(formData.weightKg),
                activityLevel: formData.activityLevel,
                respiratoryRate: parseInt(formData.respiratoryRate),
                hrv: parseInt(formData.hrv),
                patientName: formData.patientName,
                identificationId: formData.identificationId
            };
            const symptomList = formData.symptoms.split(',').map(s => s.trim()).filter(s => s);

            await onSubmit(vitals, symptomList);
        } finally {
            setIsSubmitting(false);
            setScanProgress(0);
        }
    };

    return (
        <div className="w-full max-w-4xl mx-auto p-4 animate-in fade-in duration-700">
            {/* FORENSIC HEADER */}
            <div className="bg-slate-900 rounded-[3rem] p-10 text-white mb-10 relative overflow-hidden shadow-2xl border border-slate-800">
                <div className="absolute top-0 right-0 w-64 h-64 bg-cyan-500/10 blur-[100px] rounded-full"></div>
                <div className="relative z-10 flex flex-col md:flex-row justify-between items-center gap-8">
                    <div className="text-center md:text-left">
                        <div className="inline-flex items-center gap-2 bg-cyan-500/20 text-cyan-400 px-4 py-1.5 rounded-full text-[10px] font-black mb-4 uppercase tracking-[0.25em] border border-cyan-500/20">
                            <Shield size={12} strokeWidth={3} /> Clinical Grade Bio-Uplink
                        </div>
                        <h2 className="text-4xl font-black tracking-tighter mb-2">High-Fidelity <span className="text-cyan-400">Bio-Scan</span></h2>
                        <p className="text-slate-400 font-medium text-sm">Initializing neural-correlative biometric sequencing.</p>
                    </div>
                    <button
                        type="button"
                        onClick={handleConnectWearable}
                        disabled={wearableConnected || isConnecting}
                        className={`flex items-center gap-3 px-8 py-4 rounded-2xl text-[10px] font-black uppercase tracking-widest transition-all ${wearableConnected ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30' : 'bg-white text-slate-900 hover:bg-slate-100 shadow-xl'}`}
                    >
                        {isConnecting ? <Loader2 className="w-4 h-4 animate-spin" /> : wearableConnected ? <Link2 className="w-4 h-4" /> : <Watch className="w-4 h-4" />}
                        {isConnecting ? 'Linking...' : wearableConnected ? 'Stream Active' : 'Link Wearable'}
                    </button>
                </div>
            </div>

            <form onSubmit={handleSubmit} className="space-y-8">
                {/* BIOLOGICAL IDENTITY */}
                <div className="bg-white rounded-[2.5rem] p-8 shadow-sm border border-sky-100 flex flex-col md:flex-row gap-8 items-center">
                    <div className="flex-1 w-full space-y-2">
                        <label className="text-[10px] font-black text-slate-400 uppercase tracking-[0.2em]">Patient Full Name</label>
                        <input
                            name="patientName"
                            value={formData.patientName}
                            onChange={handleChange}
                            className="w-full text-2xl font-black text-slate-800 bg-transparent border-none outline-none focus:ring-0 placeholder:text-slate-200"
                            placeholder="Enter Name..."
                        />
                    </div>
                    <div className="h-10 w-[2px] bg-slate-100 hidden md:block"></div>
                    <div className="flex-1 w-full space-y-2">
                        <label className="text-[10px] font-black text-slate-400 uppercase tracking-[0.2em]">Clinical ID Node</label>
                        <div className="flex items-center gap-3">
                            <div className="w-2 h-2 rounded-full bg-cyan-500 animate-pulse"></div>
                            <span className="text-xl font-mono font-black text-slate-400">{formData.identificationId}</span>
                        </div>
                    </div>
                </div>

                {/* GRID FOR INPUT GROUPS */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-8">

                    {/* CORE BIOMETRICS */}
                    <InputGroup icon={<Activity className="text-cyan-500" />} title="Neuro-Signal Core">
                        <Field label="Patient Age" name="age" value={formData.age} onChange={handleChange} type="number" />
                        <div className="space-y-3">
                            <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Biological Sex</label>
                            <select name="gender" className="premium-input appearance-none" value={formData.gender} onChange={handleChange}>
                                <option value="Male">Male</option>
                                <option value="Female">Female</option>
                            </select>
                        </div>
                        <Field label="Heart Rate (BPM)" name="heartRate" value={formData.heartRate} onChange={handleChange} type="number" />
                        <Field label="HRV (ms)" name="hrv" value={formData.hrv} onChange={handleChange} type="number" />
                    </InputGroup>

                    {/* HEMODYNAMICS */}
                    <InputGroup icon={<Heart className="text-rose-500" />} title="Hemodynamic Matrix">
                        <Field label="Systolic (mmHg)" name="systolicBP" value={formData.systolicBP} onChange={handleChange} type="number" />
                        <Field label="Diastolic (mmHg)" name="diastolicBP" value={formData.diastolicBP} onChange={handleChange} type="number" />
                        <Field label="SpO2 (%)" name="spO2" value={formData.spO2} onChange={handleChange} type="number" />
                        <Field label="Resp. Rate" name="respiratoryRate" value={formData.respiratoryRate} onChange={handleChange} type="number" />
                    </InputGroup>

                    {/* ENDOCRINE & METABOLIC */}
                    <InputGroup icon={<Droplets className="text-amber-500" />} title="Metabolic Benchmarks">
                        <Field label="Total Cholesterol" name="cholesterol" value={formData.cholesterol} onChange={handleChange} type="number" />
                        <Field label="Blood Sugar (mg/dL)" name="bloodSugar" value={formData.bloodSugar} onChange={handleChange} type="number" />
                        <div className="space-y-3">
                            <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Diabetes Status</label>
                            <select name="hasDiabetes" className="premium-input appearance-none" value={formData.hasDiabetes} onChange={handleChange}>
                                <option value="No">Non-Diabetic</option>
                                <option value="Yes">Diabetic (Type I/II)</option>
                            </select>
                        </div>
                        <Field label="Temp (°C)" name="temperature" value={formData.temperature} onChange={handleChange} type="number" step="0.1" />
                    </InputGroup>

                    {/* LIFESTYLE & PHYSICS */}
                    <InputGroup icon={<Shield className="text-emerald-500" />} title="Physics & Protocol">
                        <Field label="Height (cm)" name="heightCm" value={formData.heightCm} onChange={handleChange} type="number" />
                        <Field label="Weight (kg)" name="weightKg" value={formData.weightKg} onChange={handleChange} type="number" />
                        <div className="space-y-3">
                            <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Tobacco Use</label>
                            <select name="isSmoker" className="premium-input appearance-none" value={formData.isSmoker} onChange={handleChange}>
                                <option value="No">Non-Smoker</option>
                                <option value="Yes">Active Smoker</option>
                            </select>
                        </div>
                        <div className="space-y-3">
                            <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Activity Node</label>
                            <select name="activityLevel" className="premium-input appearance-none" value={formData.activityLevel} onChange={handleChange}>
                                <option value="sedentary">Sedentary</option>
                                <option value="moderate">Moderate</option>
                                <option value="active">High Performance</option>
                            </select>
                        </div>
                    </InputGroup>
                </div>

                {/* SYMPTOMS */}
                <div className="bg-white rounded-[2.5rem] p-8 shadow-sm border border-sky-50">
                    <div className="space-y-3">
                        <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Clinical Symptomatology</label>
                        <textarea
                            name="symptoms"
                            placeholder="Identify acute anomalies (e.g. Angina, Palpitations, Edema)..."
                            className="w-full p-6 bg-sky-50/30 rounded-[1.5rem] font-bold text-slate-800 border-2 border-transparent focus:border-cyan-200 focus:bg-white transition-all outline-none min-h-[120px]"
                            value={formData.symptoms}
                            onChange={handleChange as any}
                        />
                    </div>
                </div>

                {/* SUBMIT */}
                <div className="relative">
                    {isSubmitting && (
                        <div className="absolute -top-12 left-0 w-full flex flex-col gap-2 p-2">
                            <div className="flex justify-between text-[10px] font-black text-cyan-600 uppercase tracking-widest px-2">
                                <span>Analyzing DNA-Correlative Stream</span>
                                <span>{scanProgress}%</span>
                            </div>
                            <div className="h-1.5 w-full bg-sky-100 rounded-full overflow-hidden">
                                <div className="h-full bg-cyan-600 transition-all duration-300" style={{ width: `${scanProgress}%` }}></div>
                            </div>
                        </div>
                    )}
                    <button
                        type="submit"
                        disabled={isSubmitting}
                        className="w-full py-7 bg-cyan-600 hover:bg-cyan-500 text-white rounded-[2rem] font-black text-xl shadow-2xl shadow-cyan-200 transition-all flex items-center justify-center gap-4 group disabled:opacity-70 disabled:grayscale"
                    >
                        {isSubmitting ? 'Biometric Forensic Processing...' : 'Finalize Clinical Scryption'}
                        {!isSubmitting && <ArrowRight size={24} className="group-hover:translate-x-2 transition-transform" />}
                    </button>
                </div>
            </form>

            <MedicalDisclaimer />

            <style>{`
                .premium-input {
                    width: 100%;
                    padding: 1.25rem;
                    background: #f0f9ff4d;
                    border-radius: 1.25rem;
                    font-weight: 700;
                    color: #1e293b;
                    border: 2px solid transparent;
                    transition: all 0.3s;
                    outline: none;
                }
                .premium-input:focus {
                    border-color: #a5f3fc;
                    background: white;
                    box-shadow: 0 10px 15px -3px rgb(0 0 0 / 0.05);
                }
            `}</style>
        </div>
    );
};

// --- SUB-COMPONENTS ---

function InputGroup({ icon, title, children }: any) {
    return (
        <div className="bg-white rounded-[2.5rem] p-8 shadow-sm border border-sky-50 hover:shadow-md transition-shadow">
            <div className="flex items-center gap-4 mb-8 border-b border-sky-50 pb-6">
                <div className="bg-slate-50 p-2.5 rounded-xl">{icon}</div>
                <h3 className="font-black text-lg text-slate-800 tracking-tight uppercase">{title}</h3>
            </div>
            <div className="grid grid-cols-1 gap-6">
                {children}
            </div>
        </div>
    );
}

function Field({ label, ...props }: any) {
    return (
        <div className="space-y-3">
            <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest">{label}</label>
            <input className="premium-input" {...props} />
        </div>
    );
}


export default VitalsForm;