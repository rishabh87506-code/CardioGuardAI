import React from 'react';
import { FileText, Scale, AlertCircle, Users, Shield, Ban, Gavel, Mail } from 'lucide-react';

const TermsOfService: React.FC<{ onBack: () => void }> = ({ onBack }) => {
    return (
        <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-purple-50 py-12 px-4 sm:px-6 lg:px-8">
            <div className="max-w-4xl mx-auto">
                {/* Header */}
                <div className="text-center mb-12">
                    <button
                        onClick={onBack}
                        className="mb-6 inline-flex items-center text-blue-600 hover:text-blue-800 transition-colors"
                    >
                        ← Back to App
                    </button>
                    <div className="flex justify-center mb-4">
                        <FileText className="w-16 h-16 text-blue-600" />
                    </div>
                    <h1 className="text-4xl font-bold text-slate-900 mb-4">Terms of Service</h1>
                    <p className="text-slate-600">Last Updated: February 9, 2026</p>
                </div>

                {/* Important Notice */}
                <div className="bg-amber-50 border-l-4 border-amber-400 p-4 mb-8 rounded-r-lg">
                    <div className="flex items-start gap-3">
                        <AlertCircle className="w-6 h-6 text-amber-500 flex-shrink-0 mt-1" />
                        <div>
                            <h3 className="font-semibold text-amber-800">Medical Disclaimer</h3>
                            <p className="text-amber-700 text-sm mt-1">
                                CardioGuard AI is an informational tool and does NOT provide medical diagnoses.
                                Always consult qualified healthcare professionals for medical advice, diagnosis, or treatment.
                            </p>
                        </div>
                    </div>
                </div>

                {/* Content */}
                <div className="bg-white/80 backdrop-blur-sm rounded-2xl shadow-xl p-8 space-y-8">

                    {/* Acceptance */}
                    <section>
                        <h2 className="text-2xl font-semibold text-slate-900 mb-4 flex items-center gap-2">
                            <Scale className="w-6 h-6 text-blue-500" />
                            1. Acceptance of Terms
                        </h2>
                        <p className="text-slate-700 leading-relaxed">
                            By accessing or using CardioGuard AI ("Service"), you agree to be bound by these Terms of Service.
                            If you do not agree to these terms, please do not use our Service. These terms apply to all visitors,
                            users, and others who access or use the Service.
                        </p>
                    </section>

                    {/* Service Description */}
                    <section>
                        <h2 className="text-2xl font-semibold text-slate-900 mb-4 flex items-center gap-2">
                            <Users className="w-6 h-6 text-purple-500" />
                            2. Service Description
                        </h2>
                        <p className="text-slate-700 mb-4">CardioGuard AI provides:</p>
                        <ul className="list-disc list-inside text-slate-700 space-y-2 ml-4">
                            <li>AI-powered cardiovascular risk assessment tools</li>
                            <li>Remote photoplethysmography (rPPG) heart rate monitoring</li>
                            <li>Health data tracking and visualization</li>
                            <li>Educational health information and insights</li>
                            <li>Integration with wearable health devices</li>
                        </ul>
                        <div className="mt-4 bg-red-50 p-4 rounded-lg">
                            <p className="text-red-800 font-semibold">The Service is NOT intended to:</p>
                            <ul className="list-disc list-inside text-red-700 space-y-1 mt-2">
                                <li>Replace professional medical advice or diagnosis</li>
                                <li>Treat or cure any medical condition</li>
                                <li>Provide emergency medical services</li>
                            </ul>
                        </div>
                    </section>

                    {/* User Responsibilities */}
                    <section>
                        <h2 className="text-2xl font-semibold text-slate-900 mb-4 flex items-center gap-2">
                            <Shield className="w-6 h-6 text-green-500" />
                            3. User Responsibilities
                        </h2>
                        <p className="text-slate-700 mb-4">As a user, you agree to:</p>
                        <div className="grid md:grid-cols-2 gap-4">
                            {[
                                'Provide accurate health information',
                                'Not rely solely on our Service for medical decisions',
                                'Seek professional medical advice when needed',
                                'Protect your account credentials',
                                'Not misuse or attempt to hack the Service',
                                'Comply with all applicable laws and regulations',
                            ].map((item, i) => (
                                <div key={i} className="flex items-center gap-2 bg-green-50 p-3 rounded-lg">
                                    <span className="text-green-600">✓</span>
                                    <span className="text-slate-700 text-sm">{item}</span>
                                </div>
                            ))}
                        </div>
                    </section>

                    {/* Prohibited Uses */}
                    <section>
                        <h2 className="text-2xl font-semibold text-slate-900 mb-4 flex items-center gap-2">
                            <Ban className="w-6 h-6 text-red-500" />
                            4. Prohibited Uses
                        </h2>
                        <p className="text-slate-700 mb-4">You may NOT use the Service to:</p>
                        <ul className="list-disc list-inside text-slate-700 space-y-2 ml-4">
                            <li>Violate any laws or regulations</li>
                            <li>Transmit malicious code or interfere with the Service</li>
                            <li>Collect data about other users without consent</li>
                            <li>Impersonate others or provide false information</li>
                            <li>Use the Service for commercial purposes without authorization</li>
                            <li>Reverse engineer or attempt to extract source code</li>
                        </ul>
                    </section>

                    {/* Limitation of Liability */}
                    <section>
                        <h2 className="text-2xl font-semibold text-slate-900 mb-4 flex items-center gap-2">
                            <Gavel className="w-6 h-6 text-amber-500" />
                            5. Limitation of Liability
                        </h2>
                        <div className="bg-slate-50 p-4 rounded-lg">
                            <p className="text-slate-700 leading-relaxed">
                                TO THE MAXIMUM EXTENT PERMITTED BY LAW, CARDIOGUARD AI AND ITS AFFILIATES SHALL NOT BE LIABLE
                                FOR ANY INDIRECT, INCIDENTAL, SPECIAL, CONSEQUENTIAL, OR PUNITIVE DAMAGES, OR ANY LOSS OF PROFITS
                                OR REVENUES, WHETHER INCURRED DIRECTLY OR INDIRECTLY, OR ANY LOSS OF DATA, USE, GOODWILL, OR
                                OTHER INTANGIBLE LOSSES RESULTING FROM YOUR ACCESS TO OR USE OF OR INABILITY TO ACCESS OR USE THE SERVICE.
                            </p>
                        </div>
                    </section>

                    {/* Intellectual Property */}
                    <section>
                        <h2 className="text-2xl font-semibold text-slate-900 mb-4">6. Intellectual Property</h2>
                        <p className="text-slate-700 leading-relaxed">
                            The Service and its original content, features, and functionality are and will remain the exclusive
                            property of CardioGuard AI. The Service is protected by copyright, trademark, and other laws.
                            Our trademarks may not be used in connection with any product or service without prior written consent.
                        </p>
                    </section>

                    {/* Termination */}
                    <section>
                        <h2 className="text-2xl font-semibold text-slate-900 mb-4">7. Termination</h2>
                        <p className="text-slate-700 leading-relaxed">
                            We may terminate or suspend your access immediately, without prior notice or liability, for any reason,
                            including breach of these Terms. Upon termination, your right to use the Service will cease immediately.
                            You may request deletion of your data at any time.
                        </p>
                    </section>

                    {/* Governing Law */}
                    <section>
                        <h2 className="text-2xl font-semibold text-slate-900 mb-4">8. Governing Law</h2>
                        <p className="text-slate-700 leading-relaxed">
                            These Terms shall be governed by and construed in accordance with the laws of India,
                            without regard to its conflict of law provisions. Any disputes arising from these Terms
                            shall be subject to the exclusive jurisdiction of the courts in India.
                        </p>
                    </section>

                    {/* Contact */}
                    <section>
                        <h2 className="text-2xl font-semibold text-slate-900 mb-4 flex items-center gap-2">
                            <Mail className="w-6 h-6 text-blue-500" />
                            9. Contact Us
                        </h2>
                        <p className="text-slate-700">
                            For questions about these Terms, contact us at:
                        </p>
                        <div className="mt-4 bg-slate-50 p-4 rounded-lg">
                            <p className="text-slate-900 font-semibold">CardioGuard AI Legal Team</p>
                            <p className="text-slate-600">Email: legal@cardioguardai.co.in</p>
                            <p className="text-slate-600">Website: www.cardioguardai.co.in</p>
                        </div>
                    </section>

                </div>

                {/* Footer */}
                <div className="text-center mt-8 text-slate-500 text-sm">
                    <p>© 2026 CardioGuard AI. All rights reserved.</p>
                    <p className="mt-2">These terms are effective as of February 9, 2026</p>
                </div>
            </div>
        </div>
    );
};

export default TermsOfService;
