
import React from 'react';
import { Shield, AlertTriangle, Heart, Activity, Baby, Brain, Zap } from 'lucide-react';
import { WomensHealthAnalysis, FEMALE_CVD_CONDITIONS } from '../services/womensHealthSentinel';

interface WomensHealthSentinelUIProps {
    analysis: WomensHealthAnalysis;
    onClose?: () => void;
}

const WomensHealthSentinelUI: React.FC<WomensHealthSentinelUIProps> = ({ analysis, onClose }) => {
    if (!analysis.isFemaleSentinelActive) return null;

    const getUrgencyColor = (urgency: string) => {
        switch (urgency) {
            case 'CRITICAL': return 'bg-rose-600 text-white';
            case 'HIGH': return 'bg-amber-500 text-white';
            case 'MODERATE': return 'bg-blue-500 text-white';
            case 'SURVEILLANCE': return 'bg-slate-500 text-white';
            default: return 'bg-slate-200 text-slate-700';
        }
    };

    const getConditionIcon = (conditionName: string) => {
        if (conditionName.includes('SCAD')) return Heart;
        if (conditionName.includes('Peripartum')) return Baby;
        if (conditionName.includes('Takotsubo')) return Brain;
        if (conditionName.includes('Microvascular')) return Activity;
        return Shield;
    };

    return (
        <div className="bg-gradient-to-br from-pink-50 via-white to-rose-50 border-2 border-pink-200 rounded-[2.5rem] p-8 shadow-xl animate-in fade-in slide-in-from-top-4 duration-500">
            {/* Header */}
            <div className="flex items-center justify-between mb-8">
                <div className="flex items-center gap-4">
                    <div className="p-3 bg-pink-600 rounded-2xl shadow-lg">
                        <Shield className="w-6 h-6 text-white" />
                    </div>
                    <div>
                        <h3 className="text-xl font-black text-slate-900 tracking-tight flex items-center gap-2">
                            Women's Health Sentinel
                            <span className="text-[10px] px-3 py-1 bg-pink-100 text-pink-700 font-black uppercase tracking-widest rounded-full">
                                Active
                            </span>
                        </h3>
                        <p className="text-sm text-slate-500 font-bold">Sex-specific cardiovascular analysis</p>
                    </div>
                </div>

                {analysis.emergencyProtocolTriggered && (
                    <div className="flex items-center gap-2 px-4 py-2 bg-rose-600 rounded-full animate-pulse">
                        <AlertTriangle className="w-4 h-4 text-white" />
                        <span className="text-[10px] font-black text-white uppercase tracking-widest">
                            Emergency Protocol
                        </span>
                    </div>
                )}
            </div>

            {/* Risk Elevation Badge */}
            {analysis.riskElevation > 0 && (
                <div className="mb-6 p-4 bg-amber-50 border border-amber-200 rounded-2xl flex items-center justify-between">
                    <span className="text-sm font-bold text-amber-900">Risk Elevation from Sentinel Findings</span>
                    <span className="text-2xl font-black text-amber-600">+{analysis.riskElevation}%</span>
                </div>
            )}

            {/* Detected Conditions */}
            {analysis.detectedConditions.length > 0 ? (
                <div className="space-y-4 mb-8">
                    <h4 className="text-[10px] font-black text-slate-500 uppercase tracking-widest mb-4">
                        Detected Conditions Requiring Attention
                    </h4>
                    {analysis.detectedConditions.map((condition, idx) => {
                        const Icon = getConditionIcon(condition.condition);
                        return (
                            <div
                                key={idx}
                                className="p-5 bg-white rounded-2xl border border-slate-200 shadow-sm hover:shadow-md transition-shadow"
                            >
                                <div className="flex items-start gap-4">
                                    <div className="p-2 bg-pink-100 rounded-xl shrink-0">
                                        <Icon className="w-5 h-5 text-pink-600" />
                                    </div>
                                    <div className="flex-1">
                                        <div className="flex items-center gap-3 mb-2">
                                            <h5 className="font-black text-slate-900">{condition.condition}</h5>
                                            <span className={`px-2 py-0.5 rounded-full text-[9px] font-black uppercase tracking-wider ${getUrgencyColor(condition.urgency)}`}>
                                                {condition.urgency}
                                            </span>
                                        </div>
                                        <p className="text-sm text-slate-600 mb-3">{condition.clinicalNote}</p>
                                        <div className="flex items-center justify-between">
                                            <span className="text-[10px] font-bold text-slate-400">
                                                Confidence: {condition.confidence}%
                                            </span>
                                            <span className="text-xs font-bold text-blue-600">{condition.action}</span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        );
                    })}
                </div>
            ) : (
                <div className="mb-8 p-6 bg-emerald-50 border border-emerald-200 rounded-2xl text-center">
                    <div className="inline-block p-3 bg-emerald-100 rounded-full mb-3">
                        <Shield className="w-6 h-6 text-emerald-600" />
                    </div>
                    <p className="font-bold text-emerald-900">No female-specific conditions detected</p>
                    <p className="text-sm text-emerald-600 mt-1">Standard cardiovascular analysis applies</p>
                </div>
            )}

            {/* Recommendations */}
            {analysis.recommendations.length > 0 && (
                <div className="mb-6">
                    <h4 className="text-[10px] font-black text-slate-500 uppercase tracking-widest mb-4">
                        Sentinel Recommendations
                    </h4>
                    <ul className="space-y-2">
                        {analysis.recommendations.map((rec, idx) => (
                            <li key={idx} className="flex items-start gap-3 p-3 bg-blue-50 rounded-xl">
                                <Zap className="w-4 h-4 text-blue-600 shrink-0 mt-0.5" />
                                <span className="text-sm font-bold text-slate-700">{rec}</span>
                            </li>
                        ))}
                    </ul>
                </div>
            )}

            {/* Agent Notes */}
            <div className="pt-6 border-t border-slate-200">
                <div className="flex items-center gap-2 text-[9px] font-bold text-slate-400 uppercase tracking-widest">
                    <Activity className="w-3 h-3" />
                    {analysis.agentNotes.join(' • ')}
                </div>
            </div>
        </div>
    );
};

export default WomensHealthSentinelUI;
