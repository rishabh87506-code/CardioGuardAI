
import React, { useState, useEffect } from 'react';
import {
    Activity, ShieldCheck, AlertTriangle, Search,
    FileText, BarChart3, ArrowLeft, Bot,
    Lock, CheckCircle2, XCircle, Zap, ShieldAlert
} from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { runFullstackAudit, AuditReport, AuditFinding } from '../services/auditorAgent';

export default function AuditSuite() {
    const navigate = useNavigate();
    const [status, setStatus] = useState<string>('Initializing Audit Engine...');
    const [report, setReport] = useState<AuditReport | null>(null);
    const [isScanning, setIsScanning] = useState(true);

    useEffect(() => {
        const executeAudit = async () => {
            const result = await runFullstackAudit((step) => {
                setStatus(step);
            });
            setReport(result);
            setIsScanning(false);
        };
        executeAudit();
    }, []);

    const getImpactColor = (impact: string) => {
        switch (impact) {
            case 'High': return 'text-rose-500 bg-rose-50 border-rose-100';
            case 'Medium': return 'text-amber-500 bg-amber-50 border-amber-100';
            case 'Low': return 'text-blue-500 bg-blue-50 border-blue-100';
            default: return 'text-slate-500 bg-slate-50 border-slate-100';
        }
    };

    return (
        <div className="max-w-7xl mx-auto p-6 space-y-8 pb-20 animate-in fade-in duration-700">
            {/* Clinical Audit Header */}
            <div className="bg-white p-10 rounded-[3rem] border border-slate-100 shadow-xl flex flex-col md:flex-row md:items-center justify-between gap-6 relative overflow-hidden">
                <div className="absolute top-0 right-0 p-10 opacity-5">
                    <ShieldCheck className="w-56 h-56 text-emerald-600" />
                </div>

                <div className="flex items-center gap-6 relative z-10">
                    <div className="bg-slate-900 p-5 rounded-3xl shadow-2xl">
                        <Lock className="w-10 h-10 text-emerald-400" />
                    </div>
                    <div>
                        <h1 className="text-4xl font-black text-slate-950 tracking-tighter">Extreme Fullstack Audit</h1>
                        <p className="text-[10px] font-black text-slate-400 uppercase tracking-[0.4em] mt-1">
                            Integrity & Security Forensic Suite • Build v1.0.4-SEC
                        </p>
                    </div>
                </div>

                <div className="flex items-center gap-4 relative z-10">
                    <button
                        onClick={() => navigate('/agents')}
                        className="px-6 py-4 bg-slate-100 hover:bg-slate-200 text-slate-900 rounded-2xl transition-all font-black text-xs uppercase tracking-widest flex items-center gap-3"
                    >
                        <ArrowLeft className="w-4 h-4" /> Cancel Audit
                    </button>
                </div>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
                {/* Main Scanning/Results Section */}
                <div className="lg:col-span-8 space-y-8">
                    {isScanning ? (
                        <div className="bg-white rounded-[4rem] border border-slate-100 p-20 shadow-2xl flex flex-col items-center justify-center text-center space-y-10 min-h-[600px]">
                            <div className="relative">
                                <Activity className="w-24 h-24 text-blue-500 animate-pulse" />
                                <div className="absolute inset-0 border-8 border-blue-100 border-t-blue-500 rounded-full animate-spin" />
                            </div>
                            <div className="space-y-4">
                                <h3 className="text-2xl font-black text-slate-950 tracking-tight">{status}</h3>
                                <div className="w-64 h-2 bg-slate-100 rounded-full mx-auto overflow-hidden">
                                    <div className="h-full bg-blue-500 animate-progress origin-left" />
                                </div>
                                <p className="text-[10px] font-black text-slate-400 uppercase tracking-[0.2em]">Bypassing standard caches • Deep Sector Scan active</p>
                            </div>
                        </div>
                    ) : (
                        <div className="space-y-8 animate-in slide-in-from-bottom-5 duration-700">
                            <div className="bg-white rounded-[4rem] border border-slate-100 p-10 shadow-2xl space-y-8">
                                <div className="flex items-center justify-between border-b border-slate-100 pb-8">
                                    <div className="flex items-center gap-3">
                                        <FileText className="w-5 h-5 text-slate-400" />
                                        <h3 className="text-xs font-black text-slate-900 uppercase tracking-widest">Discovered Shortcomings</h3>
                                    </div>
                                    <span className="text-[10px] font-black text-rose-500 uppercase tracking-widest bg-rose-50 px-3 py-1 rounded-full border border-rose-100">
                                        {report?.findings.length} Anomalies Found
                                    </span>
                                </div>

                                <div className="space-y-6">
                                    {report?.findings.map((finding) => (
                                        <div key={finding.id} className="group bg-slate-50/50 hover:bg-white p-6 rounded-[2.5rem] border border-slate-100 hover:border-blue-100 transition-all duration-300 hover:shadow-lg">
                                            <div className="flex items-start gap-6">
                                                <div className={`p-4 rounded-2xl border ${getImpactColor(finding.impact)}`}>
                                                    <AlertTriangle className="w-6 h-6" />
                                                </div>
                                                <div className="flex-1 space-y-3">
                                                    <div className="flex items-center justify-between">
                                                        <h4 className="text-lg font-black text-slate-900 tracking-tight">{finding.target}</h4>
                                                        <span className="text-[9px] font-black uppercase tracking-widest text-slate-400">{finding.category}</span>
                                                    </div>
                                                    <p className="text-slate-600 font-medium text-sm leading-relaxed">{finding.issue}</p>
                                                    <div className="p-4 bg-white rounded-2xl border border-slate-100">
                                                        <p className="text-[10px] font-black text-emerald-600 uppercase tracking-widest mb-1 flex items-center gap-2">
                                                            <Zap className="w-3 h-3" /> Recommended Remedy
                                                        </p>
                                                        <p className="text-xs font-bold text-slate-500 leading-relaxed">{finding.remedy}</p>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    ))}
                                </div>
                            </div>
                        </div>
                    )}
                </div>

                {/* Right: Integrity Sidebar */}
                <div className="lg:col-span-4 space-y-8">
                    {!isScanning && report && (
                        <div className="bg-slate-950 p-10 rounded-[3.5rem] border border-white/10 shadow-2xl relative overflow-hidden space-y-8">
                            <div className="text-center space-y-4 relative z-10">
                                <div className="inline-block p-4 bg-white/5 rounded-3xl border border-white/10 mb-2">
                                    <BarChart3 className="w-8 h-8 text-emerald-400" />
                                </div>
                                <h3 className="text-xs font-black text-white uppercase tracking-[0.4em]">Clinical Standard Rating</h3>
                                <div className="relative inline-flex items-center justify-center">
                                    <svg className="w-48 h-48 transform -rotate-90">
                                        <circle cx="96" cy="96" r="88" stroke="currentColor" strokeWidth="12" fill="transparent" className="text-white/5" />
                                        <circle cx="96" cy="96" r="88" stroke="currentColor" strokeWidth="12" fill="transparent" strokeDasharray={552.92} strokeDashoffset={552.92 - (552.92 * report.score) / 100} className="text-emerald-500 transition-all duration-1000 ease-out" />
                                    </svg>
                                    <div className="absolute flex flex-col items-center">
                                        <span className="text-6xl font-black text-white tracking-tighter">{report.score}</span>
                                        <span className="text-[10px] font-black text-slate-500 uppercase tracking-widest">% Adherence</span>
                                    </div>
                                </div>
                            </div>

                            <div className="p-6 bg-white/5 rounded-3xl border border-white/10 space-y-4 relative z-10">
                                <h4 className="text-[10px] font-black text-white uppercase tracking-widest flex items-center gap-2">
                                    <Bot className="w-4 h-4 text-emerald-400" /> Auditor's Verdict
                                </h4>
                                <p className="text-sm text-slate-400 leading-relaxed font-medium">
                                    {report.summary}
                                </p>
                            </div>

                            <div className="space-y-4 relative z-10">
                                <h4 className="text-[10px] font-black text-white uppercase tracking-widest">Audit Metadata</h4>
                                <div className="grid grid-cols-2 gap-4">
                                    <div className="bg-white/5 p-4 rounded-2xl border border-white/5">
                                        <p className="text-[8px] font-black text-slate-500 mb-1">SCANNED NODES</p>
                                        <p className="text-xs font-black text-white">412</p>
                                    </div>
                                    <div className="bg-white/5 p-4 rounded-2xl border border-white/5">
                                        <p className="text-[8px] font-black text-slate-500 mb-1">HASH VERIFIED</p>
                                        <p className="text-xs font-black text-white">100%</p>
                                    </div>
                                </div>
                            </div>

                            <button
                                onClick={() => navigate('/')}
                                className="w-full py-5 bg-emerald-500 hover:bg-emerald-400 text-white rounded-3xl font-black text-[11px] uppercase tracking-widest transition-all shadow-xl active:scale-[0.98] relative z-10"
                            >
                                Re-Hardening Dashboard
                            </button>
                        </div>
                    )}

                    <div className="bg-white p-8 rounded-[3rem] border border-slate-100 shadow-xl space-y-6">
                        <div className="flex items-center gap-3">
                            <ShieldAlert className="w-5 h-5 text-rose-500" />
                            <h3 className="text-xs font-black text-slate-900 uppercase tracking-widest">Protocol Warning</h3>
                        </div>
                        <p className="text-xs text-slate-500 font-bold leading-relaxed">
                            This audit identifies logic intended for "demo mode" that must be purged before Tier-1 Clinical deployment.
                        </p>
                        <div className="flex items-center gap-2 text-[10px] font-black text-slate-400 uppercase tracking-widest">
                            <span className="w-1.5 h-1.5 bg-rose-500 rounded-full" />
                            Security Clearance Level: 4
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
}
