import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { createClient } from '../../lib/supabase/client';

const Login: React.FC = () => {
    const [email, setEmail] = useState('');
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState<string | null>(null);
    const [success, setSuccess] = useState(false);
    const navigate = useNavigate();

    const supabase = createClient();

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        setLoading(true);
        setError(null);
        setSuccess(false);

        const { error } = await supabase.auth.signInWithOtp({
            email,
            options: {
                // In Vite, we redirect to the current origin
                emailRedirectTo: `${window.location.origin}/`,
            },
        });

        if (error) {
            setError(error.message);
        } else {
            setSuccess(true);
        }
        setLoading(false);
    };

    return (
        <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-blue-950 to-indigo-950 p-4 font-inter">
            {/* Return Button */}
            <button
                onClick={() => navigate('/')}
                className="absolute top-8 left-8 text-blue-300 hover:text-white transition-colors text-sm font-bold uppercase tracking-widest"
            >
                ← Back to Lab
            </button>

            <div className="w-full max-w-md bg-white/10 backdrop-blur-xl p-10 rounded-[2.5rem] border border-white/20 shadow-2xl">
                <div className="text-center mb-10">
                    <h1 className="text-4xl font-black text-white tracking-tighter mb-2">CardioGuard AI</h1>
                    <p className="text-blue-200/60 text-xs font-bold uppercase tracking-[0.3em]">Secure Clinical Gateway</p>
                </div>

                <form onSubmit={handleSubmit} className="space-y-6">
                    <div className="space-y-2">
                        <label className="text-[10px] font-black text-blue-300 uppercase tracking-widest ml-1">Professional Email</label>
                        <input
                            type="email"
                            value={email}
                            onChange={(e) => setEmail(e.target.value)}
                            placeholder="physician@cardioguard.ai"
                            required
                            className="w-full px-6 py-4 bg-white/5 border border-white/10 rounded-2xl text-white placeholder:text-white/20 focus:outline-none focus:border-blue-400 focus:bg-white/10 transition-all font-medium"
                        />
                    </div>

                    <button
                        type="submit"
                        disabled={loading}
                        className="w-full py-5 bg-gradient-to-r from-blue-500 to-indigo-600 rounded-2xl text-white font-black text-sm uppercase tracking-widest hover:brightness-110 active:scale-[0.98] disabled:opacity-50 transition-all shadow-xl shadow-blue-500/20"
                    >
                        {loading ? 'Sending Protocol...' : 'Request Magic Link'}
                    </button>

                    {error && (
                        <div className="p-4 bg-red-500/10 border border-red-500/20 rounded-xl text-red-400 text-xs text-center font-bold">
                            {error}
                        </div>
                    )}

                    {success && (
                        <div className="p-4 bg-emerald-500/10 border border-emerald-500/20 rounded-xl text-emerald-400 text-xs text-center font-bold">
                            Magic link dispatched. Check your clinical inbox.
                        </div>
                    )}
                </form>

                <div className="mt-10 pt-8 border-t border-white/5 text-center">
                    <p className="text-[10px] text-white/30 font-bold uppercase tracking-widest">
                        AES-256 Quantum-Safe Encryption Active
                    </p>
                </div>
            </div>
        </div>
    );
};

export default Login;
