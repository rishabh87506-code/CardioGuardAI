import React, { useState, useMemo } from 'react';
import {
    Search, Filter, Activity, AlertTriangle, CheckCircle2,
    ArrowLeft, LayoutDashboard, Database, Gauge, Timer,
    Zap, ExternalLink, User
} from 'lucide-react';
import { HistoricalAssessment, StressTestStats, ViewState } from '../types';
import './HealthcareDashboard.css';

interface HealthcareDashboardProps {
    assessments: HistoricalAssessment[];
    stats: StressTestStats | null;
    onNavigate: (view: ViewState) => void;
    onRunStressTest: () => void;
    isTesting: boolean;
}

const HealthcareDashboard: React.FC<HealthcareDashboardProps> = ({
    assessments,
    stats,
    onNavigate,
    onRunStressTest,
    isTesting
}) => {
    const [filter, setFilter] = useState<string>('all');
    const [searchTerm, setSearchTerm] = useState('');

    const filteredAssessments = useMemo(() => {
        return assessments.filter(a => {
            const matchesFilter = filter === 'all' || a.riskCategory.toLowerCase() === filter.toLowerCase() || a.triageLevel?.toLowerCase() === filter.toLowerCase();
            const matchesSearch = a.patientName?.toLowerCase().includes(searchTerm.toLowerCase()) ||
                a.id.toLowerCase().includes(searchTerm.toLowerCase()) ||
                a.vitals.medicalId?.toLowerCase().includes(searchTerm.toLowerCase());
            return matchesFilter && matchesSearch;
        });
    }, [assessments, filter, searchTerm]);

    const getTriageColor = (level?: string) => {
        switch (level) {
            case 'Critical': return 'var(--color-danger)';
            case 'Urgent': return 'var(--color-warning)';
            case 'Stable': return 'var(--color-primary)';
            case 'Routine': return 'var(--color-text-secondary)';
            default: return 'var(--color-text-muted)';
        }
    };

    return (
        <div className="healthcare-dashboard premium-glass">
            <div className="dashboard-header">
                <div className="header-title">
                    <Activity className="header-icon text-primary" size={32} strokeWidth={2.5} />
                    <div className="title-group">
                        <h1>Clinical Triage Command Center</h1>
                        <p className="subtitle">Real-time cardiovascular monitor & risk assessment</p>
                    </div>
                </div>
                <div className="header-actions">
                    <button
                        className={`stress-test-btn ${isTesting ? 'loading' : ''}`}
                        onClick={onRunStressTest}
                        disabled={isTesting}
                    >
                        <Zap className={`w-4 h-4 ${isTesting ? 'animate-spin' : ''}`} />
                        {isTesting ? 'Simulation Running...' : 'Initiate Stress Test'}
                    </button>
                    <button className="back-btn" onClick={() => onNavigate(ViewState.DASHBOARD)}>
                        <ArrowLeft className="w-4 h-4" /> Exit Portal
                    </button>
                </div>
            </div>

            {stats && (
                <div className="stats-grid">
                    <div className="stat-card">
                        <div className="stat-header">
                            <Database className="stat-icon" size={20} />
                            <span className="label">Total Assessments</span>
                        </div>
                        <span className="value">{stats.total}</span>
                    </div>
                    <div className="stat-card">
                        <div className="stat-header">
                            <Gauge className="stat-icon text-success" size={20} />
                            <span className="label">Accuracy Rate</span>
                        </div>
                        <span className="value">{(stats.accuracy * 100).toFixed(1)}%</span>
                    </div>
                    <div className="stat-card">
                        <div className="stat-header">
                            <Timer className="stat-icon" size={20} />
                            <span className="label">Avg Latency</span>
                        </div>
                        <span className="value">{stats.avgTimeMs.toFixed(0)}ms</span>
                    </div>
                    <div className="stat-card">
                        <div className="stat-header">
                            <AlertTriangle className="stat-icon text-danger" size={20} />
                            <span className="label">Failed Sessions</span>
                        </div>
                        <span className="value danger">{stats.failed}</span>
                    </div>
                </div>
            )}

            <div className="triage-controls">
                <div className="search-box">
                    <Search className="search-icon" size={18} />
                    <input
                        type="text"
                        placeholder="Search Patient Identity..."
                        value={searchTerm}
                        onChange={(e) => setSearchTerm(e.target.value)}
                    />
                </div>
                <div className="filter-tabs">
                    <Filter className="filter-icon" size={16} />
                    {['all', 'Critical', 'High', 'Moderate', 'Low'].map(f => (
                        <button
                            key={f}
                            className={filter === f ? 'active' : ''}
                            onClick={() => setFilter(f)}
                        >
                            {f.charAt(0).toUpperCase() + f.slice(1)}
                        </button>
                    ))}
                </div>
            </div>

            <div className="triage-table-container">
                <table className="triage-table">
                    <thead>
                        <tr>
                            <th>Patient Identity</th>
                            <th>Vitals (BP/CH)</th>
                            <th>AI Risk</th>
                            <th>Triage Level</th>
                            <th>Case Type</th>
                            <th>Status</th>
                        </tr>
                    </thead>
                    <tbody>
                        {filteredAssessments.length > 0 ? (
                            filteredAssessments.map(a => (
                                <tr key={a.id} className="triage-row">
                                    <td>
                                        <div className="patient-info">
                                            <div className="avatar">
                                                <User size={16} />
                                            </div>
                                            <div className="info-group">
                                                <span className="name">{a.patientName || 'Anonymous'}</span>
                                                <span className="id">ID: {a.id.slice(0, 8)}</span>
                                            </div>
                                        </div>
                                    </td>
                                    <td>
                                        <div className="vitals-summary">
                                            <span className="bp">{a.vitals.systolicBP}/{a.vitals.diastolicBP}</span>
                                            <span className="sub">{a.vitals.totalCholesterol} mg/dL</span>
                                        </div>
                                    </td>
                                    <td>
                                        <span className={`risk-badge ${a.riskCategory.toLowerCase().replace(' ', '-')}`}>
                                            {a.riskCategory}
                                        </span>
                                    </td>
                                    <td>
                                        <div className="triage-level" style={{ color: getTriageColor(a.triageLevel) }}>
                                            <div className="dot" style={{ backgroundColor: getTriageColor(a.triageLevel) }}></div>
                                            {a.triageLevel || 'Stable'}
                                        </div>
                                    </td>
                                    <td>
                                        <span className="case-type">{a.caseType || 'Standard'}</span>
                                    </td>
                                    <td>
                                        {a.expectedRisk && (
                                            <div className={`accuracy-check ${a.riskCategory === a.expectedRisk ? 'correct' : 'error'}`}>
                                                {a.riskCategory === a.expectedRisk ? (
                                                    <CheckCircle2 size={14} className="text-success" />
                                                ) : (
                                                    <AlertTriangle size={14} className="text-danger" />
                                                )}
                                                <span>{a.riskCategory === a.expectedRisk ? 'Accurate' : 'Misaligned'}</span>
                                            </div>
                                        )}
                                    </td>
                                </tr>
                            ))
                        ) : (
                            <tr>
                                <td colSpan={6} className="no-results">
                                    <Database size={32} className="opacity-20 mb-4" />
                                    <p>No patient records found.</p>
                                </td>
                            </tr>
                        )}
                    </tbody>
                </table>
            </div>
        </div>
    );
};

export default HealthcareDashboard;
