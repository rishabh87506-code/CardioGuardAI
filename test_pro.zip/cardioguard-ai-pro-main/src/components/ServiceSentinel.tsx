
import React, { useState, useEffect } from 'react';
import { ShieldCheck, Wifi, WifiOff, RefreshCw, AlertTriangle, Zap, Cpu } from 'lucide-react';

interface ServiceSentinelProps {
  isOnline: boolean;
}

const ServiceSentinel: React.FC<ServiceSentinelProps> = ({ isOnline }) => {
  const [isSentinelExpanded, setIsSentinelExpanded] = useState(false);
  const [aiHealth, setAiHealth] = useState(100);
  const [latency, setLatency] = useState(24); // ms

  useEffect(() => {
    const interval = setInterval(() => {
      // Simulate real-time node monitoring
      setAiHealth(h => Math.max(92, Math.min(100, h + (Math.random() - 0.5) * 2)));
      setLatency(l => Math.max(12, Math.min(85, l + (Math.random() - 0.5) * 10)));
    }, 5000);
    return () => clearInterval(interval);
  }, []);

  return (
    <div className="fixed top-24 right-5 z-[55] flex flex-col items-end gap-3 pointer-events-none sm:pointer-events-auto">
      <div 
        onClick={() => setIsSentinelExpanded(!isSentinelExpanded)}
        className={`bg-white/90 backdrop-blur-2xl p-3 rounded-2xl border border-slate-200 shadow-xl flex items-center gap-3 transition-all cursor-pointer pointer-events-auto ${isSentinelExpanded ? 'w-64' : 'w-12'}`}
      >
        <div className={`p-1.5 rounded-lg shrink-0 ${isOnline ? 'bg-blue-600' : 'bg-rose-600'} text-white`}>
          {isOnline ? <ShieldCheck className="w-5 h-5" /> : <AlertTriangle className="w-5 h-5" />}
        </div>
        
        {isSentinelExpanded && (
          <div className="flex-1 overflow-hidden animate-in fade-in slide-in-from-right-4 duration-300">
            <p className="text-[10px] font-black uppercase text-slate-900 leading-none">Sentinel Node</p>
            <div className="flex items-center gap-1.5 mt-1.5">
              <div className={`w-1.5 h-1.5 rounded-full ${isOnline ? 'bg-emerald-500' : 'bg-rose-500'}`}></div>
              <p className="text-[8px] font-black text-slate-400 uppercase tracking-widest">{isOnline ? 'Precision Link' : 'RAP Protocol'}</p>
            </div>
          </div>
        )}
      </div>

      {isSentinelExpanded && (
        <div className="bg-slate-950 p-6 rounded-[2rem] shadow-2xl border border-white/5 w-72 space-y-6 pointer-events-auto animate-in zoom-in-95 duration-300 text-white">
          <div className="flex items-center justify-between">
            <h3 className="text-xs font-black uppercase tracking-[0.3em] flex items-center gap-2">
              <Cpu className="w-4 h-4 text-blue-400" /> Clinical Reliability AI
            </h3>
            <button onClick={() => setIsSentinelExpanded(false)}>
              <RefreshCw className="w-3.5 h-3.5 text-slate-500 hover:text-white transition-colors" />
            </button>
          </div>

          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Global Node Health</span>
              <span className="text-sm font-black text-emerald-400">{aiHealth.toFixed(1)}%</span>
            </div>
            <div className="w-full h-1 bg-white/5 rounded-full overflow-hidden">
              <div className="h-full bg-emerald-500" style={{ width: `${aiHealth}%` }}></div>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div className="p-3 bg-white/5 rounded-xl border border-white/5">
                <p className="text-[8px] font-black text-slate-500 uppercase tracking-widest mb-1">Latency</p>
                <div className="flex items-center gap-2">
                  <Zap className="w-3 h-3 text-blue-400" />
                  <span className="text-sm font-black">{Math.round(latency)}ms</span>
                </div>
              </div>
              <div className="p-3 bg-white/5 rounded-xl border border-white/5">
                <p className="text-[8px] font-black text-slate-500 uppercase tracking-widest mb-1">Connectivity</p>
                <div className="flex items-center gap-2">
                  {isOnline ? <Wifi className="w-3 h-3 text-emerald-400" /> : <WifiOff className="w-3 h-3 text-rose-400" />}
                  <span className={`text-sm font-black ${isOnline ? 'text-emerald-400' : 'text-rose-400'}`}>{isOnline ? 'High' : 'Remote'}</span>
                </div>
              </div>
            </div>

            <div className="pt-2">
              <div className="bg-blue-600/10 border border-blue-500/20 p-4 rounded-2xl">
                <p className="text-[9px] text-blue-100 font-bold leading-relaxed">
                  <span className="text-blue-400">RAP ACTIVE:</span> Remote Area Protocol is managing human interference. System will auto-rectify connection drops using clinical local cache.
                </p>
              </div>
            </div>
          </div>
          
          <p className="text-[8px] text-center font-black text-white/20 uppercase tracking-[0.4em]">
            TCH Clinical Sentinel v1.2
          </p>
        </div>
      )}
    </div>
  );
};

export default ServiceSentinel;
