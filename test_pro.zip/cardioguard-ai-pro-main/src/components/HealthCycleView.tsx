import React, { useState, useEffect } from 'react';
import {
    TrendingUp,
    Calendar,
    CheckCircle2,
    AlertCircle,
    Activity,
    ArrowLeft,
    Loader2,
    Target
} from 'lucide-react';
import {
    AreaChart,
    Area,
    XAxis,
    YAxis,
    CartesianGrid,
    Tooltip,
    ResponsiveContainer
} from 'recharts';
import { predictHealthCycle } from '../services/geminiService';
import { VitalsData, HistoricalAssessment, SupportedLanguage } from '../types';

interface HealthCycleViewProps {
    history: HistoricalAssessment[];
    currentVitals: VitalsData;
    onBack: () => void;
    language?: SupportedLanguage;
}

const CustomTooltip = ({ active, payload }: any) => {
    if (active && payload && payload.length) {
        return (
            <div className="bg-slate-950 border border-slate-800 p-4 rounded-2xl shadow-2xl">
                <p className="text-[10px] font-black text-slate-500 uppercase tracking-widest mb-1">{payload[0].payload.month}</p>
                <p className="text-xl font-black text-white">{payload[0].value}% <span className="text-[10px] text-cyan-400">RISK</span></p>
                <p className="text-[9px] font-bold text-slate-400 mt-1 uppercase tracking-tighter">{payload[0].payload.status}</p>
            </div>
        );
    }
    return null;
};

const HealthCycleView: React.FC<HealthCycleViewProps> = ({ history, currentVitals, onBack, language = 'English' }) => {
    const [prediction, setPrediction] = useState<any>(null);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        const fetchPrediction = async () => {
            try {
                const res = await predictHealthCycle(history, currentVitals, language);
                setPrediction(res);
            } catch (err) {
                console.error("Cycle Prediction Failure:", err);
            } finally {
                setLoading(false);
            }
        };
        fetchPrediction();
    }, [history, currentVitals, language]);

    if (loading) {
        return (
            <div className="flex flex-col items-center justify-center h-[60vh] gap-6">
                <div className="relative">
                    <div className="absolute inset-0 bg-cyan-500/20 blur-[40px] rounded-full animate-pulse"></div>
                    <Loader2 className="w-16 h-16 animate-spin text-cyan-600 relative z-10" />
                    <Activity className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 text-cyan-500 w-6 h-6 z-20" />
                </div>
                <div className="text-center">
                    <h2 className="text-xl font-black text-slate-800 uppercase tracking-widest">Generating 12-Month Trajectory</h2>
                    <p className="text-slate-400 text-sm font-medium mt-2 uppercase tracking-widest">Simulating Biological Stability Indicators...</p>
                </div>
            </div>
        );
    }

    return (
        <div className="space-y-10 animate-in fade-in zoom-in duration-500 pb-20">
            {/* HEADER */}
            <div className="flex items-center justify-between">
                <button
                    onClick={onBack}
                    className="flex items-center gap-3 text-slate-500 hover:text-cyan-600 transition-all font-black text-[10px] uppercase tracking-widest"
                >
                    <ArrowLeft className="w-4 h-4" /> Return to Dashboard
                </button>
                <div className="flex items-center gap-2 px-4 py-1.5 rounded-full bg-cyan-100/50 text-cyan-700 text-[9px] font-black uppercase tracking-[0.2em]">
                    <Target size={12} /> Predictive Analytics Enabled
                </div>
            </div>

            <header className="space-y-4">
                <h1 className="text-5xl font-black tracking-tighter text-slate-900">Your Heart's <span className="text-cyan-600">Health Cycle</span></h1>
                <p className="text-slate-500 text-lg font-medium max-w-2xl leading-relaxed">
                    Based on your clinical history and current biometric markers, our AI core has projected your cardiovascular stability matrix for the next year.
                </p>
            </header>

            {/* TRAJECTORY MATRIX */}
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">

                {/* 12-MONTH VISUALIZATION */}
                <div className="lg:col-span-2 bg-white rounded-[3rem] p-10 border border-sky-100 shadow-sm overflow-hidden relative min-h-[450px]">
                    <div className="flex items-center justify-between mb-8">
                        <h3 className="text-xs font-black text-slate-400 uppercase tracking-[0.3em] flex items-center gap-3">
                            <Calendar className="w-4 h-4 text-cyan-600" /> 12-Month Predictive Analytics
                        </h3>
                        <div className="flex gap-4">
                            <div className="flex items-center gap-2">
                                <div className="w-2 h-2 rounded-full bg-cyan-500"></div>
                                <span className="text-[10px] font-black text-slate-800 uppercase tracking-widest">Projected Risk Probability</span>
                            </div>
                        </div>
                    </div>

                    <div className="h-80 w-full mt-4">
                        <ResponsiveContainer width="100%" height="100%">
                            <AreaChart data={prediction?.trajectory || []}>
                                <defs>
                                    <linearGradient id="colorRisk" x1="0" y1="0" x2="0" y2="1">
                                        <stop offset="5%" stopColor="#0891b2" stopOpacity={0.3} />
                                        <stop offset="95%" stopColor="#0891b2" stopOpacity={0} />
                                    </linearGradient>
                                </defs>
                                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                                <XAxis
                                    dataKey="month"
                                    axisLine={false}
                                    tickLine={false}
                                    tick={{ fontSize: 10, fontWeight: 900, fill: '#64748b' }}
                                    dy={10}
                                />
                                <YAxis
                                    hide
                                    domain={[0, 100]}
                                />
                                <Tooltip content={<CustomTooltip />} cursor={{ stroke: '#0891b2', strokeWidth: 1, strokeDasharray: '4 4' }} />
                                <Area
                                    type="monotone"
                                    dataKey="risk"
                                    stroke="#0891b2"
                                    strokeWidth={4}
                                    fillOpacity={1}
                                    fill="url(#colorRisk)"
                                    animationDuration={1500}
                                />
                            </AreaChart>
                        </ResponsiveContainer>
                    </div>
                </div>

                {/* ANALYSIS PANEL */}
                <div className="bg-slate-900 rounded-[3rem] p-10 text-white shadow-2xl flex flex-col gap-8">
                    <div className="space-y-2">
                        <p className="text-[10px] font-black uppercase text-cyan-400 tracking-[0.3em]">AI Consensus</p>
                        <h3 className="text-2xl font-black tracking-tight">Cycle Analysis</h3>
                    </div>

                    <p className="text-slate-300 font-medium leading-relaxed text-sm">
                        {prediction?.cycleAnalysis}
                    </p>

                    <div className="mt-auto space-y-4">
                        <div className="p-5 bg-white/5 rounded-2xl border border-white/10 flex items-center gap-4">
                            <div className="w-10 h-10 rounded-xl bg-cyan-500 flex items-center justify-center text-white shadow-lg shadow-cyan-500/20">
                                <TrendingUp size={20} />
                            </div>
                            <div>
                                <p className="text-[9px] font-black text-slate-500 uppercase tracking-widest">Stability Index</p>
                                <p className="text-lg font-black">{100 - (prediction?.trajectory?.[0]?.risk || 0)}/100</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            {/* PREVENTIVE BENCHMARKS */}
            <div className="bg-white rounded-[3.5rem] p-10 border border-sky-50 shadow-sm">
                <h3 className="text-xl font-black text-slate-800 mb-10 flex items-center gap-4 tracking-tight">
                    <div className="p-3 bg-emerald-50 text-emerald-600 rounded-2xl border border-emerald-100">
                        <CheckCircle2 size={24} />
                    </div>
                    Preventive Health Benchmarks
                </h3>

                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                    {prediction?.preventiveBenchmarks.map((bench: string, idx: number) => (
                        <div key={idx} className="p-6 bg-sky-50/30 rounded-[2rem] border border-sky-50 hover:border-cyan-200 transition-all flex flex-col gap-4 group">
                            <div className="w-8 h-8 rounded-full bg-white flex items-center justify-center text-xs font-black text-slate-400 border border-sky-100 group-hover:bg-cyan-600 group-hover:text-white group-hover:border-cyan-600 transition-colors">
                                {idx + 1}
                            </div>
                            <p className="text-xs font-bold leading-relaxed text-slate-600 group-hover:text-slate-900 transition-colors">{bench}</p>
                        </div>
                    ))}
                </div>
            </div>

            {/* DISCLOSURE */}
            <div className="p-8 bg-amber-50 rounded-[2.5rem] border border-amber-100 flex gap-6">
                <AlertCircle className="text-amber-600 shrink-0" size={24} />
                <p className="text-[10px] font-bold text-amber-700 uppercase tracking-widest leading-relaxed">
                    <strong className="text-amber-900">Predictive Modeling Disclaimer:</strong> This health cycle projection is a mathematical trajectory derived from AI pattern recognition. It does not replace diagnostic procedures. Sudden lifestyle changes or acute stressors may alter the projected biological path.
                </p>
            </div>
        </div>
    );
};

export default HealthCycleView;
