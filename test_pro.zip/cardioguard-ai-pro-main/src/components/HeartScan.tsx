import React, { useState, useEffect } from 'react';
import { Activity, Shield, X, Heart, Thermometer, Zap, ShieldCheck, Search, Loader2 } from 'lucide-react';

interface HeartScanProps {
  onClose: () => void;
  onComplete?: (result: any) => void;
}

const HeartScan: React.FC<HeartScanProps> = ({ onClose, onComplete }) => {
  const [progress, setProgress] = useState(0);
  const [status, setStatus] = useState("Initializing Optical Uplink...");
  const [isComplete, setIsComplete] = useState(false);

  useEffect(() => {
    const interval = setInterval(() => {
      setProgress(prev => {
        const next = prev + Math.random() * 2;
        if (next >= 100) {
          clearInterval(interval);
          setIsComplete(true);
          return 100;
        }

        // Dynamic Status Mapping
        if (next > 80) setStatus("Finalizing Biological Report...");
        else if (next > 60) setStatus("Mapping Myocardial Velocity...");
        else if (next > 40) setStatus("Analyzing Chamber Dynamics...");
        else if (next > 20) setStatus("Calibrating Signal-to-Noise...");

        return next;
      });
    }, 100);
    return () => clearInterval(interval);
  }, []);

  return (
    <div className="fixed inset-0 z-[1000] bg-slate-950/95 backdrop-blur-xl flex flex-col items-center justify-center p-6 animate-in fade-in duration-500">

      {/* CLOSE BUTTON */}
      <button onClick={onClose} className="absolute top-8 right-8 p-3 bg-white/5 rounded-2xl hover:bg-white/10 transition-colors">
        <X className="text-white" />
      </button>

      {/* MAIN SCANNER UI */}
      <div className="relative w-full max-w-lg aspect-square flex flex-col items-center justify-center">

        {/* DECORATIVE SCANNING CIRCLES */}
        <div className="absolute inset-0 border-2 border-cyan-500/20 rounded-full animate-ping opacity-25"></div>
        <div className="absolute inset-4 border border-cyan-500/10 rounded-full animate-pulse"></div>

        {/* HEART VISUALIZATION */}
        <div className={`relative transition-all duration-1000 ${isComplete ? 'scale-110 opacity-50' : 'animate-heartbeat'}`}>
          <Heart size={160} className={`${isComplete ? 'text-emerald-500' : 'text-rose-600'} fill-current filter drop-shadow-[0_0_30px_rgba(225,29,72,0.4)]`} />

          {/* SVG SCANNING LINE */}
          {!isComplete && (
            <div className="absolute inset-0 overflow-hidden rounded-full">
              <div className="absolute top-0 left-0 w-full h-1 bg-cyan-400 shadow-[0_0_15px_rgba(34,211,238,0.8)] animate-scan"></div>
            </div>
          )}
        </div>

        {/* PROGRESS TEXT */}
        <div className="mt-16 text-center space-y-4">
          <div className="text-5xl font-black text-white tracking-tighter tabular-nums">
            {Math.floor(progress)}%
          </div>
          <div className="flex flex-col items-center gap-2">
            <p className="text-[10px] font-black uppercase tracking-[0.4em] text-cyan-500 flex items-center gap-2">
              {isComplete ? (
                <><ShieldCheck size={14} className="text-emerald-500" /> Assessment Synced</>
              ) : (
                <><Loader2 size={14} className="animate-spin" /> {status}</>
              )}
            </p>
          </div>
        </div>
      </div>

      {/* LIVE TELEMETRY CARDS (SIDE) */}
      <div className="flex gap-4 mt-8 w-full max-w-md">
        <TelemetryMiniCard icon={<Activity size={12} />} label="H-RATE" value={isComplete ? "72" : "--"} unit="BPM" />
        <TelemetryMiniCard icon={<Thermometer size={12} />} label="TEMP" value={isComplete ? "98.6" : "--"} unit="°F" />
        <TelemetryMiniCard icon={<Zap size={12} />} label="VND" value={isComplete ? "Optimal" : "--"} />
      </div>

      {/* RESULTS VIEW */}
      {isComplete && (
        <div className="mt-12 animate-in slide-in-from-bottom-5 duration-700 w-full max-w-md">
          <button
            onClick={() => {
              if (onComplete) onComplete({ status: 'success', data: { heartRate: 72 } });
              onClose();
            }}
            className="w-full py-6 bg-emerald-600 hover:bg-emerald-500 text-white rounded-3xl font-black uppercase tracking-[0.2em] shadow-lg shadow-emerald-500/20 transition-all flex items-center justify-center gap-4"
          >
            View Full Clinical Delta <Shield size={18} />
          </button>
        </div>
      )}
    </div>
  );
};

function TelemetryMiniCard({ icon, label, value, unit }: any) {
  return (
    <div className="flex-1 bg-white/5 border border-white/10 rounded-2xl p-4 text-center">
      <div className="flex items-center justify-center gap-2 mb-2">
        <div className="text-cyan-500">{icon}</div>
        <span className="text-[8px] font-black text-slate-500 uppercase tracking-widest">{label}</span>
      </div>
      <div className="text-lg font-black text-white">
        {value} <span className="text-[10px] text-slate-500">{unit}</span>
      </div>
    </div>
  );
}

export default HeartScan;
