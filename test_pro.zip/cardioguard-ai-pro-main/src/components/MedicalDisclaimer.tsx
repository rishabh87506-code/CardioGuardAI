import React from 'react';
import { ShieldAlert } from 'lucide-react';

const MedicalDisclaimer: React.FC = () => {
    return (
        <div className="p-6 rounded-[2rem] bg-amber-50 border border-amber-100 flex gap-4 shadow-sm my-6">
            <ShieldAlert className="w-6 h-6 text-amber-600 shrink-0 mt-0.5" />
            <div className="text-[10px] text-amber-800 leading-relaxed font-black uppercase tracking-wider">
                <strong className="text-amber-900">Mandatory Medical Notice:</strong> CardioGuard AI is a prototype analytical tool and is NOT FDA-cleared for diagnosis, treatment, or clinical prevention. All predictions are generated via the research-grade XGBoost ensemble and are for educational/informational purposes only. Always consult a licensed cardiologist for medical decisions. In case of emergency, contact your local emergency services (e.g., 911/102) immediately.
            </div>
        </div>
    );
};

export default MedicalDisclaimer;
