import React, { useState, useEffect, useRef } from 'react';
import { X, Send, Activity, Sparkles, User, Cpu, AlertCircle, Loader2 } from 'lucide-react';
import { getConciergeResponse } from '../services/geminiService';
import { createClient } from '../../lib/supabase/client';

interface Message {
    role: 'user' | 'model';
    content: string;
}

interface CardioChatProps {
    onClose: () => void;
    currentAssessment?: any;
}

const CardioChat: React.FC<CardioChatProps> = ({ onClose, currentAssessment }) => {
    const [messages, setMessages] = useState<Message[]>([
        { role: 'model', content: "Hello! I'm your CardioGuard AI assistant. I'm here to provide preventive cardiovascular guidance. How can I assist you with your heart health today?" }
    ]);
    const [input, setInput] = useState('');
    const [isLoading, setIsLoading] = useState(false);
    const [profile, setProfile] = useState<any>(null);
    const messagesEndRef = useRef<HTMLDivElement>(null);

    const supabase = createClient();

    useEffect(() => {
        const fetchProfile = async () => {
            const { data: { user } } = await supabase.auth.getUser();
            if (user) {
                const { data } = await supabase.from('profiles').select('*').eq('id', user.id).single();
                setProfile(data);
            }
        };
        fetchProfile();
    }, []);

    useEffect(() => {
        messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
    }, [messages]);

    const handleSend = async () => {
        if (!input.trim() || isLoading) return;

        const userMessage = input.trim();
        setInput('');
        setMessages(prev => [...prev, { role: 'user', content: userMessage }]);
        setIsLoading(true);

        try {
            // Prepare history for API
            const history = messages.map(m => ({
                role: m.role,
                content: m.content
            }));

            const response = await getConciergeResponse(userMessage, profile, currentAssessment, history as any);
            setMessages(prev => [...prev, { role: 'model', content: response }]);
        } catch (error) {
            setMessages(prev => [...prev, { role: 'model', content: "I'm sorry, I'm having trouble connecting to my intelligence core. Please check your connection." }]);
        } finally {
            setIsLoading(false);
        }
    };

    return (
        <div className="fixed inset-0 z-[1200] bg-slate-950/80 backdrop-blur-xl flex items-center justify-center p-4 font-inter">
            <div className="w-full max-w-2xl h-[80vh] bg-slate-900 border border-white/10 rounded-[2.5rem] shadow-2xl flex flex-col overflow-hidden animate-in zoom-in-95 duration-300">

                {/* HEADER */}
                <div className="p-6 border-b border-white/5 flex items-center justify-between bg-white/5">
                    <div className="flex items-center gap-4">
                        <div className="bg-blue-600 p-2.5 rounded-2xl shadow-lg shadow-blue-500/20">
                            <Sparkles className="w-5 h-5 text-white" />
                        </div>
                        <div>
                            <h2 className="text-xl font-black text-white tracking-tight">AI Health Concierge</h2>
                            <div className="flex items-center gap-2 mt-0.5">
                                <div className="w-1.5 h-1.5 bg-emerald-500 rounded-full animate-pulse" />
                                <span className="text-[10px] font-black text-emerald-400 uppercase tracking-widest">Guidance Active</span>
                            </div>
                        </div>
                    </div>
                    <button onClick={onClose} className="p-2 text-white/30 hover:text-white transition-colors">
                        <X size={24} />
                    </button>
                </div>

                {/* MESSAGES */}
                <div className="flex-1 overflow-y-auto p-6 space-y-6 no-scrollbar">
                    {messages.map((m, i) => (
                        <div key={i} className={`flex ${m.role === 'user' ? 'justify-end' : 'justify-start'} animate-in slide-in-from-bottom-2`}>
                            <div className={`max-w-[80%] flex gap-4 ${m.role === 'user' ? 'flex-row-reverse' : ''}`}>
                                <div className={`w-8 h-8 rounded-full flex items-center justify-center shrink-0 ${m.role === 'user' ? 'bg-blue-600' : 'bg-slate-800 border border-white/10'}`}>
                                    {m.role === 'user' ? <User size={16} className="text-white" /> : <Cpu size={16} className="text-blue-400" />}
                                </div>
                                <div className={`p-4 rounded-3xl text-sm leading-relaxed ${m.role === 'user' ? 'bg-blue-600 text-white rounded-tr-none' : 'bg-white/5 text-blue-50 rounded-tl-none border border-white/5'}`}>
                                    {m.content}
                                </div>
                            </div>
                        </div>
                    ))}
                    {isLoading && (
                        <div className="flex justify-start animate-pulse">
                            <div className="flex gap-4">
                                <div className="w-8 h-8 rounded-full bg-slate-800 border border-white/10 flex items-center justify-center">
                                    <Cpu size={16} className="text-blue-400" />
                                </div>
                                <div className="bg-white/5 border border-white/5 p-4 rounded-3xl text-blue-200 text-xs font-bold uppercase tracking-widest flex items-center gap-3">
                                    <Loader2 size={14} className="animate-spin" /> Analyzing Biometrics...
                                </div>
                            </div>
                        </div>
                    )}
                    <div ref={messagesEndRef} />
                </div>

                {/* FOOTER INPUT */}
                <div className="p-6 bg-white/5 border-t border-white/5">
                    <div className="relative">
                        <input
                            type="text"
                            value={input}
                            onChange={(e) => setInput(e.target.value)}
                            onKeyPress={(e) => e.key === 'Enter' && handleSend()}
                            placeholder="Ask about diet, exercise, or your risk factors..."
                            className="w-full bg-white/5 border border-white/10 rounded-2xl px-6 py-4 text-white placeholder:text-white/20 focus:outline-none focus:border-blue-500 transition-all font-medium pr-16"
                        />
                        <button
                            onClick={handleSend}
                            disabled={isLoading || !input.trim()}
                            className="absolute right-2 top-2 bottom-2 px-4 bg-blue-600 text-white rounded-xl hover:bg-blue-500 disabled:opacity-50 transition-all flex items-center justify-center shadow-lg"
                        >
                            <Send size={18} />
                        </button>
                    </div>

                    <div className="mt-4 flex items-center justify-center gap-2">
                        <AlertCircle size={10} className="text-white/20" />
                        <p className="text-[10px] font-bold text-white/20 uppercase tracking-[0.2em]">
                            Not a substitute for professional medical advice.
                        </p>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default CardioChat;
