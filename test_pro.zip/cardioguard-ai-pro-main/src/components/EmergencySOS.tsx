import React, { useState, useEffect } from 'react';
import { ShieldAlert, MapPin, PhoneCall, X, Loader2, AlertCircle, Send } from 'lucide-react';
import { triggerSOS } from '../services/supabaseService';

interface EmergencySOSProps {
  autoPrompt?: boolean;
  onClose?: () => void;
  patientId?: string;
}

const EmergencySOS: React.FC<EmergencySOSProps> = ({ autoPrompt = false, onClose, patientId }) => {
  const [isOpen, setIsOpen] = useState(autoPrompt);
  const [location, setLocation] = useState<{ lat: number, lng: number } | null>(null);
  const [isLocating, setIsLocating] = useState(false);
  const [status, setStatus] = useState<'idle' | 'locating' | 'ready' | 'sent'>('idle');
  const [error, setError] = useState<string | null>(null);

  const requestLocation = () => {
    setIsLocating(true);
    setStatus('locating');
    if (!navigator.geolocation) {
      setError("Geolocation is not supported by your browser.");
      setIsLocating(false);
      setStatus('idle');
      return;
    }

    navigator.geolocation.getCurrentPosition(
      (pos) => {
        setLocation({ lat: pos.coords.latitude, lng: pos.coords.longitude });
        setIsLocating(false);
        setStatus('ready');
      },
      (err) => {
        setError("Location permission denied. Ensure GPS is enabled.");
        setIsLocating(false);
        setStatus('idle');
      },
      { enableHighAccuracy: true, timeout: 10000 }
    );
  };

  const handleSOS = async () => {
    setStatus('sent');

    // Trigger backend dispatch log
    if (patientId && location) {
      await triggerSOS(patientId, location, "Manual SOS Button Triggered");
    }

    // In a real app, this would trigger a dispatch through a secure API
    setTimeout(() => {
      window.location.href = `tel:911`; // Fallback to standard emergency call
    }, 2000);
  };

  if (!isOpen) {
    return (
      <button
        onClick={() => { setIsOpen(true); requestLocation(); }}
        className="bg-rose-600 hover:bg-rose-700 text-white p-5 rounded-full shadow-[0_15px_35px_rgba(225,29,72,0.4)] transition-all animate-bounce flex items-center justify-center group"
      >
        <ShieldAlert className="w-8 h-8 group-hover:scale-110 transition-transform" />
      </button>
    );
  }

  return (
    <div className="fixed inset-0 z-[200] bg-slate-950/90 backdrop-blur-2xl flex items-center justify-center p-6 animate-in fade-in duration-300">
      <div className="max-w-md w-full bg-white rounded-[3rem] p-8 space-y-8 shadow-2xl relative overflow-hidden border-4 border-rose-600">
        <div className="absolute top-0 right-0 p-6">
          <button onClick={() => { setIsOpen(false); onClose?.(); }} className="p-2 text-slate-300 hover:text-slate-900 transition-colors">
            <X className="w-6 h-6" />
          </button>
        </div>

        <div className="text-center space-y-4">
          <div className="inline-flex p-6 bg-rose-600 rounded-[2rem] shadow-2xl shadow-rose-900/20 animate-pulse">
            <ShieldAlert className="w-12 h-12 text-white" />
          </div>
          <h2 className="text-3xl font-black text-slate-950 tracking-tighter">Emergency SOS Engaged</h2>
          <p className="text-slate-500 font-bold leading-relaxed">
            Clinical analysis indicates critical cardiovascular distress. Geo-tagged medical response is standby.
          </p>
        </div>

        <div className="bg-slate-50 p-6 rounded-[2rem] border border-slate-100 space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <MapPin className={`w-5 h-5 ${location ? 'text-emerald-500' : 'text-slate-300'}`} />
              <span className="text-[10px] font-black uppercase tracking-widest text-slate-950">Current Coordinates</span>
            </div>
            {isLocating && <Loader2 className="w-4 h-4 animate-spin text-blue-600" />}
          </div>

          {location ? (
            <div className="bg-white p-4 rounded-2xl border border-emerald-100 text-emerald-900 font-black tracking-tight flex items-center justify-between">
              <span>{location.lat.toFixed(5)}, {location.lng.toFixed(5)}</span>
              <div className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></div>
            </div>
          ) : (
            <button
              onClick={requestLocation}
              className="w-full py-4 bg-slate-200 text-slate-600 rounded-2xl font-black text-xs uppercase tracking-widest"
            >
              Recalibrate Location
            </button>
          )}

          {error && (
            <div className="flex items-center gap-2 p-3 bg-rose-50 text-rose-600 rounded-xl text-[10px] font-black uppercase tracking-widest">
              <AlertCircle className="w-4 h-4" />
              {error}
            </div>
          )}
        </div>

        <div className="space-y-4 pt-4">
          <button
            disabled={status === 'sent'}
            onClick={handleSOS}
            className={`w-full py-6 rounded-[2rem] font-black text-xl transition-all flex items-center justify-center gap-4 shadow-2xl uppercase tracking-[0.2em] ${status === 'sent' ? 'bg-emerald-600 text-white' : 'bg-rose-600 hover:bg-rose-700 text-white shadow-rose-900/40'
              }`}
          >
            {status === 'sent' ? (
              <>
                <Send className="w-6 h-6 animate-out fade-out" />
                Dossier Relayed
              </>
            ) : (
              <>
                <PhoneCall className="w-6 h-6" />
                Dispatch Response
              </>
            )}
          </button>

          <p className="text-[9px] text-center font-black text-slate-400 uppercase tracking-[0.4em]">
            AES-256 Encrypted Telemetry Active
          </p>
        </div>
      </div>
    </div>
  );
};

export default EmergencySOS;
