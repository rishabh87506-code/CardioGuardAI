
import React, { useState } from 'react';
import { Pill, Plus, Trash2, ShieldCheck, Clock, Info, Activity } from 'lucide-react';
import { Medication, SupportedLanguage } from '../types';

interface MedicationVaultProps {
  meds: Medication[];
  onAdd: (med: Omit<Medication, 'id'>) => void;
  onDelete: (id: string) => void;
  onUpdate: (meds: Medication[]) => void;
  onBack: () => void;
  language: SupportedLanguage;
}

const MedicationVault: React.FC<MedicationVaultProps> = ({ meds, onAdd, onDelete, onUpdate, onBack, language }) => {
  const [showAdd, setShowAdd] = useState(false);
  const [newMed, setNewMed] = useState({ name: '', dosage: '', frequency: '', purpose: '' });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newMed.name) return;
    onAdd(newMed);
    setNewMed({ name: '', dosage: '', frequency: '', purpose: '' });
    setShowAdd(false);
  };

  return (
    <div className="space-y-6 animate-in fade-in slide-in-from-bottom-4 duration-500">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-black text-slate-900 flex items-center gap-3">
          <Pill className="w-6 h-6 text-indigo-600" />
          Medication Vault
        </h2>
        <button
          onClick={() => setShowAdd(!showAdd)}
          className="p-2 bg-slate-900 text-white rounded-xl shadow-lg hover:bg-slate-800 transition-all"
        >
          <Plus className="w-6 h-6" />
        </button>
      </div>

      {showAdd && (
        <form onSubmit={handleSubmit} className="bg-white p-6 rounded-[2rem] border border-blue-100 shadow-xl space-y-4 animate-in slide-in-from-top-4 duration-300">
          <div className="grid grid-cols-2 gap-4">
            <div className="col-span-2">
              <label className="text-[10px] font-black uppercase text-slate-400 ml-1">Medication Name</label>
              <input
                type="text"
                placeholder="e.g. Atorvastatin"
                className="w-full mt-1 px-4 py-3 bg-slate-50 border border-slate-100 rounded-xl outline-none focus:ring-2 focus:ring-blue-500"
                value={newMed.name}
                onChange={e => setNewMed({ ...newMed, name: e.target.value })}
              />
            </div>
            <div>
              <label className="text-[10px] font-black uppercase text-slate-400 ml-1">Dosage</label>
              <input
                type="text"
                placeholder="20mg"
                className="w-full mt-1 px-4 py-3 bg-slate-50 border border-slate-100 rounded-xl outline-none focus:ring-2 focus:ring-blue-500"
                value={newMed.dosage}
                onChange={e => setNewMed({ ...newMed, dosage: e.target.value })}
              />
            </div>
            <div>
              <label className="text-[10px] font-black uppercase text-slate-400 ml-1">Frequency</label>
              <input
                type="text"
                placeholder="Daily (Morning)"
                className="w-full mt-1 px-4 py-3 bg-slate-50 border border-slate-100 rounded-xl outline-none focus:ring-2 focus:ring-blue-500"
                value={newMed.frequency}
                onChange={e => setNewMed({ ...newMed, frequency: e.target.value })}
              />
            </div>
          </div>
          <button type="submit" className="w-full py-4 bg-blue-600 text-white font-black rounded-2xl shadow-blue-200 shadow-xl">
            SECURELY ADD MEDICINE
          </button>
        </form>
      )}

      {meds.length === 0 ? (
        <div className="flex flex-col items-center justify-center py-20 text-center space-y-4 bg-white rounded-[2.5rem] border border-slate-100 shadow-sm">
          <div className="p-4 bg-indigo-50 rounded-full">
            <Pill className="w-10 h-10 text-indigo-200" />
          </div>
          <div className="max-w-xs">
            <h3 className="text-xl font-bold text-slate-900">No Prescriptions Found</h3>
            <p className="text-slate-500 mt-2 text-sm leading-relaxed">Log your heart-related medications here to keep your clinical profile up to date.</p>
          </div>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {meds.map(med => (
            <div key={med.id} className="bg-white p-6 rounded-3xl border border-slate-100 shadow-sm relative group hover:shadow-md transition-all">
              <button
                onClick={() => onDelete(med.id)}
                className="absolute top-4 right-4 p-2 text-slate-200 hover:text-rose-500 hover:bg-rose-50 rounded-lg transition-all"
              >
                <Trash2 className="w-4 h-4" />
              </button>

              <div className="flex items-start gap-4">
                <div className="p-3 bg-indigo-50 rounded-2xl">
                  <Pill className="w-6 h-6 text-indigo-600" />
                </div>
                <div>
                  <h4 className="text-lg font-black text-slate-900 leading-tight">{med.name}</h4>
                  <div className="flex items-center gap-3 mt-2">
                    <div className="flex items-center gap-1 text-[10px] font-bold text-slate-400">
                      <Activity className="w-3 h-3" />
                      {med.dosage}
                    </div>
                    <div className="flex items-center gap-1 text-[10px] font-bold text-slate-400">
                      <Clock className="w-3 h-3" />
                      {med.frequency}
                    </div>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      <div className="p-6 bg-slate-900 rounded-[2rem] text-white flex items-center gap-4">
        <ShieldCheck className="w-8 h-8 text-emerald-400" />
        <div>
          <h5 className="font-bold text-sm">Clinical Interaction Shield</h5>
          <p className="text-[10px] text-slate-400 uppercase tracking-widest font-black mt-1">Local Encryption Active</p>
        </div>
      </div>
    </div>
  );
};

export default MedicationVault;
