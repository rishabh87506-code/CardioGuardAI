
import React, { useState, useEffect } from 'react';
import {
    CheckCircle2,
    AlertTriangle,
    TrendingUp,
    TrendingDown,
    Minus,
    Activity,
    Heart,
    Brain,
    Shield,
    Calendar,
    Target,
    Sparkles,
    ChevronRight,
    RefreshCw,
    FileText,
    BookOpen,
    Lightbulb,
    Clock,
    Award,
    ArrowRight
} from 'lucide-react';
import { SupportedLanguage } from '../types';
import {
    getMemorySnapshot,
    shouldPromptAssessment,
    getSymptomFrequency,
    MemorySnapshot,
    SymptomSeverity
} from '../services/symptomMemoryService';
import { WORST_CVD_RISKS, CRITICAL_SYMPTOM_PATTERNS } from '../services/researchService';

interface SelfEvaluationProps {
    onBack: () => void;
    language: SupportedLanguage; // Assuming SupportedLanguage is defined elsewhere
    onStartAssessment: () => void;
}

const SelfEvaluation: React.FC<SelfEvaluationProps> = ({ onBack, language, onStartAssessment }) => {
    const [memory, setMemory] = useState<MemorySnapshot | null>(null);
    const [assessmentPrompt, setAssessmentPrompt] = useState<{ shouldPrompt: boolean; reason: string } | null>(null);
    const [symptomFrequency, setSymptomFrequency] = useState<Map<string, number>>(new Map());
    const [showEducation, setShowEducation] = useState(false);

    useEffect(() => {
        loadData();
    }, []);

    const loadData = () => {
        setMemory(getMemorySnapshot());
        setAssessmentPrompt(shouldPromptAssessment());
        setSymptomFrequency(getSymptomFrequency(30));
    };

    const getTrendIcon = (trend: string) => {
        switch (trend) {
            case 'INCREASING':
                return <TrendingUp className="w-5 h-5 text-rose-500" />;
            case 'DECREASING':
                return <TrendingDown className="w-5 h-5 text-emerald-500" />;
            default:
                return <Minus className="w-5 h-5 text-slate-400" />;
        }
    };

    const getTrendColor = (trend: string) => {
        switch (trend) {
            case 'INCREASING':
                return 'text-rose-600 bg-rose-50 border-rose-200';
            case 'DECREASING':
                return 'text-emerald-600 bg-emerald-50 border-emerald-200';
            default:
                return 'text-slate-600 bg-slate-50 border-slate-200';
        }
    };

    const keyHighlights = [
        {
            id: 'ai_analysis',
            title: 'AI-Powered Risk Analysis',
            description: 'Gemini AI analyzes your vitals using evidence from major clinical studies',
            icon: Brain,
            status: 'ACTIVE',
            color: 'text-indigo-600 bg-indigo-50'
        },
        {
            id: 'symptom_memory',
            title: 'Symptom Memory System',
            description: 'Your symptoms are tracked and compared to detect worsening patterns',
            icon: Activity,
            status: 'ACTIVE',
            color: 'text-blue-600 bg-blue-50'
        },
        {
            id: 'womens_health',
            title: "Women's Health Sentinel",
            description: 'Specialized detection for SCAD, PPCM, Takotsubo and other female-specific conditions',
            icon: Heart,
            status: 'ACTIVE',
            color: 'text-pink-600 bg-pink-50'
        },
        {
            id: 'wearable_integration',
            title: 'Wearable Connectivity',
            description: 'Real-time data from Bluetooth heart rate monitors and BP devices',
            icon: Shield,
            status: 'AVAILABLE',
            color: 'text-purple-600 bg-purple-50'
        },
        {
            id: 'research_backed',
            title: 'PubMed Research Integration',
            description: 'Risk assessments cite Framingham, INTERHEART and latest CVD studies',
            icon: BookOpen,
            status: 'ACTIVE',
            color: 'text-emerald-600 bg-emerald-50'
        }
    ];

    const futureFeatures = [
        {
            title: 'ECG Analysis via Smartphone',
            quarter: 'Q2 2026',
            description: 'Apple Watch and Samsung Galaxy ECG data integration'
        },
        {
            title: 'Continuous Glucose Monitoring',
            quarter: 'Q2 2026',
            description: 'For enhanced diabetic cardiovascular risk assessment'
        },
        {
            title: 'Family History AI',
            quarter: 'Q3 2026',
            description: 'Genetic risk stratification based on family tree analysis'
        },
        {
            title: 'Telehealth Integration',
            quarter: 'Q3 2026',
            description: 'Direct video consultation with cardiologists'
        },
        {
            title: 'Predictive Alerts',
            quarter: 'Q4 2026',
            description: 'ML-based prediction of cardiac events 24-48 hours ahead'
        }
    ];

    return (
        <div className="space-y-8 animate-in fade-in duration-500 pb-24">
            {/* Assessment Prompt Banner */}
            {assessmentPrompt?.shouldPrompt && (
                <div className="bg-gradient-to-r from-blue-600 to-indigo-600 rounded-3xl p-6 text-white shadow-xl">
                    <div className="flex items-start gap-4">
                        <div className="p-3 bg-white/20 rounded-2xl backdrop-blur-sm">
                            <Clock className="w-6 h-6" />
                        </div>
                        <div className="flex-1">
                            <h3 className="text-lg font-black">Time for a Check-In</h3>
                            <p className="text-white/80 text-sm font-medium mt-1">{assessmentPrompt.reason}</p>
                            <button
                                onClick={onStartAssessment}
                                className="mt-4 px-6 py-3 bg-white text-blue-600 rounded-xl font-black text-sm uppercase tracking-widest hover:bg-blue-50 transition-all flex items-center gap-2"
                            >
                                Start Assessment
                                <ArrowRight className="w-4 h-4" />
                            </button>
                        </div>
                    </div>
                </div>
            )}

            {/* Your Health Summary */}
            <section className="bg-white rounded-3xl p-8 border border-slate-200 shadow-sm">
                <div className="flex items-center justify-between mb-6">
                    <div className="flex items-center gap-3">
                        <div className="p-2 bg-slate-100 rounded-xl">
                            <Target className="w-5 h-5 text-slate-600" />
                        </div>
                        <h2 className="text-xl font-black text-slate-900">Your Health Summary</h2>
                    </div>
                    <button
                        onClick={loadData}
                        className="p-2 hover:bg-slate-100 rounded-xl transition-colors"
                    >
                        <RefreshCw className="w-5 h-5 text-slate-400" />
                    </button>
                </div>

                <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
                    <div className="bg-slate-50 rounded-2xl p-4 text-center border border-slate-100">
                        <p className="text-3xl font-black text-slate-900">{memory?.totalAssessments || 0}</p>
                        <p className="text-[10px] font-bold text-slate-500 uppercase tracking-widest mt-1">Total Assessments</p>
                    </div>

                    <div className="bg-slate-50 rounded-2xl p-4 text-center border border-slate-100">
                        <p className="text-3xl font-black text-slate-900">{memory?.symptoms.length || 0}</p>
                        <p className="text-[10px] font-bold text-slate-500 uppercase tracking-widest mt-1">Symptoms Tracked</p>
                    </div>

                    <div className={`rounded-2xl p-4 text-center border ${getTrendColor(memory?.riskTrend || 'STABLE')}`}>
                        <div className="flex items-center justify-center gap-2">
                            {getTrendIcon(memory?.riskTrend || 'STABLE')}
                            <p className="text-lg font-black">{memory?.riskTrend || 'STABLE'}</p>
                        </div>
                        <p className="text-[10px] font-bold uppercase tracking-widest mt-1 opacity-70">Risk Trend</p>
                    </div>

                    <div className="bg-slate-50 rounded-2xl p-4 text-center border border-slate-100">
                        <p className="text-3xl font-black text-slate-900">
                            {memory?.lastAssessment
                                ? Math.floor((Date.now() - memory.lastAssessment) / (24 * 60 * 60 * 1000))
                                : '—'}
                        </p>
                        <p className="text-[10px] font-bold text-slate-500 uppercase tracking-widest mt-1">Days Since Last</p>
                    </div>
                </div>

                {/* Symptom Frequency */}
                {symptomFrequency.size > 0 && (
                    <div className="mt-6 pt-6 border-t border-slate-100">
                        <h3 className="text-sm font-black text-slate-700 uppercase tracking-widest mb-4">
                            Top Symptoms (Last 30 Days)
                        </h3>
                        <div className="flex flex-wrap gap-2">
                            {Array.from(symptomFrequency.entries())
                                .sort((a, b) => b[1] - a[1])
                                .slice(0, 5)
                                .map(([symptom, count]) => (
                                    <span
                                        key={symptom}
                                        className="px-3 py-1.5 bg-slate-100 rounded-full text-sm font-bold text-slate-700"
                                    >
                                        {symptom} ({count}x)
                                    </span>
                                ))
                            }
                        </div>
                    </div>
                )}
            </section>

            {/* Key Highlights - System Capabilities */}
            <section className="bg-white rounded-3xl p-8 border border-slate-200 shadow-sm">
                <div className="flex items-center gap-3 mb-6">
                    <div className="p-2 bg-amber-100 rounded-xl">
                        <Sparkles className="w-5 h-5 text-amber-600" />
                    </div>
                    <div>
                        <h2 className="text-xl font-black text-slate-900">Key Capabilities</h2>
                        <p className="text-sm text-slate-500 font-medium">What CardioGuard AI does for you</p>
                    </div>
                </div>

                <div className="space-y-4">
                    {keyHighlights.map((highlight) => (
                        <div
                            key={highlight.id}
                            className="flex items-center gap-4 p-4 rounded-2xl border border-slate-100 hover:border-slate-200 hover:bg-slate-50 transition-all"
                        >
                            <div className={`p-3 rounded-xl ${highlight.color}`}>
                                <highlight.icon className="w-5 h-5" />
                            </div>
                            <div className="flex-1">
                                <div className="flex items-center gap-2">
                                    <h3 className="font-black text-slate-900">{highlight.title}</h3>
                                    <span className={`px-2 py-0.5 rounded-full text-[8px] font-black uppercase tracking-widest ${highlight.status === 'ACTIVE'
                                        ? 'bg-emerald-100 text-emerald-700'
                                        : 'bg-slate-100 text-slate-500'
                                        }`}>
                                        {highlight.status}
                                    </span>
                                </div>
                                <p className="text-sm text-slate-500 font-medium mt-0.5">{highlight.description}</p>
                            </div>
                            <CheckCircle2 className="w-5 h-5 text-emerald-500 shrink-0" />
                        </div>
                    ))}
                </div>
            </section>

            {/* Evidence Base */}
            <section className="bg-white rounded-3xl p-8 border border-slate-200 shadow-sm">
                <button
                    onClick={() => setShowEducation(!showEducation)}
                    className="w-full flex items-center justify-between"
                >
                    <div className="flex items-center gap-3">
                        <div className="p-2 bg-blue-100 rounded-xl">
                            <BookOpen className="w-5 h-5 text-blue-600" />
                        </div>
                        <div className="text-left">
                            <h2 className="text-xl font-black text-slate-900">Clinical Evidence Base</h2>
                            <p className="text-sm text-slate-500 font-medium">Major studies powering our risk analysis</p>
                        </div>
                    </div>
                    <ChevronRight className={`w-6 h-6 text-slate-400 transition-transform ${showEducation ? 'rotate-90' : ''}`} />
                </button>

                {showEducation && (
                    <div className="mt-6 pt-6 border-t border-slate-100 space-y-6">
                        {Object.entries(WORST_CVD_RISKS).slice(0, 2).map(([key, study]) => (
                            <div key={key} className="bg-slate-50 rounded-2xl p-5 border border-slate-100">
                                <div className="flex items-center justify-between mb-3">
                                    <h3 className="font-black text-slate-900">{study.source}</h3>
                                    {'pmid' in study && (
                                        <a
                                            href={`https://pubmed.ncbi.nlm.nih.gov/${study.pmid}/`}
                                            target="_blank"
                                            rel="noopener noreferrer"
                                            className="text-[10px] font-bold text-blue-600 hover:underline uppercase tracking-widest"
                                        >
                                            PMID: {study.pmid}
                                        </a>
                                    )}
                                </div>
                                <div className="flex flex-wrap gap-2">
                                    {study.factors.slice(0, 4).map((factor: any) => (
                                        <span
                                            key={factor.name}
                                            className="px-2 py-1 bg-white rounded-lg text-xs font-bold text-slate-600 border border-slate-200"
                                        >
                                            {factor.name}
                                        </span>
                                    ))}
                                    {study.factors.length > 4 && (
                                        <span className="px-2 py-1 text-xs font-bold text-slate-400">
                                            +{study.factors.length - 4} more
                                        </span>
                                    )}
                                </div>
                            </div>
                        ))}
                    </div>
                )}
            </section>

            {/* Critical Symptom Awareness */}
            <section className="bg-gradient-to-br from-rose-50 to-orange-50 rounded-3xl p-8 border border-rose-200">
                <div className="flex items-center gap-3 mb-6">
                    <div className="p-2 bg-rose-100 rounded-xl">
                        <AlertTriangle className="w-5 h-5 text-rose-600" />
                    </div>
                    <div>
                        <h2 className="text-xl font-black text-slate-900">Know the Warning Signs</h2>
                        <p className="text-sm text-slate-600 font-medium">Critical symptoms that require immediate attention</p>
                    </div>
                </div>

                <div className="grid gap-4 sm:grid-cols-2">
                    {Object.values(CRITICAL_SYMPTOM_PATTERNS).slice(0, 4).map((pattern) => (
                        <div
                            key={pattern.name}
                            className="bg-white rounded-2xl p-4 border border-rose-100"
                        >
                            <div className="flex items-center justify-between mb-2">
                                <h3 className="font-bold text-slate-900 text-sm">{pattern.name}</h3>
                                <span className={`px-2 py-0.5 rounded-full text-[8px] font-black uppercase tracking-widest ${pattern.urgency === 'CALL_911'
                                    ? 'bg-rose-100 text-rose-700'
                                    : 'bg-amber-100 text-amber-700'
                                    }`}>
                                    {pattern.urgency}
                                </span>
                            </div>
                            <div className="flex flex-wrap gap-1.5">
                                {pattern.symptoms.slice(0, 3).map((symptom) => (
                                    <span
                                        key={symptom}
                                        className="px-2 py-0.5 bg-slate-50 rounded text-[10px] font-medium text-slate-600"
                                    >
                                        {symptom}
                                    </span>
                                ))}
                            </div>
                        </div>
                    ))}
                </div>
            </section>

            {/* Future Roadmap */}
            <section className="bg-white rounded-3xl p-8 border border-slate-200 shadow-sm">
                <div className="flex items-center gap-3 mb-6">
                    <div className="p-2 bg-indigo-100 rounded-xl">
                        <Lightbulb className="w-5 h-5 text-indigo-600" />
                    </div>
                    <div>
                        <h2 className="text-xl font-black text-slate-900">Coming Soon</h2>
                        <p className="text-sm text-slate-500 font-medium">Our roadmap for enhanced care</p>
                    </div>
                </div>

                <div className="space-y-3">
                    {futureFeatures.map((feature, index) => (
                        <div
                            key={index}
                            className="flex items-center gap-4 p-4 bg-slate-50 rounded-2xl border border-slate-100"
                        >
                            <div className="w-16 shrink-0">
                                <span className="text-[10px] font-black text-indigo-600 uppercase tracking-widest">{feature.quarter}</span>
                            </div>
                            <div className="flex-1">
                                <h4 className="font-bold text-slate-900">{feature.title}</h4>
                                <p className="text-sm text-slate-500">{feature.description}</p>
                            </div>
                            <Calendar className="w-5 h-5 text-slate-300 shrink-0" />
                        </div>
                    ))}
                </div>
            </section>

            {/* Safety Disclaimer */}
            <section className="bg-slate-900 rounded-3xl p-8 text-white">
                <div className="flex items-start gap-4">
                    <Shield className="w-8 h-8 text-blue-400 shrink-0" />
                    <div>
                        <h2 className="text-lg font-black mb-2">Medical Disclaimer</h2>
                        <p className="text-slate-300 text-sm leading-relaxed">
                            CardioGuard AI provides <strong>clinical decision support</strong>, not medical diagnoses.
                            All risk assessments are based on validated studies (Framingham, INTERHEART) but should
                            supplement, not replace, professional medical advice. In case of emergency symptoms
                            (chest pain, difficulty breathing, severe dizziness), call emergency services immediately.
                        </p>
                        <div className="flex flex-wrap gap-3 mt-4">
                            <span className="px-3 py-1 bg-white/10 rounded-lg text-[10px] font-bold uppercase tracking-widest">
                                HIPAA Aligned
                            </span>
                            <span className="px-3 py-1 bg-white/10 rounded-lg text-[10px] font-bold uppercase tracking-widest">
                                FDA Guidelines
                            </span>
                            <span className="px-3 py-1 bg-white/10 rounded-lg text-[10px] font-bold uppercase tracking-widest">
                                AHA Endorsed Studies
                            </span>
                        </div>
                    </div>
                </div>
            </section>
        </div>
    );
};

export default SelfEvaluation;
