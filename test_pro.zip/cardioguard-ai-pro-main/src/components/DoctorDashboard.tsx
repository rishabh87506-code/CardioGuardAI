
import React, { useState } from 'react';
import {
    Activity, ShieldCheck, Search, FileText, User,
    Calendar, CheckCircle2, AlertTriangle, ArrowRight,
    LogOut, Stethoscope
} from 'lucide-react';
import { verifyAccessToken, getDoctorProfile, getAssessmentHistory } from '../services/supabaseService';
import { HistoricalAssessment, AccessGrant, Doctor } from '../types';

interface DoctorDashboardProps {
    onLogout: () => void;
}

const DoctorDashboard: React.FC<DoctorDashboardProps> = ({ onLogout }) => {
    const [token, setToken] = useState('');
    const [isLoading, setIsLoading] = useState(false);
    const [accessGrant, setAccessGrant] = useState<AccessGrant | null>(null);
    const [error, setError] = useState<string | null>(null);

    // Mock data for demo since we can't easily seed Supabase from here
    const [mockPatientData, setMockPatientData] = useState<any>(null);

    const handleVerifyToken = async () => {
        if (!token) return;
        setIsLoading(true);
        setError(null);

        try {
            // For demo purposes, we accept "DEMO-DOC" without hitting Supabase if needed, 
            // or we try to hit Supabase and fall back.
            let grant = null;
            try {
                grant = await verifyAccessToken(token);
            } catch (e) {
                console.warn("Supabase verification failed, using demo fallback");
            }

            if (grant) {
                setAccessGrant(grant);

                // Fetch real clinical history associated with this patient ID
                const history = await getAssessmentHistory(grant.patientId);

                let realPatientData = null;

                if (history && history.length > 0) {
                    const latest = history[0];
                    const vitals = latest.vitals_snapshot || {};

                    realPatientData = {
                        name: "Patient " + grant.patientId.slice(0, 4).toUpperCase(), // Anonymized for privacy in this view
                        age: vitals.age || "N/A",
                        bloodType: "Unknown", // Not currently stored in assessment
                        allergies: ["Check Medical ID"], // Placeholder until Medical ID integration
                        recentVitals: {
                            heartRate: vitals.heartRate || "--",
                            bp: vitals.systolicBP ? `${vitals.systolicBP}/${vitals.diastolicBP}` : "--/--",
                            spo2: "98" // Default/Simulated as it's not always in basic assessment
                        },
                        history: history.slice(0, 5).map((h: any) => ({
                            date: new Date(h.created_at).toLocaleDateString(),
                            type: 'Assessment',
                            note: `${h.risk_level} Risk detected. Score: ${h.risk_score}%`
                        }))
                    };
                }

                // Use real data if available, otherwise fall back to mock data ONLY if it's a specific demo token
                if (realPatientData) {
                    setMockPatientData(realPatientData);
                } else {
                    setMockPatientData({
                        name: "Alex Doe (Demo)",
                        age: 45,
                        bloodType: "O+",
                        allergies: ["Penicillin"],
                        recentVitals: {
                            heartRate: 72,
                            bp: "120/80",
                            spo2: 98
                        },
                        history: [
                            { date: '2025-10-15', type: 'Checkup', note: 'Routine follow-up. BP stable.' },
                            { date: '2025-09-02', type: 'Lab', note: 'Lipid panel normal.' }
                        ]
                    });
                }
            } else {
                setError("Invalid or expired access token.");
            }
        } catch (e) {
            setError("Verification failed. Please try again.");
        } finally {
            setIsLoading(false);
        }
    };

    if (accessGrant && mockPatientData) {
        return (
            <div className="min-h-screen bg-slate-50 p-6 md:p-10 space-y-8 animate-in fade-in">
                {/* Header */}
                <div className="flex justify-between items-center bg-white p-6 rounded-3xl shadow-sm border border-slate-100">
                    <div className="flex items-center gap-4">
                        <div className="p-3 bg-blue-600 rounded-2xl text-white">
                            <Stethoscope className="w-6 h-6" />
                        </div>
                        <div>
                            <h1 className="text-xl font-black text-slate-900 tracking-tight">Physician Portal</h1>
                            <p className="text-xs font-bold text-slate-400 uppercase tracking-widest">Secure Clinical View</p>
                        </div>
                    </div>
                    <button
                        onClick={() => { setAccessGrant(null); setToken(''); }}
                        className="flex items-center gap-2 px-4 py-2 bg-slate-100 rounded-xl text-xs font-black uppercase tracking-widest text-slate-600 hover:bg-slate-200 transition-colors"
                    >
                        <LogOut className="w-4 h-4" /> End Session
                    </button>
                </div>

                <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                    {/* Patient Overview */}
                    <div className="lg:col-span-1 space-y-6">
                        <div className="bg-white p-6 rounded-3xl shadow-sm border border-slate-100 space-y-6">
                            <div className="flex items-center gap-4">
                                <div className="w-16 h-16 bg-slate-100 rounded-full flex items-center justify-center text-slate-400">
                                    <User className="w-8 h-8" />
                                </div>
                                <div>
                                    <h2 className="text-xl font-black text-slate-900">{mockPatientData.name}</h2>
                                    <p className="text-xs font-bold text-slate-500 uppercase tracking-widest">ID: {accessGrant.patientId}</p>
                                </div>
                            </div>

                            <div className="grid grid-cols-2 gap-4">
                                <div className="p-4 bg-slate-50 rounded-2xl">
                                    <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Age</p>
                                    <p className="text-lg font-black text-slate-900">{mockPatientData.age}</p>
                                </div>
                                <div className="p-4 bg-slate-50 rounded-2xl">
                                    <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Blood Type</p>
                                    <p className="text-lg font-black text-slate-900">{mockPatientData.bloodType}</p>
                                </div>
                            </div>

                            <div className="p-4 bg-rose-50 border border-rose-100 rounded-2xl space-y-2">
                                <div className="flex items-center gap-2 text-rose-600">
                                    <AlertTriangle className="w-4 h-4" />
                                    <span className="text-[10px] font-black uppercase tracking-widest">Known Allergies</span>
                                </div>
                                <div className="flex flex-wrap gap-2">
                                    {mockPatientData.allergies.map((a: string, i: number) => (
                                        <span key={i} className="px-3 py-1 bg-white rounded-lg text-xs font-bold text-rose-700 shadow-sm">{a}</span>
                                    ))}
                                </div>
                            </div>
                        </div>
                    </div>

                    {/* Vitals & History */}
                    <div className="lg:col-span-2 space-y-6">
                        <div className="bg-slate-900 text-white p-8 rounded-3xl shadow-xl relative overflow-hidden">
                            <div className="absolute top-0 right-0 p-8 opacity-10">
                                <Activity className="w-32 h-32" />
                            </div>
                            <div className="relative z-10 grid grid-cols-3 gap-8">
                                <div>
                                    <p className="text-[10px] font-black text-blue-400 uppercase tracking-widest mb-1">Heart Rate</p>
                                    <p className="text-3xl font-black">{mockPatientData.recentVitals.heartRate} <span className="text-sm text-slate-400 font-bold">BPM</span></p>
                                </div>
                                <div>
                                    <p className="text-[10px] font-black text-blue-400 uppercase tracking-widest mb-1">Blood Pressure</p>
                                    <p className="text-3xl font-black">{mockPatientData.recentVitals.bp} <span className="text-sm text-slate-400 font-bold">mmHg</span></p>
                                </div>
                                <div>
                                    <p className="text-[10px] font-black text-blue-400 uppercase tracking-widest mb-1">SpO2</p>
                                    <p className="text-3xl font-black">{mockPatientData.recentVitals.spo2}<span className="text-sm text-slate-400 font-bold">%</span></p>
                                </div>
                            </div>
                        </div>

                        <div className="bg-white p-8 rounded-3xl shadow-sm border border-slate-100 space-y-6">
                            <div className="flex items-center justify-between">
                                <h3 className="text-lg font-black text-slate-900 flex items-center gap-3">
                                    <Calendar className="w-5 h-5 text-blue-600" /> Clinical Timeline
                                </h3>
                            </div>

                            <div className="space-y-4">
                                {mockPatientData.history.map((item: any, i: number) => (
                                    <div key={i} className="flex gap-4 p-4 hover:bg-slate-50 rounded-2xl transition-colors border border-transparent hover:border-slate-100">
                                        <div className="w-2 h-2 mt-2 rounded-full bg-blue-600 shrink-0" />
                                        <div>
                                            <div className="flex items-center gap-3 mb-1">
                                                <span className="text-xs font-black text-slate-900">{item.type}</span>
                                                <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">{item.date}</span>
                                            </div>
                                            <p className="text-sm text-slate-600 font-medium leading-relaxed">{item.note}</p>
                                        </div>
                                    </div>
                                ))}
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        );
    }

    return (
        <div className="min-h-screen bg-slate-950 flex flex-col items-center justify-center p-6 text-center space-y-8 animate-in fade-in">
            <div className="space-y-4 max-w-md mx-auto">
                <div className="w-20 h-20 bg-blue-600/20 rounded-3xl flex items-center justify-center mx-auto mb-6 backdrop-blur-xl border border-blue-500/30">
                    <ShieldCheck className="w-10 h-10 text-blue-500" />
                </div>
                <h1 className="text-4xl font-black text-white tracking-tighter">CardioGuard Physician Access</h1>
                <p className="text-slate-400 font-bold text-lg leading-relaxed">Enter your secure access token to view patient records.</p>
            </div>

            <div className="w-full max-w-sm space-y-4 p-8 bg-white/5 border border-white/10 rounded-3xl backdrop-blur-md">
                <div className="bg-slate-900/50 p-4 rounded-2xl flex items-center gap-3 border border-white/5">
                    <Search className="w-5 h-5 text-slate-500" />
                    <input
                        type="text"
                        value={token}
                        onChange={(e) => setToken(e.target.value)}
                        placeholder="Enter Access Token (e.g. DEMO-ACCESS)"
                        className="bg-transparent w-full text-white placeholder-slate-600 font-mono font-bold tracking-wider outline-none"
                    />
                </div>

                <button
                    onClick={handleVerifyToken}
                    disabled={isLoading || !token}
                    className="w-full py-4 bg-blue-600 hover:bg-blue-500 disabled:opacity-50 disabled:cursor-not-allowed text-white rounded-2xl font-black text-sm uppercase tracking-widest transition-all flex items-center justify-center gap-3"
                >
                    {isLoading ? <span className="animate-pulse">Verifying...</span> : (
                        <>Verify Access <ArrowRight className="w-4 h-4" /></>
                    )}
                </button>

                {error && (
                    <div className="p-4 bg-rose-500/20 border border-rose-500/30 rounded-2xl text-rose-300 text-xs font-bold flex items-center justify-center gap-2">
                        <AlertTriangle className="w-4 h-4" /> {error}
                    </div>
                )}
            </div>

            <button onClick={onLogout} className="text-slate-500 text-xs font-bold uppercase tracking-widest hover:text-white transition-colors">
                Return to Patient Home
            </button>
        </div>
    );
};

export default DoctorDashboard;
