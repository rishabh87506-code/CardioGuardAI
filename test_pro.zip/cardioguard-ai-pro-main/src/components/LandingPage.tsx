import React from 'react';
import { Link } from 'react-router-dom';
import { ArrowRight, ShieldCheck, HeartPulse, Shield, Activity, Globe, ChevronRight } from 'lucide-react';

const LandingPage = ({ onLogin, onLaunch }: { onLogin: () => void; onLaunch: () => void }) => {
    return (
        <div className="min-h-screen bg-gradient-to-b from-slate-950 via-blue-950 to-indigo-950 text-white flex flex-col font-inter selection:bg-cyan-500/30">

            {/* Disclaimer Banner - Prominent & Non-Dismissible */}
            <div className="bg-rose-900/90 text-rose-100 py-3 px-4 text-center text-[10px] font-black uppercase tracking-widest border-b border-rose-800/50 backdrop-blur-md sticky top-0 z-[100]">
                <div className="flex items-center justify-center gap-3">
                    <Shield size={14} className="animate-pulse" />
                    <span><strong>Research Prototype v4.0:</strong> Not FDA-cleared. Not for clinical diagnosis. In emergencies, call 911/102 immediately.</span>
                </div>
            </div>

            {/* Hero Section */}
            <header className="flex-1 flex flex-col items-center justify-center px-6 py-20 text-center relative overflow-hidden">
                {/* Background Elements */}
                <div className="absolute top-20 left-1/4 w-96 h-96 bg-cyan-600/10 rounded-full blur-[120px] -z-10 animate-pulse"></div>
                <div className="absolute bottom-20 right-1/4 w-96 h-96 bg-purple-600/10 rounded-full blur-[120px] -z-10 animate-pulse delay-1000"></div>

                <div className="max-w-5xl mx-auto">
                    <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-cyan-500/10 border border-cyan-500/20 text-cyan-400 text-[10px] font-black uppercase tracking-[0.3em] mb-12 backdrop-blur-sm">
                        <Activity size={14} /> Neuro-Symbolic Intelligence
                    </div>

                    <h1 className="text-6xl md:text-8xl font-black tracking-tighter mb-8 leading-[0.9] text-white">
                        Predict Today.<br />
                        <span className="bg-clip-text text-transparent bg-gradient-to-r from-cyan-400 to-blue-500">Avert Tomorrow.</span>
                    </h1>

                    <p className="text-xl md:text-3xl font-medium mb-12 max-w-3xl mx-auto text-slate-400 leading-relaxed">
                        High-fidelity cardiovascular event detection. Powered by <span className="text-white">XGBoost-MVP-V1</span> ensembles trained on 70,000+ records.
                    </p>

                    <div className="inline-flex items-center gap-6 bg-white/5 backdrop-blur-xl border border-white/10 px-8 py-4 rounded-[2rem] mb-16 shadow-2xl">
                        <div className="text-center border-r border-white/10 pr-6">
                            <p className="text-2xl font-black text-cyan-400">99.1%</p>
                            <p className="text-[8px] font-black uppercase tracking-widest text-slate-500">Precision Target</p>
                        </div>
                        <div className="text-center">
                            <p className="text-2xl font-black text-white">12-HOUR</p>
                            <p className="text-[8px] font-black uppercase tracking-widest text-slate-500">Predictive Window</p>
                        </div>
                    </div>

                    {/* Primary CTAs */}
                    <div className="flex flex-col sm:flex-row gap-6 justify-center w-full max-w-2xl mx-auto">
                        <button
                            onClick={onLaunch}
                            className="group flex-1 bg-cyan-600 hover:bg-cyan-500 text-white py-6 rounded-2xl font-black text-sm uppercase tracking-widest transition-all shadow-xl shadow-cyan-900/20 flex items-center justify-center gap-3 active:scale-95"
                        >
                            Start Bio-Assessment <ArrowRight className="h-5 w-5 group-hover:translate-x-1 transition-transform" />
                        </button>

                        <button
                            onClick={onLogin}
                            className="flex-1 bg-white/10 hover:bg-white/20 border border-white/10 text-white py-6 rounded-2xl font-black text-sm uppercase tracking-widest transition-all backdrop-blur-md active:scale-95"
                        >
                            Clinician Portal Access
                        </button>
                    </div>

                    {/* Institutional Stats */}
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mt-24">
                        <div className="bg-slate-900/50 backdrop-blur-md p-8 rounded-[2.5rem] border border-white/5 text-left group hover:border-cyan-500/30 transition-all">
                            <p className="text-4xl font-black text-white mb-2 group-hover:text-cyan-400 transition-colors">92%</p>
                            <p className="text-[10px] font-black uppercase tracking-widest text-slate-500 mb-4">Current Validation</p>
                            <p className="text-xs text-slate-400 leading-relaxed uppercase tracking-tighter">Verified against clinical registry datasets with 0.89 F1-Score.</p>
                        </div>
                        <div className="bg-slate-900/50 backdrop-blur-md p-8 rounded-[2.5rem] border border-white/5 text-left group hover:border-purple-500/30 transition-all">
                            <p className="text-4xl font-black text-white mb-2 group-hover:text-purple-400 transition-colors">8.1B</p>
                            <p className="text-[10px] font-black uppercase tracking-widest text-slate-500 mb-4">Market Opportunity</p>
                            <p className="text-xs text-slate-400 leading-relaxed uppercase tracking-tighter">Projected TAM for digital-first cardiovascular risk nodes by 2028.</p>
                        </div>
                        <div className="bg-slate-900/50 backdrop-blur-md p-8 rounded-[2.5rem] border border-white/5 text-left group hover:border-emerald-500/30 transition-all">
                            <ShieldCheck className="w-10 h-10 text-emerald-500 mb-4" />
                            <p className="text-[10px] font-black uppercase tracking-widest text-slate-500 mb-2">Security Architecture</p>
                            <p className="text-xs text-slate-400 leading-relaxed uppercase tracking-tighter">HIPAA-ready nodes with AES-256 client-side encryption protocols.</p>
                        </div>
                    </div>
                </div>
            </header>

            {/* Trust Sign boards */}
            <div className="bg-black/20 py-12 border-y border-white/5">
                <div className="max-w-6xl mx-auto px-6 flex flex-wrap justify-center gap-12 opacity-40">
                    <div className="flex items-center gap-2 font-black text-[10px] uppercase tracking-[0.4em]">HL7 FHIR READY</div>
                    <div className="flex items-center gap-2 font-black text-[10px] uppercase tracking-[0.4em]">XGBOOST ENSEMBLE</div>
                    <div className="flex items-center gap-2 font-black text-[10px] uppercase tracking-[0.4em]">HIPAA COMPLIANT</div>
                    <div className="flex items-center gap-2 font-black text-[10px] uppercase tracking-[0.4em]">MACE TARGETED</div>
                </div>
            </div>

            {/* Footer */}
            <footer className="py-16 px-8 bg-slate-950/50 text-slate-500 relative overflow-hidden">
                <div className="max-w-6xl mx-auto flex flex-col md:flex-row justify-between items-start gap-12">
                    <div className="max-w-sm">
                        <span className="font-black text-2xl tracking-tighter text-white">CardioGuard<span className="text-cyan-500">AI</span></span>
                        <p className="text-xs font-medium mt-4 leading-relaxed">Defining the standard for predictive cardiovascular intelligence through clinical-grade ML scaling.</p>
                    </div>

                    <div className="grid grid-cols-2 sm:grid-cols-3 gap-12">
                        <div className="space-y-4">
                            <p className="text-[10px] font-black text-white uppercase tracking-widest">Protocol</p>
                            <nav className="flex flex-col gap-2 text-xs">
                                <Link to="/analyze" className="hover:text-cyan-400 transition-colors">Start Assessment</Link>
                                <Link to="/lab" className="hover:text-cyan-400 transition-colors">Accuracy Lab</Link>
                            </nav>
                        </div>
                        <div className="space-y-4">
                            <p className="text-[10px] font-black text-white uppercase tracking-widest">Legal</p>
                            <nav className="flex flex-col gap-2 text-xs">
                                <Link to="/privacy" className="hover:text-cyan-400 transition-colors">Privacy Node</Link>
                                <Link to="/terms" className="hover:text-cyan-400 transition-colors">Terms of Service</Link>
                            </nav>
                        </div>
                        <div className="space-y-4">
                            <p className="text-[10px] font-black text-white uppercase tracking-widest">Access</p>
                            <button onClick={onLogin} className="text-xs hover:text-cyan-400 transition-colors block text-left">Physician Login</button>
                            <button onClick={onLaunch} className="text-xs hover:text-cyan-400 transition-colors block text-left">Guest Terminal</button>
                        </div>
                    </div>
                </div>

                <div className="max-w-6xl mx-auto mt-16 pt-8 border-t border-white/5 flex flex-col sm:flex-row justify-between items-center gap-6">
                    <p className="text-[10px] font-black uppercase tracking-widest">© 2026 CardioGuard AI | Institutional Growth Phase</p>
                    <div className="flex items-center gap-2">
                        <div className="w-1.5 h-1.5 bg-emerald-500 rounded-full animate-pulse"></div>
                        <p className="text-[10px] font-black uppercase tracking-widest text-emerald-500">Clinical Nodes Standardized</p>
                    </div>
                </div>
            </footer>
        </div>
    );
};

export default LandingPage;
