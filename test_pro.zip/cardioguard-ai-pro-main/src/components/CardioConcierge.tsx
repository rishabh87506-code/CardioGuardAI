import React, { useEffect, useRef, useState } from 'react';
import { GoogleGenAI, Modality, LiveServerMessage } from '@google/genai';
// Added Globe to the imported icons from lucide-react to resolve the missing name error
import { Mic, MicOff, X, Loader2, Sparkles, Activity, Volume2, AlertCircle, Globe } from 'lucide-react';
import { SupportedLanguage } from '../types';

// Audio Helpers from SDK Instructions
function encode(bytes: Uint8Array) {
  let binary = '';
  const len = bytes.byteLength;
  for (let i = 0; i < len; i++) {
    binary += String.fromCharCode(bytes[i]);
  }
  return btoa(binary);
}

function decode(base64: string) {
  const binaryString = atob(base64);
  const len = binaryString.length;
  const bytes = new Uint8Array(len);
  for (let i = 0; i < len; i++) {
    bytes[i] = binaryString.charCodeAt(i);
  }
  return bytes;
}

async function decodeAudioData(
  data: Uint8Array,
  ctx: AudioContext,
  sampleRate: number,
  numChannels: number,
): Promise<AudioBuffer> {
  const dataInt16 = new Int16Array(data.buffer);
  const frameCount = dataInt16.length / numChannels;
  const buffer = ctx.createBuffer(numChannels, frameCount, sampleRate);
  for (let channel = 0; channel < numChannels; channel++) {
    const channelData = buffer.getChannelData(channel);
    for (let i = 0; i < frameCount; i++) {
      channelData[i] = dataInt16[i * numChannels + channel] / 32768.0;
    }
  }
  return buffer;
}

interface CardioConciergeProps {
  onBack: () => void;
  language: SupportedLanguage;
  onClose?: () => void;
  currentAssessment?: any;
}

const CardioConcierge: React.FC<CardioConciergeProps> = ({ onBack, language, onClose, currentAssessment }) => {
  const [isActive, setIsActive] = useState(false);
  const [isConnecting, setIsConnecting] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [transcript, setTranscript] = useState<string>('');

  const sessionRef = useRef<any>(null);
  const audioContextInRef = useRef<AudioContext | null>(null);
  const audioContextOutRef = useRef<AudioContext | null>(null);
  const nextStartTimeRef = useRef(0);
  const sourcesRef = useRef<Set<AudioBufferSourceNode>>(new Set());

  const stopSession = () => {
    if (sessionRef.current) {
      try { sessionRef.current.close(); } catch (e) { }
      sessionRef.current = null;
    }
    if (audioContextInRef.current) audioContextInRef.current.close();
    if (audioContextOutRef.current) audioContextOutRef.current.close();
    setIsActive(false);
    setIsConnecting(false);
  };

  const startSession = async () => {
    setError(null);
    setIsConnecting(true);

    try {
      const apiKey = import.meta.env.VITE_GEMINI_API_KEY || '';
      if (!apiKey) throw new Error("Missing Gemini API Key in environment variables");
      const ai = new GoogleGenAI({ apiKey });

      // Initialize Contexts
      audioContextInRef.current = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 16000 });
      audioContextOutRef.current = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 24000 });

      // Ensure resumed
      await audioContextInRef.current.resume();
      await audioContextOutRef.current.resume();

      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });

      const sessionPromise = ai.live.connect({
        model: 'gemini-2.0-flash-exp',
        callbacks: {
          onopen: () => {
            setIsConnecting(false);
            setIsActive(true);

            const source = audioContextInRef.current!.createMediaStreamSource(stream);
            const scriptProcessor = audioContextInRef.current!.createScriptProcessor(4096, 1, 1);

            scriptProcessor.onaudioprocess = (e) => {
              const inputData = e.inputBuffer.getChannelData(0);
              const l = inputData.length;
              const int16 = new Int16Array(l);
              for (let i = 0; i < l; i++) {
                int16[i] = inputData[i] * 32768;
              }
              const pcmBlob = {
                data: encode(new Uint8Array(int16.buffer)),
                mimeType: 'audio/pcm;rate=16000',
              };

              sessionPromise.then(session => {
                session.sendRealtimeInput({ media: pcmBlob });
              });
            };

            source.connect(scriptProcessor);
            scriptProcessor.connect(audioContextInRef.current!.destination);
          },
          onmessage: async (message: LiveServerMessage) => {
            if (message.serverContent?.outputTranscription) {
              setTranscript(prev => prev + ' ' + message.serverContent?.outputTranscription?.text);
            }

            const base64Audio = message.serverContent?.modelTurn?.parts?.[0]?.inlineData?.data;
            if (base64Audio && audioContextOutRef.current) {
              const ctx = audioContextOutRef.current;
              nextStartTimeRef.current = Math.max(nextStartTimeRef.current, ctx.currentTime);

              const audioBuffer = await decodeAudioData(decode(base64Audio), ctx, 24000, 1);
              const source = ctx.createBufferSource();
              source.buffer = audioBuffer;
              source.connect(ctx.destination);
              source.addEventListener('ended', () => sourcesRef.current.delete(source));
              source.start(nextStartTimeRef.current);
              nextStartTimeRef.current += audioBuffer.duration;
              sourcesRef.current.add(source);
            }

            if (message.serverContent?.interrupted) {
              sourcesRef.current.forEach(s => {
                try { s.stop(); } catch (e) { }
              });
              sourcesRef.current.clear();
              nextStartTimeRef.current = 0;
            }
          },
          onerror: (e) => {
            console.error("Concierge Error:", e);
            setError("Connection disrupted. Please retry or check your network.");
            stopSession();
          },
          onclose: () => {
            console.log("Session Closed");
            stopSession();
          },
        },
        config: {
          responseModalities: [Modality.AUDIO],
          speechConfig: {
            voiceConfig: { prebuiltVoiceConfig: { voiceName: 'Puck' } },
          },
          systemInstruction: `You are the CardioGuard Clinical Liaison. You are an expert AI dedicated to precise cardiovascular guidance.
            
            USER BIOMETRIC CONTEXT:
            - Risk Category: ${currentAssessment?.riskCategory || 'New User (No baseline)'}
            - Risk Score: ${currentAssessment?.riskScore || '--'}%
            - Hemodynamics: BP ${currentAssessment?.vitals?.systolicBP || '--'}/${currentAssessment?.vitals?.diastolicBP || '--'}, HR ${currentAssessment?.vitals?.heartRate || '--'} BPM.
            - Bio-Signals: SpO2 ${currentAssessment?.vitals?.spO2 || '--'}%, HRV ${currentAssessment?.vitals?.hrv || '--'}ms.
            - Recent Symptoms: ${currentAssessment?.vitals?.symptoms || 'None reported'}.

            OPERATIONAL PROTOCOL:
            1. LANGUAGE: Respond ONLY in ${language}.
            2. PERSONALIZATION: Always acknowledge the user's current vitals if they ask for advice. If BP is high, focus on immediate calming and medical triage.
            3. EVIDENCE: Use clinical logic. Mention that your analysis is based on non-linear XGBoost and Framingham ensembles.
            4. TONE: Attentive, clinical, and empathetic. Your voice profile is Puck (Professional Medical Tier).
            5. SAFETY: Remind the user you are an AI liaison. If you detect emergency patterns (Chest pain, very high BP), advise immediate SOS dispatch.`,
          outputAudioTranscription: {},
        },
      });

      sessionRef.current = await sessionPromise;
    } catch (err) {
      console.error(err);
      setError("Microphone access denial or API Key issue. Please allow permissions.");
      setIsConnecting(false);
    }
  };

  useEffect(() => {
    return () => stopSession();
  }, []);

  return (
    <div className="fixed inset-0 z-[100] bg-slate-900 flex flex-col items-center justify-center p-6 animate-in fade-in duration-300">
      <div className="max-w-md w-full flex flex-col h-full">
        <div className="flex justify-between items-center mb-10">
          <div className="flex items-center gap-3">
            <div className="bg-blue-600 p-2 rounded-xl">
              <Activity className="w-5 h-5 text-white" />
            </div>
            <h2 className="text-xl font-black text-white tracking-tight">Cardio Concierge</h2>
          </div>
          <button onClick={onClose} className="p-2 text-white/30 hover:text-white transition-colors">
            <X className="w-6 h-6" />
          </button>
        </div>

        <div className="flex-1 flex flex-col items-center justify-center space-y-12">
          {error && (
            <div className="w-full p-4 bg-rose-500/10 border border-rose-500/20 rounded-2xl flex items-center gap-3 text-rose-200 text-sm font-medium animate-in slide-in-from-top-4">
              <AlertCircle className="w-5 h-5 shrink-0" />
              {error}
            </div>
          )}

          <div className="relative">
            <div className={`absolute inset-0 bg-blue-500/20 blur-[60px] rounded-full transition-all duration-1000 ${isActive ? 'scale-150 opacity-100' : 'scale-100 opacity-0'}`}></div>

            {/* BIOMETRIC FEED (EFFECTIVE & RESPONSIVE) */}
            {currentAssessment && (
              <div className="absolute -top-12 left-1/2 -translate-x-1/2 flex gap-3 whitespace-nowrap">
                <div className="px-3 py-1 bg-white/5 border border-white/10 rounded-lg backdrop-blur-md">
                  <p className="text-[8px] font-black text-blue-400 uppercase tracking-widest leading-none mb-1">Systolic BP</p>
                  <p className="text-xs font-bold text-white leading-none">{currentAssessment.vitals?.systolicBP || '--'}</p>
                </div>
                <div className="px-3 py-1 bg-white/5 border border-white/10 rounded-lg backdrop-blur-md">
                  <p className="text-[8px] font-black text-rose-400 uppercase tracking-widest leading-none mb-1">Heart Rate</p>
                  <p className="text-xs font-bold text-white leading-none">{currentAssessment.vitals?.heartRate || '--'}BPM</p>
                </div>
                <div className="px-3 py-1 bg-white/5 border border-white/10 rounded-lg backdrop-blur-md">
                  <p className="text-[8px] font-black text-emerald-400 uppercase tracking-widest leading-none mb-1">SpO2</p>
                  <p className="text-xs font-bold text-white leading-none">{currentAssessment.vitals?.spO2 || '--'}%</p>
                </div>
              </div>
            )}

            <div className={`w-48 h-48 rounded-full border-4 flex items-center justify-center transition-all duration-500 ${isActive ? 'border-blue-500 shadow-[0_0_50px_rgba(59,130,246,0.3)]' : 'border-white/10'}`}>
              {isConnecting ? (
                <Loader2 className="w-12 h-12 text-blue-500 animate-spin" />
              ) : isActive ? (
                <div className="flex gap-1 items-end h-12">
                  {[...Array(5)].map((_, i) => (
                    <div
                      key={i}
                      className="w-2 bg-blue-400 rounded-full animate-pulse"
                      style={{ height: `${20 + Math.random() * 80}%`, animationDelay: `${i * 0.1}s` }}
                    ></div>
                  ))}
                </div>
              ) : (
                <Mic className="w-12 h-12 text-white/20" />
              )}
            </div>
          </div>

          <div className="text-center space-y-4">
            <h3 className="text-2xl font-bold text-white">
              {isConnecting ? 'Establishing Link...' : isActive ? 'Listening...' : 'Ready to Talk'}
            </h3>
            <div className="flex items-center justify-center gap-2 mb-2">
              <Globe className="w-3 h-3 text-blue-400" />
              <span className="text-[10px] font-black uppercase tracking-widest text-blue-400">{language} Protocol</span>
            </div>
            <p className="text-slate-400 text-sm max-w-[280px] mx-auto font-medium">
              {isActive
                ? "Speak naturally. I'm here to help you manage your cardiovascular journey."
                : "Secure voice channel powered by Gemini Live. Tap to begin your session."}
            </p>
          </div>

          {isActive && transcript && (
            <div className="w-full bg-white/5 backdrop-blur-md rounded-3xl p-6 border border-white/10 max-h-32 overflow-y-auto">
              <p className="text-xs text-slate-300 italic text-center font-medium">
                "{transcript.slice(-150)}..."
              </p>
            </div>
          )}
        </div>

        <div className="mt-auto pb-10 flex flex-col items-center gap-6">
          {!isActive ? (
            <button
              disabled={isConnecting}
              onClick={startSession}
              className="px-8 py-4 bg-blue-600 hover:bg-blue-500 text-white rounded-full font-black flex items-center gap-3 shadow-2xl shadow-blue-500/20 active:scale-95 transition-all disabled:opacity-50 disabled:cursor-not-allowed"
            >
              <Mic className="w-5 h-5" />
              START SESSION
            </button>
          ) : (
            <button
              onClick={stopSession}
              className="px-8 py-4 bg-rose-600 hover:bg-rose-500 text-white rounded-full font-black flex items-center gap-3 shadow-2xl shadow-rose-500/20 active:scale-95 transition-all"
            >
              <MicOff className="w-5 h-5" />
              END SESSION
            </button>
          )}

          <div className="flex items-center gap-2 text-[10px] font-black text-white/30 uppercase tracking-[0.3em]">
            <Sparkles className="w-3 h-3" />
            AI Health Reasoning Ready
          </div>
        </div>
      </div>
    </div>
  );
};

export default CardioConcierge;