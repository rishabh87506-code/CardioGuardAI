
import React, { useState } from 'react';
import { ShieldCheck, Lock, Unlock, Key, Fingerprint } from 'lucide-react';

interface SecurityVaultProps {
  isLocked: boolean;
  onToggle: (passphrase: string) => void;
}

const SecurityVault: React.FC<SecurityVaultProps> = ({ isLocked, onToggle }) => {
  const [passphrase, setPassphrase] = useState('');
  const [showInput, setShowInput] = useState(false);

  return (
    <div className="bg-slate-900 rounded-3xl p-6 text-white shadow-2xl relative overflow-hidden group">
      <div className="absolute top-0 right-0 p-4 opacity-10 group-hover:scale-110 transition-transform">
        <Fingerprint className="w-24 h-24" />
      </div>

      <div className="relative z-10">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-3">
            <div className={`p-2 rounded-xl ${isLocked ? 'bg-blue-600' : 'bg-emerald-600'}`}>
              {isLocked ? <Lock className="w-5 h-5" /> : <Unlock className="w-5 h-5" />}
            </div>
            <div>
              <h3 className="font-bold text-lg leading-none">TCH-Secure Vault</h3>
              <p className="text-[10px] text-slate-400 font-bold uppercase tracking-widest mt-1">Enterprise Encryption</p>
            </div>
          </div>
          <ShieldCheck className={`w-6 h-6 ${isLocked ? 'text-blue-400' : 'text-emerald-400'}`} />
        </div>

        <p className="text-sm text-slate-300 mb-6 leading-relaxed">
          {isLocked 
            ? "Your assessment history is currently encrypted using TCH zero-knowledge protocol. Enter your passphrase to decrypt."
            : "Data is currently readable. We recommend locking your vault to secure personal medical records locally."}
        </p>

        {!showInput ? (
          <button 
            onClick={() => setShowInput(true)}
            className={`w-full py-3 rounded-xl font-bold text-sm transition-all flex items-center justify-center gap-2 ${
              isLocked ? 'bg-blue-600 hover:bg-blue-700' : 'bg-slate-800 hover:bg-slate-700'
            }`}
          >
            {isLocked ? <Key className="w-4 h-4" /> : <Lock className="w-4 h-4" />}
            {isLocked ? "Unlock Vault" : "Secure My Data"}
          </button>
        ) : (
          <div className="space-y-3 animate-in slide-in-from-top-2">
            <input 
              type="password"
              placeholder="Enter Private Key..."
              className="w-full bg-slate-800 border border-slate-700 rounded-xl px-4 py-3 text-sm outline-none focus:ring-2 focus:ring-blue-500 text-white"
              value={passphrase}
              onChange={(e) => setPassphrase(e.target.value)}
            />
            <div className="flex gap-2">
              <button 
                onClick={() => {
                  onToggle(passphrase);
                  setPassphrase('');
                  setShowInput(false);
                }}
                className="flex-1 bg-white text-slate-900 py-3 rounded-xl font-bold text-sm"
              >
                Confirm
              </button>
              <button 
                onClick={() => setShowInput(false)}
                className="px-4 py-3 rounded-xl bg-slate-800 font-bold text-sm"
              >
                Cancel
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default SecurityVault;
