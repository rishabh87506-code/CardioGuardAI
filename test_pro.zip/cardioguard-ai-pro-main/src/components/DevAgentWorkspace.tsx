
import React, { useState, useEffect, useRef } from 'react';
import {
    Activity, Code2, Cpu, Loader2, CheckCircle2,
    Zap, ArrowLeft, Bot, Sparkles,
    Layout, Globe, Smartphone, ShieldCheck,
    Gauge, Database, HeartPulse, Microscope
} from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { DevMilestone, DEV_TASKS, runDevSprint } from '../services/devAgent';

export default function DevAgentWorkspace() {
    const navigate = useNavigate();
    const [milestones, setMilestones] = useState<DevMilestone[]>(DEV_TASKS);
    const [logs, setLogs] = useState<{ msg: string; type: 'info' | 'warn' | 'success' | 'cmd'; time: number }[]>([]);
    const [isAwaitingApproval, setIsAwaitingApproval] = useState(false);
    const logEndRef = useRef<HTMLDivElement>(null);

    const addLog = (msg: string, type: 'info' | 'warn' | 'success' | 'cmd' = 'info') => {
        setLogs(prev => [...prev.slice(-49), { msg, type, time: Date.now() }]);
    };

    useEffect(() => {
        const startSprint = async () => {
            addLog('Initializing Clinical Environment...', 'info');
            await new Promise(r => setTimeout(r, 1000));
            addLog('Verifying HIPAA compliance headers...', 'info');
            await new Promise(r => setTimeout(r, 800));
            addLog('Environment ready. Commencing System Calibration.', 'success');

            await runDevSprint((updated) => {
                setMilestones(prev => prev.map(m => m.id === updated.id ? updated : m));

                if (updated.status === 'in-progress') {
                    addLog(`CALIBRATING Node: ${updated.title}`, 'info');
                    addLog(`Action: ${updated.description}`, 'info');
                } else if (updated.status === 'completed') {
                    addLog(`VERIFIED: ${updated.title} optimization complete.`, 'success');
                }
            });

            addLog('CALIBRATION COMPLETED: All systems synchronized.', 'success');
            setIsAwaitingApproval(true);
        };

        startSprint();
    }, []);

    useEffect(() => {
        logEndRef.current?.scrollIntoView({ behavior: 'smooth' });
    }, [logs]);

    return (
        <div className="max-w-7xl mx-auto p-6 space-y-8 animate-in fade-in duration-700 pb-20">
            {/* Clinical Header */}
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 bg-white p-10 rounded-[3rem] border border-slate-100 shadow-xl relative overflow-hidden">
                <div className="absolute top-0 right-0 p-8 opacity-5">
                    <Microscope className="w-48 h-48 text-blue-600" />
                </div>

                <div className="flex items-center gap-6 relative z-10">
                    <div className="bg-slate-900 p-5 rounded-3xl shadow-2xl">
                        <Bot className="w-10 h-10 text-tesla-cyan animate-pulse" />
                    </div>
                    <div>
                        <h1 className="text-4xl font-black text-slate-950 tracking-tighter flex items-center gap-3">
                            Clinical Eng. Suite <Sparkles className="w-6 h-6 text-amber-500" />
                        </h1>
                        <p className="text-[10px] font-black text-slate-400 uppercase tracking-[0.4em] mt-1">
                            Autonomous Optimization Layer • Node ID: CG-882-SYS
                        </p>
                    </div>
                </div>

                <div className="flex items-center gap-4 relative z-10">
                    <div className="bg-emerald-50 px-4 py-2 rounded-2xl border border-emerald-100 flex items-center gap-3">
                        <div className="w-2 h-2 bg-emerald-500 rounded-full animate-ping" />
                        <span className="text-[10px] font-black text-emerald-600 uppercase tracking-widest">Engine Live</span>
                    </div>
                    <button
                        onClick={() => navigate('/agents')}
                        className="px-6 py-4 bg-slate-100 hover:bg-slate-200 text-slate-900 rounded-2xl transition-all font-black text-xs uppercase tracking-widest flex items-center gap-3"
                    >
                        <ArrowLeft className="w-4 h-4" /> Exit Suite
                    </button>
                </div>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
                {/* Left: System Calibration Matrix (Was Terminal) */}
                <div className="lg:col-span-8 space-y-6">
                    <div className="bg-white rounded-[3.5rem] border border-slate-100 overflow-hidden shadow-2xl flex flex-col h-[550px]">
                        <div className="px-8 py-6 border-b border-slate-100 flex items-center justify-between bg-slate-50/50">
                            <div className="flex items-center gap-3">
                                <Gauge className="w-5 h-5 text-blue-600" />
                                <h3 className="text-xs font-black text-slate-900 uppercase tracking-widest">Optimization Matrix</h3>
                            </div>
                            <div className="flex items-center gap-2">
                                <span className="w-2 h-2 rounded-full bg-blue-500 animate-pulse"></span>
                                <span className="text-[9px] font-black text-slate-400 uppercase tracking-widest">Processing Data Streams</span>
                            </div>
                        </div>

                        <div className="flex-1 overflow-y-auto p-8 space-y-4 font-medium no-scrollbar bg-white">
                            {logs.map((log, i) => (
                                <div key={i} className="flex gap-6 animate-in slide-in-from-bottom-2 duration-500">
                                    <span className="text-slate-300 text-[10px] font-black select-none mt-1">{new Date(log.time).toLocaleTimeString([], { hour12: false, minute: '2-digit', second: '2-digit' })}</span>
                                    <div className={`p-4 rounded-2xl border flex-1 ${log.type === 'info' ? 'bg-blue-50/50 border-blue-100 text-blue-900' :
                                            log.type === 'success' ? 'bg-emerald-50/50 border-emerald-100 text-emerald-900' :
                                                'bg-slate-50 border-slate-100 text-slate-900'
                                        }`}>
                                        <div className="flex items-center gap-3">
                                            {log.type === 'success' ? <CheckCircle2 className="w-4 h-4 text-emerald-500" /> : <Activity className="w-4 h-4 text-blue-400 animate-pulse" />}
                                            <span className="text-sm font-bold tracking-tight">{log.msg}</span>
                                        </div>
                                    </div>
                                </div>
                            ))}
                            <div ref={logEndRef} />
                        </div>

                        <div className="p-6 bg-slate-900 border-t border-slate-800">
                            <div className="flex items-center justify-between">
                                <div className="flex items-center gap-4">
                                    <Zap className="w-5 h-5 text-tesla-cyan animate-pulse" />
                                    <div>
                                        <p className="text-[10px] font-black text-white uppercase tracking-[0.2em]">Clinical-Grade Acceleration Active</p>
                                        <p className="text-[8px] text-slate-500 font-bold uppercase mt-0.5">Bypassing standard latency nodes for peak performance</p>
                                    </div>
                                </div>
                                <div className="text-right">
                                    <p className="text-[10px] font-black text-tesla-cyan uppercase tracking-widest">99.9% Logic Accuracy</p>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                        {[
                            { label: 'Clinical Hash', val: '0x882A...FD21', icon: ShieldCheck, color: 'text-emerald-500' },
                            { label: 'Data Relay', val: '984 Mbps', icon: Zap, color: 'text-amber-500' },
                            { label: 'Vault Status', val: 'Encrypted', icon: Database, color: 'text-blue-500' }
                        ].map((stat, i) => (
                            <div key={i} className="bg-white p-6 rounded-[2rem] border border-slate-100 shadow-sm flex flex-col gap-2">
                                <stat.icon className={`w-5 h-5 ${stat.color}`} />
                                <div>
                                    <p className="text-[9px] font-black text-slate-400 uppercase tracking-widest">{stat.label}</p>
                                    <p className="text-sm font-black text-slate-900">{stat.val}</p>
                                </div>
                            </div>
                        ))}
                    </div>
                </div>

                {/* Right: Roadmap (Clinical Style) */}
                <div className="lg:col-span-4 space-y-8">
                    <div className="bg-slate-950 p-8 rounded-[3.5rem] border border-white/10 shadow-2xl relative overflow-hidden">
                        <div className="absolute top-0 right-0 p-8 opacity-5">
                            <HeartPulse className="w-32 h-32 text-white" />
                        </div>

                        <h3 className="text-xs font-black text-white uppercase tracking-[0.3em] mb-8 flex items-center gap-3 relative z-10">
                            <div className="p-2 bg-white/10 rounded-lg">
                                <Layout className="w-4 h-4 text-tesla-cyan" />
                            </div>
                            Calibration Roadmap
                        </h3>

                        <div className="space-y-6 relative z-10">
                            {milestones.map((m) => (
                                <div key={m.id} className="group">
                                    <div className="flex items-start gap-5">
                                        <div className={`mt-1 w-6 h-6 rounded-lg border flex items-center justify-center shrink-0 transition-all duration-500 ${m.status === 'completed' ? 'bg-emerald-500 border-emerald-500 shadow-[0_0_15px_rgba(16,185,129,0.4)]' :
                                                m.status === 'in-progress' ? 'bg-tesla-cyan border-tesla-cyan animate-pulse' : 'bg-white/5 border-white/20'
                                            }`}>
                                            {m.status === 'completed' ? <CheckCircle2 className="w-3.5 h-3.5 text-white" /> : <div className="w-1.5 h-1.5 rounded-full bg-white/20" />}
                                        </div>

                                        <div className="space-y-1">
                                            <p className={`text-sm font-black tracking-tight transition-colors ${m.status === 'completed' ? 'text-white' : m.status === 'in-progress' ? 'text-tesla-cyan' : 'text-slate-500'}`}>
                                                {m.title}
                                            </p>
                                            <p className="text-[10px] text-slate-400 leading-relaxed font-bold opacity-60">
                                                {m.description}
                                            </p>
                                        </div>
                                    </div>
                                </div>
                            ))}
                        </div>
                    </div>

                    {isAwaitingApproval && (
                        <div className="bg-emerald-600 p-8 rounded-[3.5rem] shadow-2xl animate-in zoom-in-95 duration-500">
                            <div className="text-center space-y-6">
                                <div className="w-16 h-16 bg-white/20 rounded-3xl flex items-center justify-center mx-auto border border-white/30 backdrop-blur-md">
                                    <ShieldCheck className="w-8 h-8 text-white" />
                                </div>
                                <div className="space-y-2">
                                    <h4 className="text-xl font-black text-white">Clinical Calibration Complete</h4>
                                    <p className="text-xs text-emerald-100 font-bold leading-relaxed">System has been successfully optimized to Healthcare 4.0 standards.</p>
                                </div>
                                <button
                                    onClick={() => navigate('/')}
                                    className="w-full py-5 bg-white text-emerald-600 rounded-3xl font-black text-[11px] uppercase tracking-widest transition-all shadow-xl hover:bg-slate-50 active:scale-[0.98]"
                                >
                                    Dashboard Home
                                </button>
                            </div>
                        </div>
                    )}
                </div>
            </div>
        </div>
    );
}
