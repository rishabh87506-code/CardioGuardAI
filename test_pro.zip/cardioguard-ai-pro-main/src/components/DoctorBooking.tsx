import React, { useState } from 'react';
import {
    Calendar, Star, MapPin, Clock, Search,
    CheckCircle2, User, Phone, Video, Stethoscope, ChevronRight
} from 'lucide-react';

interface Doctor {
    id: string;
    name: string;
    specialty: string;
    rating: number;
    reviews: number;
    location: string;
    availability: string[];
    image: string;
    price: string;
}

const mockDoctors: Doctor[] = [
    {
        id: '1',
        name: 'Dr. Sarah Chen, MD',
        specialty: 'Interventional Cardiology',
        rating: 4.9,
        reviews: 124,
        location: 'Metro Heart Institute',
        availability: ['Mon 10:00 AM', 'Wed 2:00 PM', 'Fri 11:30 AM'],
        image: 'https://images.unsplash.com/photo-1559839734-2b71ea197ec2?auto=format&fit=crop&q=80&w=300&h=300',
        price: '$150'
    },
    {
        id: '2',
        name: 'Dr. James Wilson, PhD',
        specialty: 'Electrophysiology',
        rating: 4.8,
        reviews: 89,
        location: 'City General',
        availability: ['Tue 9:00 AM', 'Thu 3:00 PM'],
        image: 'https://images.unsplash.com/photo-1612349317150-e413f6a5b16d?auto=format&fit=crop&q=80&w=300&h=300',
        price: '$200'
    },
    {
        id: '3',
        name: 'Dr. Emily Carter',
        specialty: 'Preventive Cardiology',
        rating: 4.9,
        reviews: 210,
        location: 'Wellness Center',
        availability: ['Mon 4:00 PM', 'Fri 9:00 AM'],
        image: 'https://images.unsplash.com/photo-1594824476967-48c8b964273f?auto=format&fit=crop&q=80&w=300&h=300',
        price: '$120'
    }
];

const DoctorBooking = () => {
    const [selectedDoctor, setSelectedDoctor] = useState<Doctor | null>(null);
    const [selectedSlot, setSelectedSlot] = useState<string | null>(null);
    const [bookingStage, setBookingStage] = useState<'list' | 'confirm' | 'success'>('list');

    const handleBook = () => {
        // Here we would integrate with Supabase Appointments table
        setTimeout(() => {
            setBookingStage('success');
        }, 1500);
    };

    if (bookingStage === 'success') {
        return (
            <div className="flex flex-col items-center justify-center min-h-[60vh] text-center space-y-6 animate-in zoom-in duration-500">
                <div className="w-24 h-24 bg-emerald-100 rounded-full flex items-center justify-center mb-4">
                    <CheckCircle2 className="w-12 h-12 text-emerald-600" />
                </div>
                <h2 className="text-3xl font-black text-slate-800">Appointment Confirmed</h2>
                <div className="bg-white p-6 rounded-3xl shadow-sm border border-slate-100 max-w-md w-full">
                    <div className="flex items-center gap-4 mb-4 pb-4 border-b border-slate-50">
                        <img src={selectedDoctor?.image} alt={selectedDoctor?.name} className="w-12 h-12 rounded-xl object-cover" />
                        <div className="text-left">
                            <h3 className="font-bold text-slate-900">{selectedDoctor?.name}</h3>
                            <p className="text-xs text-slate-500">{selectedDoctor?.specialty}</p>
                        </div>
                    </div>
                    <div className="flex justify-between items-center text-sm font-medium text-slate-600">
                        <span className="flex items-center gap-2"><Calendar size={16} /> {selectedSlot}</span>
                        <span className="flex items-center gap-2"><Video size={16} /> Tele-Consult</span>
                    </div>
                </div>
                <button
                    onClick={() => { setBookingStage('list'); setSelectedDoctor(null); setSelectedSlot(null); }}
                    className="px-8 py-3 bg-slate-900 text-white rounded-xl font-bold uppercase tracking-wider text-xs"
                >
                    Book Another
                </button>
            </div>
        );
    }

    if (selectedDoctor && bookingStage === 'confirm') {
        return (
            <div className="max-w-2xl mx-auto space-y-6 animate-in slide-in-from-right duration-300">
                <button onClick={() => setBookingStage('list')} className="flex items-center gap-2 text-slate-500 font-bold text-xs uppercase tracking-widest hover:text-slate-900">
                    <ChevronRight className="rotate-180" size={16} /> Back to List
                </button>

                <div className="bg-white rounded-[2.5rem] p-8 border border-sky-100 shadow-sm relative overflow-hidden">
                    <div className="flex flex-col md:flex-row gap-8 items-start">
                        <img src={selectedDoctor.image} alt={selectedDoctor.name} className="w-32 h-32 rounded-3xl object-cover shadow-lg" />
                        <div className="flex-1 space-y-4">
                            <div>
                                <h2 className="text-3xl font-black text-slate-900 leading-tight">{selectedDoctor.name}</h2>
                                <p className="text-emerald-600 font-bold uppercase tracking-wider text-xs mt-1">{selectedDoctor.specialty}</p>
                            </div>

                            <div className="flex items-center gap-4 text-sm text-slate-500 font-medium">
                                <span className="flex items-center gap-1"><Star size={16} className="text-amber-400 fill-amber-400" /> {selectedDoctor.rating} ({selectedDoctor.reviews} reviews)</span>
                                <span className="flex items-center gap-1"><MapPin size={16} /> {selectedDoctor.location}</span>
                            </div>

                            <div className="p-4 bg-slate-50 rounded-2xl border border-slate-100">
                                <h3 className="text-xs font-black text-slate-400 uppercase tracking-widest mb-3">Select Time Slot</h3>
                                <div className="flex flex-wrap gap-2">
                                    {selectedDoctor.availability.map(slot => (
                                        <button
                                            key={slot}
                                            onClick={() => setSelectedSlot(slot)}
                                            className={`px-4 py-2 rounded-xl text-xs font-bold transition-all border ${selectedSlot === slot
                                                ? 'bg-slate-900 text-white border-slate-900'
                                                : 'bg-white text-slate-600 border-slate-200 hover:border-slate-300'}`}
                                        >
                                            {slot}
                                        </button>
                                    ))}
                                </div>
                            </div>

                            <button
                                onClick={handleBook}
                                disabled={!selectedSlot}
                                className="w-full py-4 bg-emerald-600 disabled:opacity-50 disabled:cursor-not-allowed hover:bg-emerald-500 text-white rounded-2xl font-black uppercase tracking-widest text-sm shadow-xl shadow-emerald-900/10 transition-all"
                            >
                                Confirm Appointment {selectedSlot ? `for ${selectedSlot}` : ''}
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        );
    }

    return (
        <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500">
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                <div>
                    <h1 className="text-4xl font-black text-slate-900 tracking-tighter">Specialist <span className="text-emerald-600">Network</span></h1>
                    <p className="text-slate-500 font-medium">Book top-tier cardiologists for rapid consultation.</p>
                </div>
                <div className="flex items-center gap-2 bg-white p-2 rounded-2xl border border-sky-100 shadow-sm w-full md:w-auto">
                    <Search className="text-slate-400 ml-2" size={20} />
                    <input type="text" placeholder="Search by name or specialty..." className="bg-transparent outline-none p-2 text-sm font-bold text-slate-700 w-full placeholder:font-medium" />
                </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {mockDoctors.map(doc => (
                    <div key={doc.id} className="bg-white p-6 rounded-[2.5rem] border border-sky-50 shadow-sm hover:shadow-md hover:scale-[1.02] transition-all group cursor-pointer" onClick={() => { setSelectedDoctor(doc); setBookingStage('confirm'); }}>
                        <div className="flex items-start justify-between mb-6">
                            <img src={doc.image} alt={doc.name} className="w-20 h-20 rounded-2xl object-cover shadow-sm group-hover:shadow-md transition-shadow" />
                            <span className="px-3 py-1 bg-sky-50 text-sky-600 rounded-full text-[10px] font-black uppercase tracking-widest">{doc.price}</span>
                        </div>

                        <h3 className="text-xl font-bold text-slate-900 mb-1 leading-tight">{doc.name}</h3>
                        <p className="text-xs font-bold text-slate-400 uppercase tracking-widest mb-4">{doc.specialty}</p>

                        <div className="flex items-center gap-4 text-xs font-medium text-slate-500 mb-6">
                            <span className="flex items-center gap-1"><Star size={14} className="text-amber-400 fill-amber-400" /> {doc.rating}</span>
                            <span className="flex items-center gap-1"><MapPin size={14} /> {doc.location}</span>
                        </div>

                        <button className="w-full py-3 bg-slate-50 group-hover:bg-slate-900 group-hover:text-white text-slate-900 rounded-xl font-black text-[10px] uppercase tracking-widest transition-colors">
                            View Availability
                        </button>
                    </div>
                ))}
            </div>
        </div>
    );
};

export default DoctorBooking;
