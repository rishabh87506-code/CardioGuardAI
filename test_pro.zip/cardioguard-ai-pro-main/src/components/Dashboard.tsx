import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { createClient } from '../../lib/supabase/client';
import { Activity, TrendingUp, Shield, Cpu } from 'lucide-react';

const Dashboard: React.FC = () => {
    const [user, setUser] = useState<any>(null);
    const [profile, setProfile] = useState<any>(null);
    const [loading, setLoading] = useState(true);
    const navigate = useNavigate();
    const supabase = createClient();

    useEffect(() => {
        const checkUser = async () => {
            const { data: { user } } = await supabase.auth.getUser();
            if (!user) {
                navigate('/app/login');
                return;
            }
            setUser(user);

            // Fetch profile
            const { data: profileData } = await supabase
                .from('profiles')
                .select('name, age, gender')
                .eq('id', user.id)
                .single();

            setProfile(profileData);
            setLoading(false);
        };

        checkUser();
    }, [navigate]);

    if (loading) {
        return (
            <div className="min-h-screen bg-blue-950 flex items-center justify-center">
                <div className="w-12 h-12 border-4 border-blue-400 border-t-transparent rounded-full animate-spin"></div>
            </div>
        );
    }

    return (
        <div className="min-h-screen bg-gradient-to-br from-blue-950 via-indigo-950 to-slate-950 p-6 md:p-12 text-white font-inter">
            <header className="max-w-6xl mx-auto mb-16 animate-in fade-in slide-in-from-top-4 duration-700">
                <div className="flex items-center gap-4 mb-6">
                    <div className="bg-blue-500/20 p-3 rounded-2xl border border-blue-500/30">
                        <Shield className="text-blue-400 w-6 h-6" />
                    </div>
                    <span className="text-blue-400/60 text-xs font-black uppercase tracking-[0.4em]">Clinical Dashboard v4.0</span>
                </div>
                <h1 className="text-5xl md:text-7xl font-black tracking-tighter mb-4">
                    CardioGuard <span className="text-transparent bg-clip-text bg-gradient-to-r from-blue-400 to-indigo-400">Intelligence</span>
                </h1>
                <p className="text-xl text-blue-200/60 font-medium">
                    Hello, <span className="text-white font-bold">{profile?.name || user.email?.split('@')[0]}</span> • Your cardiovascular metrics are synchronized.
                </p>
            </header>

            <main className="max-w-6xl mx-auto grid grid-cols-1 md:grid-cols-2 gap-8 animate-in fade-in slide-in-from-bottom-8 duration-1000 delay-200">
                {/* Latest Risk Assessment */}
                <div className="group bg-white/5 backdrop-blur-2xl p-10 rounded-[2.5rem] border border-white/10 hover:border-blue-500/30 transition-all duration-500 shadow-2xl">
                    <div className="flex items-center justify-between mb-8">
                        <div className="w-14 h-14 bg-blue-500/20 rounded-2xl flex items-center justify-center border border-blue-500/20 group-hover:scale-110 transition-transform">
                            <Activity className="text-blue-400 w-7 h-7" />
                        </div>
                        <span className="bg-emerald-500/10 text-emerald-400 text-[10px] font-black px-4 py-1.5 rounded-full uppercase tracking-widest border border-emerald-500/20">Active Node</span>
                    </div>
                    <h2 className="text-3xl font-black mb-4 tracking-tight">Biometric Insight</h2>
                    <p className="text-blue-200/50 mb-8 leading-relaxed">No critical anomalies detected in the last 24 hours. Your heart rate variability remains within clinical bounds.</p>
                    <button onClick={() => navigate('/analyze')} className="flex items-center gap-3 text-xs font-black uppercase tracking-widest text-blue-400 hover:text-white transition-colors">
                        Run Forensic Scan →
                    </button>
                </div>

                {/* Vitals Trends */}
                <div className="group bg-white/5 backdrop-blur-2xl p-10 rounded-[2.5rem] border border-white/10 hover:border-indigo-500/30 transition-all duration-500 shadow-2xl">
                    <div className="flex items-center justify-between mb-8">
                        <div className="w-14 h-14 bg-indigo-500/20 rounded-2xl flex items-center justify-center border border-indigo-500/20 group-hover:scale-110 transition-transform">
                            <TrendingUp className="text-indigo-400 w-7 h-7" />
                        </div>
                    </div>
                    <h2 className="text-3xl font-black mb-4 tracking-tight">Vitals Analytics</h2>
                    <p className="text-blue-200/50 mb-8 leading-relaxed">Your recovery trends show a 12% improvement over the last cycle. Continue current cardiovascular protocols.</p>
                    <button onClick={() => navigate('/trends')} className="flex items-center gap-3 text-xs font-black uppercase tracking-widest text-indigo-400 hover:text-white transition-colors">
                        View Full Matrix →
                    </button>
                </div>
            </main>

            {/* Security Signature */}
            <div className="mt-20 max-w-6xl mx-auto flex flex-col md:flex-row items-center justify-between gap-6 pt-8 border-t border-white/5">
                <div className="flex items-center gap-4 text-white/20">
                    <Cpu size={18} />
                    <span className="text-[10px] font-black uppercase tracking-[0.2em]">Validated via Neuro-Symbolic Engine</span>
                </div>
                <div className="bg-black/40 px-6 py-3 rounded-2xl border border-white/5 text-[10px] font-mono text-blue-400/60">
                    UPLINK_ID: {user.id.substring(0, 12).toUpperCase()} // SESSION_SECURE
                </div>
            </div>
        </div>
    );
};

export default Dashboard;
