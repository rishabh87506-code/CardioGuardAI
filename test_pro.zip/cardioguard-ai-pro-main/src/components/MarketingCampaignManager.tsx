
import React, { useState, useEffect } from 'react';
import {
    Megaphone, CheckCircle2, XCircle, Share2,
    Twitter, Linkedin, Instagram, RefreshCw,
    Loader2, Sparkles, Send, Mail
} from 'lucide-react';
import { MarketingDraft, SocialChannel } from '../types';
import { generateMarketingDrafts, approveDraft } from '../services/marketingAgent';

interface MarketingCampaignManagerProps {
    onBack?: () => void;
}

const MarketingCampaignManager: React.FC<MarketingCampaignManagerProps> = ({ onBack }) => {
    const [drafts, setDrafts] = useState<MarketingDraft[]>([]);
    const [loading, setLoading] = useState(false);
    const [processingId, setProcessingId] = useState<string | null>(null);

    const loadDrafts = async () => {
        setLoading(true);
        try {
            const newDrafts = await generateMarketingDrafts();
            setDrafts(newDrafts);
        } catch (e) {
            console.error(e);
        } finally {
            setLoading(false);
        }
    };

    useEffect(() => {
        loadDrafts();
    }, []);

    const handleApprove = async (draft: MarketingDraft) => {
        setProcessingId(draft.id);
        try {
            const updated = await approveDraft(draft);
            setDrafts(prev => prev.map(d => d.id === draft.id ? updated : d));
        } finally {
            setProcessingId(null);
        }
    };

    const handleReject = (id: string) => {
        setDrafts(prev => prev.map(d => d.id === id ? { ...d, status: 'rejected' } : d));
    };

    const getIcon = (channel: SocialChannel) => {
        switch (channel) {
            case 'twitter': return <Twitter className="w-5 h-5 text-sky-400" />;
            case 'linkedin': return <Linkedin className="w-5 h-5 text-blue-600" />;
            case 'instagram': return <Instagram className="w-5 h-5 text-pink-500" />;
            case 'email': return <Mail className="w-5 h-5 text-slate-400" />;
        }
    };

    return (
        <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500 pb-24">
            <div className="bg-slate-900 rounded-[3rem] p-10 text-white relative overflow-hidden shadow-2xl">
                <div className="absolute top-0 right-0 p-10 opacity-10">
                    <Megaphone className="w-48 h-48" />
                </div>
                <div className="relative z-10 space-y-6">
                    <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-indigo-600/20 border border-indigo-500/30 text-indigo-400 text-[10px] font-black uppercase tracking-widest">
                        <Sparkles className="w-4 h-4" /> Marketing Agent Active
                    </div>
                    <h2 className="text-4xl font-black tracking-tighter">Campaign Command.</h2>
                    <p className="text-slate-400 font-bold max-w-sm">
                        Review and approve AI-generated social content based on your recent health milestones.
                    </p>
                    <button
                        onClick={loadDrafts}
                        disabled={loading}
                        className="px-6 py-3 bg-white text-slate-900 rounded-2xl font-black text-xs uppercase tracking-widest hover:bg-indigo-50 transition-all flex items-center gap-3"
                    >
                        {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : <RefreshCw className="w-4 h-4" />}
                        Generate New Drafts
                    </button>
                </div>
            </div>

            <div className="grid gap-6">
                {drafts.map((draft) => (
                    <div
                        key={draft.id}
                        className={`
              relative p-6 rounded-[2rem] border transition-all duration-500
              ${draft.status === 'posted' ? 'bg-emerald-50 border-emerald-200 opacity-80' :
                                draft.status === 'rejected' ? 'bg-slate-50 border-slate-100 opacity-50 grayscale' :
                                    'bg-white border-slate-100 shadow-xl hover:translate-y-[-4px]'}
            `}
                    >
                        {draft.status === 'posted' && (
                            <div className="absolute top-6 right-6 flex items-center gap-2 text-emerald-600">
                                <CheckCircle2 className="w-6 h-6" />
                                <span className="text-xs font-black uppercase tracking-widest">Posted</span>
                            </div>
                        )}

                        <div className="flex items-start gap-4 mb-4">
                            <div className="p-3 bg-slate-50 rounded-2xl border border-slate-100">
                                {getIcon(draft.channel)}
                            </div>
                            <div>
                                <div className="flex items-center gap-3">
                                    <span className="text-xs font-black text-slate-900 uppercase tracking-widest">{draft.channel}</span>
                                    <span className="px-2 py-0.5 bg-indigo-50 text-indigo-600 rounded-full text-[9px] font-bold uppercase tracking-widest">
                                        {draft.predictedEngagement} Impact
                                    </span>
                                </div>
                                <p className="text-[10px] text-slate-400 font-bold uppercase mt-1">Generated {new Date(draft.timestamp).toLocaleTimeString()}</p>
                            </div>
                        </div>

                        <div className="bg-slate-50 p-6 rounded-2xl border border-slate-100 mb-6">
                            <p className="text-slate-700 font-medium leading-relaxed">{draft.content}</p>
                            <div className="flex flex-wrap gap-2 mt-4">
                                {draft.hashtags.map(tag => (
                                    <span key={tag} className="text-blue-500 text-xs font-bold">{tag}</span>
                                ))}
                            </div>
                        </div>

                        {draft.status === 'draft' && (
                            <div className="flex items-center gap-4">
                                <button
                                    onClick={() => handleApprove(draft)}
                                    disabled={!!processingId}
                                    className="flex-1 py-4 bg-slate-900 text-white rounded-2xl font-black text-xs uppercase tracking-widest hover:bg-emerald-600 transition-all flex items-center justify-center gap-2 shadow-lg disabled:opacity-50"
                                >
                                    {processingId === draft.id ? <Loader2 className="w-4 h-4 animate-spin" /> : <Send className="w-4 h-4" />}
                                    Approve & Post
                                </button>
                                <button
                                    onClick={() => handleReject(draft.id)}
                                    disabled={!!processingId}
                                    className="px-6 py-4 bg-white text-slate-400 border border-slate-200 rounded-2xl font-black text-xs uppercase tracking-widest hover:bg-rose-50 hover:text-rose-500 hover:border-rose-200 transition-all"
                                >
                                    Reject
                                </button>
                            </div>
                        )}
                    </div>
                ))}
            </div>
        </div>
    );
};

export default MarketingCampaignManager;
