
import React from 'react';
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  AreaChart,
  Area
} from 'recharts';
import { HistoricalAssessment, SupportedLanguage } from '../types';
import { TrendingUp, Activity, Heart, Calendar } from 'lucide-react';
import MedicalDisclaimer from './MedicalDisclaimer';

interface TrendDashboardProps {
  history: HistoricalAssessment[];
  onBack: () => void;
  language: SupportedLanguage;
}

const TrendDashboard: React.FC<TrendDashboardProps> = ({ history, onBack, language }) => {
  const data = [...history].reverse().map(h => ({
    date: new Date(h.timestamp).toLocaleDateString(undefined, { month: 'short', day: 'numeric' }),
    risk: h.riskScore,
    systolic: h.vitals.systolicBP,
    diastolic: h.vitals.diastolicBP
  }));

  if (history.length < 2) {
    return (
      <div className="flex flex-col items-center justify-center py-20 text-center space-y-4 bg-white rounded-[2.5rem] border border-slate-100 shadow-sm">
        <TrendingUp className="w-12 h-12 text-slate-200" />
        <div className="max-w-xs">
          <h3 className="text-xl font-bold text-slate-900">Insufficient Data</h3>
          <p className="text-slate-500 mt-2 text-sm leading-relaxed">Complete at least two assessments to unlock predictive health trends and analytics.</p>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6 animate-in fade-in slide-in-from-bottom-4 duration-500">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {/* Risk Trend */}
        <div className="bg-white p-6 rounded-[2rem] border border-slate-100 shadow-sm">
          <div className="flex items-center gap-2 mb-6">
            <div className="p-2 bg-rose-50 rounded-lg">
              <Heart className="w-4 h-4 text-rose-600" />
            </div>
            <h3 className="font-bold text-slate-800">Risk Score Variance</h3>
          </div>
          <div className="h-48 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={data}>
                <defs>
                  <linearGradient id="colorRisk" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#ef4444" stopOpacity={0.1} />
                    <stop offset="95%" stopColor="#ef4444" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <XAxis dataKey="date" hide />
                <YAxis hide domain={[0, 100]} />
                <Tooltip
                  contentStyle={{ borderRadius: '16px', border: 'none', boxShadow: '0 10px 15px -3px rgb(0 0 0 / 0.1)' }}
                  itemStyle={{ fontWeight: 'bold' }}
                />
                <Area type="monotone" dataKey="risk" stroke="#ef4444" strokeWidth={3} fillOpacity={1} fill="url(#colorRisk)" />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* BP Trend */}
        <div className="bg-white p-6 rounded-[2rem] border border-slate-100 shadow-sm">
          <div className="flex items-center gap-2 mb-6">
            <div className="p-2 bg-blue-50 rounded-lg">
              <Activity className="w-4 h-4 text-blue-600" />
            </div>
            <h3 className="font-bold text-slate-800">Blood Pressure Baseline</h3>
          </div>
          <div className="h-48 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={data}>
                <XAxis dataKey="date" hide />
                <YAxis hide domain={['dataMin - 10', 'dataMax + 10']} />
                <Tooltip
                  contentStyle={{ borderRadius: '16px', border: 'none', boxShadow: '0 10px 15px -3px rgb(0 0 0 / 0.1)' }}
                />
                <Line type="monotone" dataKey="systolic" stroke="#3b82f6" strokeWidth={3} dot={{ r: 4, fill: '#3b82f6' }} />
                <Line type="monotone" dataKey="diastolic" stroke="#93c5fd" strokeWidth={3} dot={{ r: 4, fill: '#93c5fd' }} />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>

      <div className="bg-slate-900 rounded-[2.5rem] p-8 text-white relative overflow-hidden">
        <div className="absolute top-0 right-0 p-8 opacity-10">
          <TrendingUp className="w-32 h-32" />
        </div>
        <div className="relative z-10">
          <span className="text-[10px] font-black uppercase tracking-[0.3em] text-blue-400">AI Narrative</span>
          <h2 className="text-2xl font-bold mt-2">Overall Progress</h2>
          <p className="text-slate-400 mt-4 leading-relaxed max-w-lg">
            Based on your last {history.length} scans, your cardiovascular risk is trending
            <span className="text-emerald-400 font-bold"> stable</span>. Maintaining a consistent activity score has contributed to a 2% reduction in predicted variance over the last month.
          </p>
          <div className="flex gap-4 mt-8">
            <div className="px-4 py-2 bg-white/10 rounded-xl border border-white/10">
              <p className="text-[10px] text-slate-400 font-bold uppercase tracking-wider">Avg. Risk</p>
              <p className="text-xl font-black">{(history.reduce((acc, h) => acc + h.riskScore, 0) / history.length).toFixed(1)}%</p>
            </div>
            <div className="px-4 py-2 bg-white/10 rounded-xl border border-white/10">
              <p className="text-[10px] text-slate-400 font-bold uppercase tracking-wider">Stabilized BP</p>
              <p className="text-xl font-black">{Math.round(history[0].vitals.systolicBP)}/80</p>
            </div>
          </div>
        </div>
      </div>

      <MedicalDisclaimer />
    </div>
  );
};

export default TrendDashboard;
