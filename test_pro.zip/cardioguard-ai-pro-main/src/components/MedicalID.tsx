import React, { useRef } from 'react';
import {
    ShieldAlert,
    User,
    MapPin,
    PhoneCall,
    QrCode,
    Download,
    Heart,
    Activity,
    AlertTriangle,
    ChevronLeft,
    Printer,
    AlertCircle
} from 'lucide-react';
import { VitalsData, AssessmentResult } from '../types';

interface MedicalIDProps {
    onBack: () => void;
    vitals?: VitalsData | null;
    assessment?: AssessmentResult | null;
}

const MedicalID: React.FC<MedicalIDProps> = ({ onBack, vitals, assessment }) => {
    const cardRef = useRef<HTMLDivElement>(null);

    const handlePrint = () => {
        window.print();
    };

    return (
        <div className="space-y-10 animate-in fade-in slide-in-from-bottom-5 duration-700 pb-20">
            {/* HEADER */}
            <div className="flex items-center justify-between print:hidden">
                <button
                    onClick={onBack}
                    className="flex items-center gap-3 text-slate-500 hover:text-cyan-600 transition-all font-black text-[10px] uppercase tracking-widest"
                >
                    <ChevronLeft className="w-4 h-4" /> Return to Dashboard
                </button>
                <button
                    onClick={handlePrint}
                    className="flex items-center gap-3 px-6 py-3 bg-slate-900 text-white rounded-2xl font-black text-[10px] hover:bg-slate-800 transition-all shadow-xl shadow-slate-900/20 uppercase tracking-[0.2em]"
                >
                    <Printer className="w-4 h-4" /> Export Physical Card
                </button>
            </div>

            <header className="space-y-4 print:hidden">
                <h1 className="text-5xl font-black tracking-tighter text-slate-900">Emergency <span className="text-rose-600">Medical ID</span></h1>
                <p className="text-slate-500 text-lg font-medium max-w-2xl leading-relaxed">
                    Your secure, clinician-ready identity card. Includes critical conditions, allergies, and the latest risk telemetry for first responders.
                </p>
            </header>

            {/* MEDICAL ID CARD */}
            <div ref={cardRef} className="max-w-xl mx-auto bg-white rounded-[3rem] shadow-2xl overflow-hidden border border-slate-100 flex flex-col relative print:shadow-none print:border-slate-300">

                {/* TOP ALERT BAR */}
                <div className="bg-rose-600 p-4 text-center">
                    <p className="text-[10px] font-black text-white uppercase tracking-[0.4em] flex items-center justify-center gap-3">
                        <ShieldAlert size={14} /> Emergency Medical Profile
                    </p>
                </div>

                <div className="p-8 md:p-12 space-y-8">
                    {/* PHOTO & BASIC IDENTITY */}
                    <div className="flex flex-col md:flex-row gap-8 items-center md:items-start text-center md:text-left">
                        <div className="w-32 h-32 bg-slate-100 rounded-[2rem] flex items-center justify-center relative overflow-hidden ring-4 ring-slate-50">
                            <User size={64} className="text-slate-300" />
                        </div>
                        <div className="space-y-2">
                            <h2 className="text-4xl font-black text-slate-950 tracking-tighter uppercase">{vitals?.patientName || 'IDENTITY DISCONNECTED'}</h2>
                            <div className="flex flex-wrap justify-center md:justify-start gap-4">
                                <span className="text-xs font-black text-slate-400 uppercase tracking-widest bg-slate-50 px-3 py-1 rounded-lg">DOB: 12/04/1981</span>
                                <span className="text-xs font-black text-slate-400 uppercase tracking-widest bg-slate-50 px-3 py-1 rounded-lg">Blood: O Pos (+)</span>
                            </div>
                        </div>
                    </div>

                    {/* CRITICAL ALERTS */}
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <div className="bg-rose-50 border border-rose-100 p-6 rounded-[2rem] space-y-3">
                            <div className="flex items-center gap-2 text-rose-600">
                                <AlertTriangle size={16} />
                                <h3 className="text-[10px] font-black uppercase tracking-widest">Medical Conditions</h3>
                            </div>
                            <ul className="text-sm font-black text-rose-900 space-y-1">
                                <li>• Hypertension (Grade II)</li>
                                <li>• Acute Myocardial History</li>
                            </ul>
                        </div>

                        <div className="bg-amber-50 border border-amber-100 p-6 rounded-[2rem] space-y-3">
                            <div className="flex items-center gap-2 text-amber-600">
                                <AlertCircle size={16} />
                                <h3 className="text-[10px] font-black uppercase tracking-widest">Known Allergies</h3>
                            </div>
                            <ul className="text-sm font-black text-amber-900 space-y-1">
                                <li>• Penicillin G</li>
                                <li>• Contrast Media (Iodine)</li>
                            </ul>
                        </div>
                    </div>

                    {/* LATEST VITALS TELEMETRY */}
                    <div className="bg-slate-900 rounded-[2.5rem] p-8 text-white relative overflow-hidden">
                        <div className="absolute top-0 right-0 p-8 opacity-10">
                            <Activity size={48} />
                        </div>
                        <h3 className="text-[10px] font-black text-cyan-400 uppercase tracking-[0.3em] mb-6 flex items-center gap-2">
                            <Heart size={14} /> Last Captured Telemetry
                        </h3>
                        <div className="grid grid-cols-3 gap-4">
                            <div className="text-center">
                                <p className="text-[9px] font-black text-slate-500 uppercase mb-1">BP</p>
                                <p className="text-lg font-black">{vitals?.systolicBP || '--'}/{vitals?.diastolicBP || '--'}</p>
                            </div>
                            <div className="text-center">
                                <p className="text-[9px] font-black text-slate-500 uppercase mb-1">HR</p>
                                <p className="text-lg font-black">{vitals?.heartRate || '--'}BPM</p>
                            </div>
                            <div className="text-center">
                                <p className="text-[9px] font-black text-slate-500 uppercase mb-1">Risk</p>
                                <p className={`text-lg font-black ${assessment?.riskCategory === 'High' ? 'text-rose-500' : 'text-emerald-500'}`}>{assessment?.riskScore || '--'}%</p>
                            </div>
                        </div>
                    </div>

                    {/* EMERGENCY CONTACTS */}
                    <div className="space-y-4">
                        <h3 className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Primary Emergency Contact</h3>
                        <div className="flex items-center justify-between p-6 bg-slate-50 rounded-[2rem] border border-slate-100">
                            <div>
                                <p className="text-sm font-black text-slate-950 uppercase">Jane Doe <span className="text-slate-400 lowercase">(Spouse)</span></p>
                                <p className="text-xs font-bold text-slate-500 mt-1">+1 (555) 012-3492</p>
                            </div>
                            <button className="p-4 bg-slate-950 text-white rounded-2xl shadow-xl active:scale-95 transition-all">
                                <PhoneCall size={20} />
                            </button>
                        </div>
                    </div>

                    {/* QR IDENTIFIER */}
                    <div className="pt-8 border-t border-slate-100 flex flex-col md:flex-row items-center gap-8">
                        <div className="p-4 bg-slate-50 rounded-3xl border border-slate-100">
                            <QrCode size={80} className="text-slate-900" />
                        </div>
                        <div className="flex-1 space-y-2">
                            <p className="text-[9px] font-black text-slate-400 uppercase tracking-widest">Digital Healthcare Hash</p>
                            <p className="text-[10px] font-mono font-bold text-slate-600 break-all">CG-AI-SHA256-0X49BS294K29L58N9P</p>
                            <p className="text-[9px] font-bold text-rose-600 uppercase tracking-tighter">Scan to unlock secure clinical records</p>
                        </div>
                    </div>
                </div>

                {/* FOOTER */}
                <div className="bg-slate-50 border-t border-slate-100 p-6 text-center">
                    <p className="text-[9px] font-black text-slate-400 uppercase tracking-[0.25em]">CardioGuard Medical Node v4.1 • © 2026</p>
                </div>
            </div>

            {/* DISCLOSURE */}
            <div className="p-8 bg-sky-50 rounded-[2.5rem] border border-sky-100 flex gap-6 print:hidden">
                <MapPin className="text-cyan-600 shrink-0" size={24} />
                <p className="text-[10px] font-bold text-slate-500 uppercase tracking-widest leading-relaxed">
                    <strong className="text-slate-800">Operational Notice:</strong> This Medical ID is a locally cached fallback for first responders. In active sessions, location data is automatically shared with dispatch nodes if the Emergency SOS is triggered.
                </p>
            </div>
        </div>
    );
};

export default MedicalID;
