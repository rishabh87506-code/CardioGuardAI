
import React, { useState } from 'react';
import {
  FolderLock, FileText, Upload, ShieldCheck,
  Stethoscope, AlertCircle, Loader2, Sparkles,
  ChevronRight, FileWarning, CheckCircle2,
  Share2, HardDrive, Filter, QrCode, Link
} from 'lucide-react';
import { MedicalDocument, SupportedLanguage } from '../types';
import { analyzeMedicalDocument } from '../services/geminiService';
import { uploadMedicalDocument, createDocumentRecord, createEmergencyAccess } from '../services/supabaseService';
import MedicalDisclaimer from './MedicalDisclaimer';

interface MedicalLockerProps {
  onBack: () => void;
  language: SupportedLanguage;
  storageMode: 'cloud' | 'local';
  onToggleStorage: (mode: 'cloud' | 'local') => void;
}

const MedicalLocker: React.FC<MedicalLockerProps> = ({ onBack, language, storageMode, onToggleStorage }) => {
  const [docs, setDocs] = useState<MedicalDocument[]>([]);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [isUploading, setIsUploading] = useState(false);
  const [selectedDoc, setSelectedDoc] = useState<MedicalDocument | null>(null);
  const [emergencyToken, setEmergencyToken] = useState<string | null>(null);
  const [showShareModal, setShowShareModal] = useState(false);

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setIsUploading(true);
    // simulated patient ID for demo
    const patientId = 'user-123';

    try {
      let storagePath: string | null = null;

      // 1. Upload based on mode
      if (storageMode === 'cloud') {
        storagePath = await uploadMedicalDocument(file, patientId);
        if (!storagePath) throw new Error("Cloud Upload failed");
      } else {
        // Local Mode: We don't upload to Supabase.
        // In a real app, we'd persist the base64 to IndexedDB.
        // For now, we simulate success with a local identifier.
        await new Promise(r => setTimeout(r, 800)); // Simulate delay
        storagePath = `local://${file.name}`;
      }

      // 2. Client-side preview & analysis
      const reader = new FileReader();
      reader.onload = async (event) => {
        const base64 = (event.target?.result as string).split(',')[1];

        const newDoc: MedicalDocument = {
          id: crypto.randomUUID(),
          type: 'Lab Report', // Default, would be dynamic
          fileName: file.name,
          uploadDate: Date.now(),
          base64Data: base64,
          storagePath: storagePath // stored reference
        };

        setDocs(prev => [newDoc, ...prev]);

        // Auto-analyze
        setIsAnalyzing(true);
        try {
          const analysis = await analyzeMedicalDocument(newDoc, language);

          // 3. Save metadata to Supabase DB
          const completeDoc = { ...newDoc, analysis };
          await createDocumentRecord(completeDoc, patientId);

          setDocs(prev => prev.map(d => d.id === newDoc.id ? completeDoc : d));
        } catch (err) {
          console.error("Analysis failed", err);
        } finally {
          setIsAnalyzing(false);
          setIsUploading(false);
        }
      };
      reader.readAsDataURL(file);

    } catch (err) {
      console.error("Process failed", err);
      setIsUploading(false);
    }
  };

  const handleGenerateEmergencyLink = async () => {
    const grant = await createEmergencyAccess('user-123'); // Demo user
    if (grant) {
      setEmergencyToken(grant.token);
      setShowShareModal(true);
    }
  };

  const getUrgencyColor = (score: number) => {
    if (score > 75) return 'text-rose-600 bg-rose-50 border-rose-100';
    if (score > 40) return 'text-amber-600 bg-amber-50 border-amber-100';
    return 'text-emerald-600 bg-emerald-50 border-emerald-100';
  };

  return (
    <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500">
      <div className="bg-slate-950 rounded-[3rem] p-10 text-white relative overflow-hidden shadow-2xl">
        <div className="absolute top-0 right-0 p-10 opacity-10">
          <FolderLock className="w-48 h-48" />
        </div>
        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-8">
          <div className="space-y-4">
            <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-blue-600/20 border border-blue-500/30 text-blue-400 text-[10px] font-black uppercase tracking-widest">
              <ShieldCheck className="w-4 h-4" /> Secure Medical Locker
            </div>
            <h2 className="text-4xl font-black tracking-tighter">Biometric Archive.</h2>
            <p className="text-slate-400 font-bold max-w-sm">Store CTs, Echoes, and Lab reports in a highly secure clinical environment.</p>
          </div>

          <label className="bg-white text-slate-950 px-8 py-5 rounded-2xl font-black text-xs uppercase tracking-widest cursor-pointer hover:bg-blue-50 transition-all flex items-center gap-3 shadow-xl">
            {isUploading ? <Loader2 className="w-5 h-5 animate-spin" /> : <Upload className="w-5 h-5" />}
            {isUploading ? 'Ingesting...' : 'Ingest Medical File'}
            <input type="file" className="hidden" accept="image/*" onChange={handleFileUpload} disabled={isUploading} />
          </label>
        </div>
      </div>

      <div className="flex justify-end px-4">
        <button
          onClick={handleGenerateEmergencyLink}
          className="flex items-center gap-2 px-6 py-3 bg-red-600 text-white rounded-2xl font-black text-xs uppercase tracking-widest hover:bg-red-700 transition-all shadow-lg hover:shadow-red-500/20"
        >
          <QrCode className="w-4 h-4" /> Generate Emergency Access Token
        </button>
      </div>

      {/* Hospital Integration Stub */}
      <div className="bg-white rounded-[2rem] p-6 border border-sky-100 flex items-center justify-between shadow-sm">
        <div className="flex items-center gap-4">
          <div className="p-3 bg-slate-100 rounded-xl text-slate-400">
            <Stethoscope className="w-6 h-6" />
          </div>
          <div>
            <h3 className="font-black text-slate-900 text-sm uppercase tracking-wider">Hospital EHR Integration</h3>
            <p className="text-xs font-bold text-slate-400">Direct sync with Epic/Cerner systems.</p>
          </div>
        </div>
        <div className="px-4 py-2 bg-slate-100 text-slate-500 rounded-xl text-[10px] font-black uppercase tracking-widest border border-slate-200">
          Enterprise Access Required
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Document List */}
        <div className="lg:col-span-1 space-y-4">
          <div className="flex items-center justify-between px-2">
            <h3 className="text-[10px] font-black text-slate-400 uppercase tracking-widest flex items-center gap-2">
              <HardDrive className="w-3 h-3" /> Indexed Nodes ({docs.length})
            </h3>
            <Filter className="w-3 h-3 text-slate-400" />
          </div>

          {docs.length === 0 ? (
            <div className="bg-white border-2 border-dashed border-slate-200 rounded-[2rem] p-12 text-center space-y-4">
              <FileText className="w-10 h-10 text-slate-200 mx-auto" />
              <p className="text-[10px] font-black text-slate-300 uppercase tracking-widest">Locker Standby</p>
            </div>
          ) : (
            <div className="space-y-3">
              {docs.map(doc => (
                <div
                  key={doc.id}
                  onClick={() => setSelectedDoc(doc)}
                  className={`p-5 rounded-2xl border transition-all cursor-pointer group ${selectedDoc?.id === doc.id ? 'bg-slate-950 border-slate-900 text-white' : 'bg-white border-slate-100 hover:border-blue-200 shadow-sm'}`}
                >
                  <div className="flex items-start justify-between mb-3">
                    <div className={`p-2 rounded-lg ${selectedDoc?.id === doc.id ? 'bg-blue-600' : 'bg-slate-100 text-slate-400'}`}>
                      <FileText className="w-4 h-4" />
                    </div>
                    {doc.analysis?.isUrgent && <div className="w-2 h-2 rounded-full bg-rose-500 animate-pulse" />}
                  </div>
                  <h4 className="font-black text-sm tracking-tight truncate">{doc.fileName}</h4>
                  <div className="flex items-center gap-3 mt-1.5 opacity-60">
                    <span className="text-[9px] font-black uppercase tracking-widest">{doc.type}</span>
                    <span className="text-[9px] font-black uppercase tracking-widest">•</span>
                    <span className="text-[9px] font-black uppercase tracking-widest">{new Date(doc.uploadDate).toLocaleDateString()}</span>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* AI Analysis View */}
        <div className="lg:col-span-2">
          {selectedDoc ? (
            <div className="bg-white rounded-[2.5rem] p-10 border border-slate-100 shadow-xl space-y-8 animate-in fade-in slide-in-from-right-4">
              <div className="flex flex-col sm:flex-row justify-between items-start gap-6">
                <div className="space-y-1">
                  <span className="text-[10px] font-black text-blue-600 uppercase tracking-widest">Diagnostic Report analysis</span>
                  <h3 className="text-3xl font-black text-slate-950 tracking-tighter">{selectedDoc.fileName}</h3>
                </div>
                {selectedDoc.analysis && (
                  <div className={`px-6 py-3 rounded-2xl border flex items-center gap-3 ${getUrgencyColor(selectedDoc.analysis.criticality)}`}>
                    <div className="text-center">
                      <p className="text-[8px] font-black uppercase tracking-widest leading-none">Criticality</p>
                      <p className="text-xl font-black leading-none mt-1">{selectedDoc.analysis.criticality}%</p>
                    </div>
                    <FileWarning className="w-6 h-6" />
                  </div>
                )}
              </div>

              {!selectedDoc.analysis && isAnalyzing ? (
                <div className="py-20 flex flex-col items-center justify-center space-y-6">
                  <div className="relative">
                    <div className="absolute inset-0 bg-blue-500/20 blur-xl animate-pulse rounded-full" />
                    <Loader2 className="w-12 h-12 text-blue-600 animate-spin relative z-10" />
                  </div>
                  <p className="text-[10px] font-black text-slate-400 uppercase tracking-[0.5em]">Synthesizing Theory of Criticality...</p>
                </div>
              ) : selectedDoc.analysis ? (
                <div className="space-y-8">
                  <div className="bg-slate-50 rounded-3xl p-8 border border-slate-100 space-y-4">
                    <div className="flex items-center gap-3 text-slate-950">
                      <Stethoscope className="w-5 h-5" />
                      <h4 className="text-xs font-black uppercase tracking-widest">Doctor's Handover Brief</h4>
                    </div>
                    <p className="text-slate-600 font-bold leading-relaxed">{selectedDoc.analysis.summary}</p>
                  </div>

                  <div className="space-y-4">
                    <h4 className="text-xs font-black text-slate-400 uppercase tracking-widest flex items-center gap-2">
                      <Sparkles className="w-4 h-4 text-blue-600" /> Strategic Observations
                    </h4>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                      {selectedDoc.analysis.pointers.map((p, i) => (
                        <div key={i} className="flex gap-4 p-5 bg-white border border-slate-100 rounded-2xl shadow-sm hover:border-blue-100 transition-all">
                          <CheckCircle2 className="w-5 h-5 text-blue-600 shrink-0" />
                          <span className="text-xs font-bold text-slate-700 leading-snug">{p}</span>
                        </div>
                      ))}
                    </div>
                  </div>

                  <div className="pt-8 border-t border-slate-100 flex justify-between items-center">
                    <button className="flex items-center gap-2 px-6 py-3 bg-slate-950 text-white rounded-xl text-[10px] font-black uppercase tracking-widest hover:bg-blue-600 transition-all">
                      <Share2 className="w-4 h-4" /> Share Secure Node
                    </button>
                    <p className="text-[8px] font-black text-slate-300 uppercase tracking-widest">Verified by CardioGuard v2.8</p>
                  </div>
                </div>
              ) : null}
            </div>
          ) : (
            <div className="h-full bg-white rounded-[2.5rem] border-2 border-dashed border-slate-100 flex flex-col items-center justify-center p-20 text-center space-y-6">
              <div className="p-8 bg-slate-50 rounded-[3rem]">
                <FolderLock className="w-16 h-16 text-slate-200" />
              </div>
              <div className="max-w-xs space-y-2">
                <h4 className="text-xl font-black text-slate-900 tracking-tight">Select Node for Analysis</h4>
                <p className="text-xs text-slate-400 font-bold uppercase tracking-widest">AI analysis standby. Ingest a clinical file to begin the Theory of Criticality synthesis.</p>
              </div>
            </div>
          )}
        </div>
      </div>

      {showShareModal && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-center justify-center p-6 animate-in fade-in">
          <div className="bg-white rounded-[2rem] p-8 max-w-sm w-full space-y-6 shadow-2xl">
            <div className="text-center space-y-2">
              <div className="w-16 h-16 bg-red-50 rounded-2xl flex items-center justify-center mx-auto mb-4">
                <AlertCircle className="w-8 h-8 text-red-600" />
              </div>
              <h3 className="text-2xl font-black text-slate-900">Emergency Access</h3>
              <p className="text-xs font-bold text-slate-500">Share this token with verified medical personnel only.</p>
            </div>

            <div className="bg-slate-900 p-6 rounded-2xl text-center space-y-2">
              <p className="text-[10px] font-black text-slate-400 uppercase tracking-[0.2em]">Access Token</p>
              <p className="text-4xl font-mono font-black text-white tracking-widest">{emergencyToken}</p>
            </div>

            <div className="p-4 bg-blue-50 border border-blue-100 rounded-xl flex items-start gap-3">
              <Link className="w-5 h-5 text-blue-600 shrink-0 mt-0.5" />
              <div className="space-y-1">
                <p className="text-[10px] font-black text-blue-700 uppercase tracking-widest">Direct Link Active</p>
                <p className="text-[10px] font-bold text-blue-600 leading-snug">
                  Token expires in 24 hours. Access grants read-only permissions for all historical data.
                </p>
              </div>
            </div>

            <button
              onClick={() => setShowShareModal(false)}
              className="w-full py-4 bg-slate-200 hover:bg-slate-300 text-slate-900 rounded-xl font-black text-xs uppercase tracking-widest transition-colors"
            >
              Close Secure Modal
            </button>
          </div>
        </div>
      )}

      <MedicalDisclaimer />
    </div>
  );
};

export default MedicalLocker;
