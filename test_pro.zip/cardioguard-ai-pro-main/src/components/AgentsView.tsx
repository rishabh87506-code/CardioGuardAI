import React from 'react';
import {
    Bot, Activity, Shield, ArrowRight, Database, Users,
    Megaphone, ArrowLeft, Code2, Zap, ShieldCheck
} from 'lucide-react';
import { useNavigate } from 'react-router-dom';

interface AgentsViewProps {
    onBack?: () => void;
}

export default function AgentsView({ onBack }: AgentsViewProps) {
    const navigate = useNavigate();

    const agents = [
        {
            id: 'analyst',
            name: 'Cardio Risk Analyst',
            role: 'Clinical Intelligence',
            desc: 'Analyzes your vital signs against millions of clinical data points to assess cardiovascular risk.',
            icon: Activity,
            color: 'text-blue-400',
            bg: 'bg-blue-500/10'
        },
        {
            id: 'concierge',
            name: 'Cardio Concierge',
            role: 'Personal Health Assistant',
            desc: 'Provides 24/7 answers to your heart health questions and offers personalized lifestyle guidance.',
            icon: Users,
            color: 'text-indigo-400',
            bg: 'bg-indigo-500/10'
        },
        {
            id: 'sentinel',
            name: 'Sentinel Guardian',
            role: 'Proactive Monitoring',
            desc: 'Continuously monitors for anomalies and specific women\'s health indicators to provide early warnings.',
            icon: Shield,
            color: 'text-emerald-400',
            bg: 'bg-emerald-500/10'
        },
        {
            id: 'marketing',
            name: 'Marketing Strategist',
            role: 'Growth & Outreach',
            desc: 'Generates viral social media content based on your health milestones. You approve every post.',
            icon: Megaphone,
            color: 'text-pink-400',
            bg: 'bg-pink-500/10'
        },
        {
            id: 'dev',
            name: 'Web Dev Agent',
            role: 'System Optimization',
            desc: 'Autonomous agent that handles UI polish, API hardening, and cross-device optimization in high-speed sprints.',
            icon: Code2,
            color: 'text-tesla-cyan',
            bg: 'bg-tesla-cyan/10'
        },
        {
            id: 'auditor',
            name: 'Security & Integrity Auditor',
            role: 'Extreme Risk Forensic',
            desc: 'System-wide auditor that identifies code-sharing leaks, security fallbacks, and logic shortcomings.',
            icon: ShieldCheck,
            color: 'text-emerald-400',
            bg: 'bg-emerald-500/10'
        }
    ];

    return (
        <div className="max-w-7xl mx-auto space-y-12 animate-in fade-in slide-in-from-bottom-4 duration-500 pb-12 p-6">
            <div className="text-center space-y-4">
                <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-white/10 text-tesla-cyan text-[10px] font-black uppercase tracking-[0.2em] mb-2 border border-white/5">
                    <Bot className="w-3.5 h-3.5" /> AI System Core
                </div>
                <h1 className="text-5xl font-black text-white tracking-tighter font-display">Meet Your Health Agents</h1>
                <p className="text-slate-400 font-medium text-lg max-w-2xl mx-auto">
                    CardioGuard AI is powered by a team of specialized agents working together to protect your heart health.
                </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                {agents.map((agent) => (
                    <div key={agent.id} className="glass-apple p-8 rounded-[2rem] border-white/5 shadow-xl hover:hyper-glow transition-all group relative overflow-hidden">
                        <div className="absolute top-4 right-4 flex items-center gap-1.5 px-3 py-1 bg-white/5 rounded-full border border-white/5">
                            <div className="w-1.5 h-1.5 rounded-full animate-pulse bg-emerald-400"></div>
                            <span className="text-[9px] font-black uppercase tracking-widest text-slate-400">Clinical Ready</span>
                        </div>
                        <div className={`w-14 h-14 rounded-2xl flex items-center justify-center mb-6 ${agent.bg} ${agent.color}`}>
                            <agent.icon className="w-7 h-7" strokeWidth={agent.id === 'dev' ? 2 : 1.5} />
                        </div>
                        <h3 className="text-xl font-black text-white mb-1 font-display">{agent.name}</h3>
                        <p className="text-[10px] font-black uppercase tracking-widest text-slate-500 mb-4">{agent.role}</p>
                        <p className="text-sm text-slate-400 leading-relaxed font-medium">
                            {agent.desc}
                        </p>
                        {agent.id === 'marketing' && (
                            <button
                                onClick={() => navigate('/marketing')}
                                className="mt-4 px-4 py-2 bg-white/10 text-white rounded-xl text-[10px] font-black uppercase tracking-widest hover:bg-white/20 transition-all w-full flex items-center justify-center gap-2"
                            >
                                <Megaphone className="w-3 h-3" /> Open Campaign Manager
                            </button>
                        )}
                        {agent.id === 'dev' && (
                            <button
                                onClick={() => navigate('/dev-workspace')}
                                className="mt-4 px-4 py-3 bg-tesla-cyan text-slate-900 rounded-xl text-[10px] font-black uppercase tracking-widest hover:bg-white transition-all w-full flex items-center justify-center gap-2 font-display"
                            >
                                <Zap className="w-3 h-3 fill-current" /> Launch Dev Workspace
                            </button>
                        )}
                        {agent.id === 'auditor' && (
                            <button
                                onClick={() => navigate('/audit-suite')}
                                className="mt-4 px-4 py-3 bg-emerald-600 text-white rounded-xl text-[10px] font-black uppercase tracking-widest hover:bg-emerald-700 transition-all w-full flex items-center justify-center gap-2 font-display"
                            >
                                <ShieldCheck className="w-3 h-3" /> Execute Extreme Audit
                            </button>
                        )}
                    </div>
                ))}
            </div>

            <div className="bg-bb-pitch rounded-[2.5rem] p-10 text-white relative overflow-hidden shadow-2xl border border-white/10">
                <div className="absolute top-0 right-0 p-12 opacity-5">
                    <Database className="w-64 h-64" />
                </div>

                <div className="relative z-10 flex flex-col md:flex-row items-center gap-10">
                    <div className="space-y-6 flex-1 text-center md:text-left">
                        <div className="space-y-2">
                            <h2 className="text-3xl font-black tracking-tight font-display">The Memory Portal</h2>
                            <p className="text-slate-400 font-medium leading-relaxed max-w-md">
                                All insights, scans, and conversations generated by your agents are securely stored in your personal Memory Portal. Access your complete medical history here.
                            </p>
                        </div>

                        <button
                            onClick={() => navigate('/history')}
                            className="px-8 py-4 bg-white text-bb-pitch rounded-2xl font-black text-sm uppercase tracking-widest hover:bg-slate-200 transition-colors flex items-center gap-3 shadow-lg group mx-auto md:mx-0 font-display"
                        >
                            <Database className="w-4 h-4" />
                            Access Memory Portal
                            <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
                        </button>
                    </div>

                    <div className="w-full md:w-auto flex justify-center">
                        <div className="bg-white/5 backdrop-blur-md p-6 rounded-3xl border border-white/10 w-64">
                            <div className="flex items-center gap-3 mb-4">
                                <Activity className="w-5 h-5 text-tesla-cyan" />
                                <div className="h-2 w-24 bg-white/20 rounded-full"></div>
                            </div>
                            <div className="space-y-3">
                                <div className="h-2 w-full bg-white/10 rounded-full"></div>
                                <div className="h-2 w-3/4 bg-white/10 rounded-full"></div>
                                <div className="h-2 w-1/2 bg-white/10 rounded-full"></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
}
