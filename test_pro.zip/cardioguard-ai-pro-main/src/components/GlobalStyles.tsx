import React from 'react';

const GlobalStyles = () => (
  <style>{`
    /* Global Clinical Resets */
    :root {
      --medical-blue: #0284c7;
    }

    body {
      margin: 0;
      padding: 0;
      -webkit-font-smoothing: antialiased;
      -moz-osx-font-smoothing: grayscale;
    }

    * {
      box-sizing: border-box;
    }

    /* Selection Color */
    ::selection {
      background: rgba(2, 132, 199, 0.1);
      color: #0284c7;
    }

    /* Scrollbar Styling for Clinical Feel */
    ::-webkit-scrollbar {
      width: 6px;
      height: 6px;
    }
    
    ::-webkit-scrollbar-track {
      background: transparent;
    }
    
    ::-webkit-scrollbar-thumb {
      background: #e2e8f0;
      border-radius: 10px;
    }
    
    ::-webkit-scrollbar-thumb:hover {
      background: #cbd5e1;
    }
  `}</style>
);

export default GlobalStyles;
