import React, { useState } from 'react';
import {
    Check,
    Zap,
    ShieldCheck,
    Star,
    CreditCard,
    ChevronLeft,
    Activity,
    Globe,
    Sparkles,
    Lock,
    Loader2
} from 'lucide-react';

interface SubscriptionProps {
    onBack: () => void;
}

const Subscription: React.FC<SubscriptionProps> = ({ onBack }) => {
    const [loading, setLoading] = useState(false);
    const [success, setSuccess] = useState(false);

    const handleCheckout = () => {
        setLoading(true);
        // Simulate Stripe Checkout
        setTimeout(() => {
            setLoading(false);
            setSuccess(true);
        }, 2500);
    };

    if (success) {
        return (
            <div className="flex flex-col items-center justify-center min-h-[60vh] space-y-8 animate-in zoom-in duration-500">
                <div className="w-24 h-24 bg-emerald-500 rounded-full flex items-center justify-center shadow-2xl shadow-emerald-500/40">
                    <ShieldCheck size={48} className="text-white" />
                </div>
                <div className="text-center space-y-2">
                    <h2 className="text-4xl font-black text-slate-900 tracking-tighter">Pro Access Active</h2>
                    <p className="text-slate-500 font-bold uppercase tracking-widest text-sm">Welcome to the Gold Tier of Heart Protection</p>
                </div>
                <button
                    onClick={onBack}
                    className="px-10 py-4 bg-slate-900 text-white rounded-2xl font-black text-xs uppercase tracking-widest shadow-xl hover:bg-slate-800 transition-all"
                >
                    Return to Laboratory
                </button>
            </div>
        );
    }

    return (
        <div className="space-y-12 animate-in fade-in duration-700 pb-20">
            {/* HEADER */}
            <div className="flex items-center justify-between">
                <button
                    onClick={onBack}
                    className="flex items-center gap-3 text-slate-500 hover:text-cyan-600 transition-all font-black text-[10px] uppercase tracking-widest"
                >
                    <ChevronLeft className="w-4 h-4" /> Return to Dashboard
                </button>
                <div className="flex items-center gap-2 px-3 py-1 bg-amber-100 text-amber-700 rounded-lg text-[10px] font-black uppercase tracking-widest">
                    <Sparkles size={12} /> Seasonal Beta Pricing Active
                </div>
            </div>

            <div className="space-y-6 text-center max-w-2xl mx-auto">
                <h1 className="text-5xl md:text-6xl font-black tracking-tighter text-slate-950">Scale Your <span className="text-cyan-600">Heart Health.</span></h1>
                <p className="text-slate-500 text-lg font-medium leading-relaxed">
                    Upgrade to Premium for unlimited rPPG scans, 12-month predictive modeling, and direct clinician-handover features.
                </p>
            </div>

            {/* PRICING GRID */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-4xl mx-auto items-stretch">

                {/* FREE TIER */}
                <div className="bg-white rounded-[3rem] p-10 border border-sky-100 shadow-sm flex flex-col hover:shadow-md transition-all">
                    <div className="space-y-2 mb-8">
                        <p className="text-[10px] font-black text-slate-400 uppercase tracking-[0.3em]">Basic Node</p>
                        <h3 className="text-3xl font-black text-slate-900">$0<span className="text-sm text-slate-400">/mo</span></h3>
                    </div>

                    <ul className="space-y-4 mb-12 flex-1">
                        <PricingFeature text="3 Clinical Scans / mo" />
                        <PricingFeature text="Standard XGBoost Risk Model" />
                        <PricingFeature text="Basic Symptom Tracker" />
                        <PricingFeature text="Local Data Storage" inactive />
                        <PricingFeature text="12-Month Trajectory" inactive />
                        <PricingFeature text="Direct Doctor Link" inactive />
                    </ul>

                    <button
                        onClick={onBack}
                        className="w-full py-5 bg-slate-50 text-slate-400 rounded-2xl font-black text-xs uppercase tracking-widest cursor-not-allowed"
                    >
                        Current Phase
                    </button>
                </div>

                {/* PRO TIER */}
                <div className="bg-slate-900 rounded-[3rem] p-1 shadow-2xl relative overflow-hidden flex flex-col group scale-105">
                    {/* GLOW DECOR */}
                    <div className="absolute -top-24 -right-24 w-64 h-64 bg-cyan-500/20 blur-[100px] rounded-full group-hover:bg-cyan-500/30 transition-all"></div>

                    <div className="bg-slate-900 p-10 rounded-[2.8rem] flex flex-col flex-1 relative z-10">
                        <div className="flex justify-between items-start mb-8">
                            <div className="space-y-2">
                                <p className="text-[10px] font-black text-cyan-400 uppercase tracking-[0.3em]">Premium Uplink</p>
                                <h3 className="text-3xl font-black text-white">$19<span className="text-sm text-slate-500">/mo</span></h3>
                            </div>
                            <div className="bg-cyan-600 text-white p-2.5 rounded-2xl">
                                <Zap size={20} />
                            </div>
                        </div>

                        <ul className="space-y-4 mb-12 flex-1">
                            <PricingFeature text="Unlimited Bio-Scans" inverse />
                            <PricingFeature text="Full 12-Month AI Trajectory" inverse />
                            <PricingFeature text="Direct Clinician Handover" inverse />
                            <PricingFeature text="Advanced Women's Health Sentinel" inverse />
                            <PricingFeature text="Encryption Medical Locker (Cloud)" inverse />
                            <PricingFeature text="Priority Concierge Access" inverse />
                        </ul>

                        <button
                            onClick={handleCheckout}
                            disabled={loading}
                            className="w-full py-5 bg-cyan-600 hover:bg-cyan-500 text-white rounded-2xl font-black text-xs uppercase tracking-widest shadow-xl shadow-cyan-600/20 transition-all flex items-center justify-center gap-3 active:scale-95"
                        >
                            {loading ? <Loader2 className="w-5 h-5 animate-spin" /> : <CreditCard size={18} />}
                            {loading ? 'Processing Protocol...' : 'Initialize Pro TIER'}
                        </button>
                    </div>
                </div>
            </div>

            {/* TRUST SIGNALS */}
            <div className="flex flex-wrap justify-center gap-12 pt-12">
                <TrustNode icon={<Globe className="text-cyan-600" />} label="Unified Global Access" />
                <TrustNode icon={<Lock className="text-emerald-600" />} label="Secure Stripe Checkout" />
                <TrustNode icon={<ShieldCheck className="text-blue-600" />} label="HIPAA-Ready Compliance" />
            </div>

            <div className="max-w-xl mx-auto p-6 bg-slate-50 rounded-2xl text-center">
                <p className="text-[9px] font-bold text-slate-400 uppercase tracking-widest leading-relaxed">
                    Prices shown in USD. Subscriptions can be managed via the Clinical Settings node. 30-day biological stability guarantee.
                </p>
            </div>
        </div>
    );
};

function PricingFeature({ text, inactive, inverse }: { text: string; inactive?: boolean; inverse?: boolean }) {
    return (
        <li className={`flex items-center gap-3 text-sm font-bold ${inactive ? 'opacity-20' : ''} ${inverse ? 'text-slate-300' : 'text-slate-600'}`}>
            <div className={`shrink-0 w-5 h-5 rounded-full flex items-center justify-center ${inverse ? 'bg-cyan-500 text-slate-900' : 'bg-cyan-50 text-cyan-600'}`}>
                <Check size={12} strokeWidth={4} />
            </div>
            {text}
        </li>
    );
}

function TrustNode({ icon, label }: { icon: React.ReactNode; label: string }) {
    return (
        <div className="flex items-center gap-3">
            <div className="bg-white p-2.5 rounded-xl shadow-sm border border-slate-50">{icon}</div>
            <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest">{label}</span>
        </div>
    );
}

export default Subscription;
