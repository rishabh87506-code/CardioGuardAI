
import { GoogleGenAI } from "@google/genai";
import * as dotenv from 'dotenv';
import * as fs from 'fs';
import * as path from 'path';

// Load environment variables
dotenv.config();

const apiKey = process.env.VITE_GEMINI_API_KEY;
if (!apiKey) {
    console.error("❌ MISSING API KEY. Please set VITE_GEMINI_API_KEY in .env");
    process.exit(1);
}

const ai = new GoogleGenAI({ apiKey });

// --- Types ---
interface VitalsData {
    age: number;
    gender: 'male' | 'female' | 'other';
    systolicBP: number;
    diastolicBP: number;
    totalCholesterol: number;
    hdlCholesterol: number;
    isSmoker: boolean;
    hasDiabetes: boolean;
    heightCm: number;
    weightKg: number;
    activityLevel: 'sedentary' | 'moderate' | 'active';
}

interface AssessmentResult {
    riskScore: number;
    riskCategory: string;
    summary: string;
}

interface TestCase {
    id: string;
    age: number;
    cholesterol: number;
    bpSystolic: number;
    smoker: boolean;
    diabetic: boolean;
    activity: string;
    targetRisk: string;
}

// --- Logic ---

const assessRisk = async (vitals: VitalsData): Promise<AssessmentResult> => {
    const prompt = `
    Assess cardiovascular risk.
    PATIENT: Age ${vitals.age}, BP ${vitals.systolicBP}/${vitals.diastolicBP}, Chol ${vitals.totalCholesterol}, Smoker: ${vitals.isSmoker}, Diabetes: ${vitals.hasDiabetes}.
    Calculate 10-year risk. Return JSON: { "riskScore": number, "riskCategory": "Low"|"Moderate"|"High"|"Very High", "summary": "string" }
    `;

    try {
        const response = await ai.models.generateContent({
            model: 'gemini-2.0-flash', // Using flash for speed in benchmark
            contents: prompt,
            config: {
                responseMimeType: "application/json"
            }
        });

        const text = response.text || "{}";
        // console.log("Raw response:", text); 
        return JSON.parse(text);
    } catch (e) {
        console.error("AI Error:", e);
        return { riskScore: 0, riskCategory: "Error", summary: "Failed" };
    }
};

// --- Dataset ---
const DATASET_RAW = `55,260,160,Yes,Yes,Low,High
60,280,170,Yes,Yes,None,High
45,200,120,No,No,High,Low
30,180,110,No,No,Moderate,Low
50,230,145,Yes,No,Low,Medium
65,210,135,No,Yes,Moderate,Medium`;

const parseDataset = (): TestCase[] => {
    return DATASET_RAW.split('\n').map((line, idx) => {
        const [age, chol, bp, smoker, diabetic, activity, target] = line.split(',');
        return {
            id: `case-${idx}`,
            age: parseInt(age),
            cholesterol: parseInt(chol),
            bpSystolic: parseInt(bp),
            smoker: smoker === 'Yes',
            diabetic: diabetic === 'Yes',
            activity: activity,
            targetRisk: target
        };
    });
};

const mapToVitals = (tc: TestCase): VitalsData => ({
    age: tc.age,
    gender: 'male',
    systolicBP: tc.bpSystolic,
    diastolicBP: 80,
    totalCholesterol: tc.cholesterol,
    hdlCholesterol: 50,
    isSmoker: tc.smoker,
    hasDiabetes: tc.diabetic,
    heightCm: 175,
    weightKg: 80,
    activityLevel: 'moderate'
});

// --- Runner ---
const run = async () => {
    console.log(`
╔═══════════════════════════════════════════════════════════════╗
║   CardioGuard AI - Core Metrics Analysis (Terminal Protocol)  ║
╠═══════════════════════════════════════════════════════════════╣
`);

    const cases = parseDataset();
    console.log(`Loaded ${cases.length} Reference Cases for Benchmarking...\n`);

    let matches = 0;
    let totalLatency = 0;

    console.log(`| ID      | Ground Truth | AI Prediction | Score | Latency | Status |`);
    console.log(`|---------|--------------|---------------|-------|---------|--------|`);

    const delay = (ms: number) => new Promise(resolve => setTimeout(resolve, ms));

    for (const tc of cases) {
        await delay(5000); // 5s delay to respect rate limits
        const start = Date.now();
        const result = await assessRisk(mapToVitals(tc));
        const duration = Date.now() - start;
        totalLatency += duration;

        const ground = tc.targetRisk.toLowerCase();
        const pred = result.riskCategory.toLowerCase();

        let isMatch = false;
        if (ground === 'high' && (pred === 'high' || pred === 'very high')) isMatch = true;
        else if (ground === 'medium' && (pred === 'moderate' || pred === 'medium')) isMatch = true;
        else if (ground === 'low' && pred === 'low') isMatch = true;

        if (isMatch) matches++;

        const statusIcon = isMatch ? "✅" : "❌";

        console.log(`| ${tc.id.padEnd(7)} | ${tc.targetRisk.padEnd(12)} | ${result.riskCategory.padEnd(13)} | ${String(result.riskScore).padEnd(5)} | ${String(duration).padEnd(5)}ms | ${statusIcon}      |`);
    }

    const accuracy = (matches / cases.length) * 100;
    const avgLatency = totalLatency / cases.length;

    console.log(`
╠═══════════════════════════════════════════════════════════════╣
║                   FINAL METRICS SUMMARY                       ║
╠═══════════════════════════════════════════════════════════════╣
║  • Total Accuracy:   ${accuracy.toFixed(1)}%                           ║
║  • Avg Latency:      ${Math.round(avgLatency)}ms                             ║
║  • Throughput:       ${(1000 / avgLatency).toFixed(2)} req/sec                        ║
╚═══════════════════════════════════════════════════════════════╝
    `);
};

run().catch(console.error);
