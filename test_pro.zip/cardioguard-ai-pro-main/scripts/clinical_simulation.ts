
import { GoogleGenAI } from "@google/genai";
import * as dotenv from 'dotenv';
import * as fs from 'fs';
import * as path from 'path';

// Load environment variables
dotenv.config();

const apiKey = process.env.VITE_GEMINI_API_KEY;
if (!apiKey) {
    console.error("❌ MISSING API KEY. Please set VITE_GEMINI_API_KEY in .env");
    process.exit(1);
}

const ai = new GoogleGenAI({ apiKey });

// --- Types ---
interface VitalsData {
    age: number;
    gender: 'male' | 'female' | 'other';
    systolicBP: number;
    diastolicBP: number;
    totalCholesterol: number;
    hdlCholesterol: number;
    isSmoker: boolean;
    hasDiabetes: boolean;
    heightCm: number;
    weightKg: number;
    activityLevel: 'sedentary' | 'moderate' | 'active';
    symptoms: string[];
    medicalHistory: string[];
}

interface AssessmentResult {
    riskScore: number;
    riskCategory: string;
    summary: string;
}

interface ClinicalCase {
    id: string;
    vitals: VitalsData;
    conditionProfile: string; // e.g. "Acute MI", "Healthy", "Stable Angina"
}

// --- Generators ---

const CONDITIONS = [
    { name: "Acute Myocardial Infarction", severity: "CRITICAL", symptoms: ["crushing chest pain", "radiating arm pain", "diaphoresis", "nausea"], history: ["Hypertension", "Previous MI"], riskProfile: "Very High" },
    { name: "Unstable Angina", severity: "URGENT", symptoms: ["chest tightness at rest", "shortness of breath"], history: ["CAD", "High Cholesterol"], riskProfile: "High" },
    { name: "Stable CAD", severity: "STABLE", symptoms: ["chest pain on exertion"], history: ["Atherosclerosis"], riskProfile: "Moderate" },
    { name: "Heart Failure (Decompensated)", severity: "CRITICAL", symptoms: ["severe dyspnea", "orthopnea", "edema"], history: ["CHF", "Diabetes"], riskProfile: "Very High" },
    { name: "Arrhythmia (Afib)", severity: "MODERATE", symptoms: ["palpitations", "dizziness"], history: ["Atrial Fibrillation"], riskProfile: "Moderate" },
    { name: "Hypertensive Crisis", severity: "URGENT", symptoms: ["severe headache", "blurred vision"], history: ["Uncontrolled Hypertension"], riskProfile: "High" },
    { name: "Panic Attack (Mimic)", severity: "LOW", symptoms: ["racing heart", "tingling fingers", "anxiety"], history: ["Anxiety Disorder"], riskProfile: "Low" },
    { name: "Healthy / Routine", severity: "LOW", symptoms: [], history: [], riskProfile: "Low" },
    { name: "Metabolic Syndrome", severity: "MODERATE", symptoms: ["fatigue"], history: ["Obesity", "Pre-diabetes"], riskProfile: "Moderate" },
    { name: "Pulmonary Embolism", severity: "CRITICAL", symptoms: ["sudden sharp chest pain", "hypoxia", "tachycardia"], history: ["DVT", "Recent Surgery"], riskProfile: "Very High" }
];

const generateRandomCase = (idx: number): ClinicalCase => {
    // Weighted random selection to ensure mixed severity
    const condition = CONDITIONS[Math.floor(Math.random() * CONDITIONS.length)];

    // Base Vitals
    let sys = 120 + Math.floor(Math.random() * 20);
    let dia = 80 + Math.floor(Math.random() * 10);
    let hr = 60 + Math.floor(Math.random() * 40);
    let chol = 180 + Math.floor(Math.random() * 40);

    // Adjust vitals based on condition
    if (condition.name.includes("Hypertension") || condition.name.includes("Crisis")) {
        sys = 180 + Math.floor(Math.random() * 40);
        dia = 110 + Math.floor(Math.random() * 20);
    }
    if (condition.name.includes("Infarction") || condition.name.includes("Failure")) {
        hr = 100 + Math.floor(Math.random() * 30);
    }
    if (condition.name.includes("Metabolic") || condition.name.includes("CAD")) {
        chol = 240 + Math.floor(Math.random() * 60);
    }

    const vitals: VitalsData = {
        age: 35 + Math.floor(Math.random() * 50),
        gender: Math.random() > 0.5 ? 'male' : 'female',
        systolicBP: sys,
        diastolicBP: dia,
        totalCholesterol: chol,
        hdlCholesterol: 40 + Math.floor(Math.random() * 20),
        isSmoker: Math.random() > 0.7,
        hasDiabetes: Math.random() > 0.8 || condition.history.includes("Diabetes"),
        heightCm: 160 + Math.floor(Math.random() * 30),
        weightKg: 60 + Math.floor(Math.random() * 50),
        activityLevel: 'moderate',
        symptoms: condition.symptoms,
        medicalHistory: condition.history
    };

    return {
        id: `PT-${String(idx).padStart(3, '0')}`,
        vitals,
        conditionProfile: condition.name
    };
};

const assessRisk = async (caseData: ClinicalCase): Promise<AssessmentResult> => {
    const { vitals } = caseData;
    const prompt = `
    Assess cardiovascular risk for a clinical simulation.
    
    PATIENT PROFILE:
    - Condition Context: ${caseData.conditionProfile} (Simulated Ground Truth)
    - Demographics: ${vitals.age}y, ${vitals.gender}
    - Vitals: BP ${vitals.systolicBP}/${vitals.diastolicBP}, Chol ${vitals.totalCholesterol}
    - Reported Symptoms: ${vitals.symptoms.join(', ') || 'None'}
    - Medical History: ${vitals.medicalHistory.join(', ') || 'None'}
    
    TASK:
    1. Analyze the clinical presentation.
    2. Assign a Risk Category: Low, Moderate, High, or Very High.
    3. Provide a 1-sentence analytical summary.
    
    Return JSON: { "riskScore": number, "riskCategory": "string", "summary": "string" }
    `;

    try {
        const response = await ai.models.generateContent({
            model: 'gemini-2.0-flash',
            contents: prompt,
            config: { responseMimeType: "application/json" }
        });
        return JSON.parse(response.text());
    } catch (e) {
        return { riskScore: 0, riskCategory: "Error", summary: "AI Analysis Failed" };
    }
};

const runSimulation = async () => {
    console.log(`
╔═══════════════════════════════════════════════════════════════════════╗
║   CardioGuard AI - Large Scale Clinical Simulation (50 Patients)      ║
╠═══════════════════════════════════════════════════════════════════════╣
`);

    // 1. Generate Dataset
    const cases: ClinicalCase[] = [];
    for (let i = 1; i <= 50; i++) {
        cases.push(generateRandomCase(i));
    }
    console.log(`✅ Generated 50 Clinical Profiles (Mixed Severity: Critical to Stable)\n`);

    // 2. Run Analysis
    console.log(`| Patient | Condition Profile            | Symptoms                     | AI Risk Category | Risk Score | Status |`);
    console.log(`|---------|------------------------------|------------------------------|------------------|------------|--------|`);

    const results = [];
    const categoryCounts = { "Low": 0, "Moderate": 0, "High": 0, "Very High": 0, "Error": 0 };

    for (const c of cases) {
        const result = await assessRisk(c);
        results.push(result);

        // Update stats
        if (categoryCounts[result.riskCategory]) {
            categoryCounts[result.riskCategory]++;
        }

        const sympStr = c.vitals.symptoms.slice(0, 2).join(', ').substring(0, 28).padEnd(28);
        const condStr = c.conditionProfile.substring(0, 28).padEnd(28);

        let status = "✅";
        // Simple validation logic
        if (c.conditionProfile.includes("Infarction") && result.riskCategory !== "Very High") status = "⚠️";
        if (c.conditionProfile.includes("Healthy") && (result.riskCategory === "High" || result.riskCategory === "Very High")) status = "⚠️";

        console.log(`| ${c.id}  | ${condStr} | ${sympStr} | ${result.riskCategory.padEnd(16)} | ${String(result.riskScore).padEnd(10)} | ${status}     |`);
    }

    // 3. Summary Report
    console.log(`
╠═══════════════════════════════════════════════════════════════════════╣
║                   SIMULATION ANALYTICS REPORT                         ║
╠═══════════════════════════════════════════════════════════════════════╣
║  • Total Patients:   50                                               ║
║  • Risk Distribution:                                                 ║
║      - Very High (Critical):  ${categoryCounts["Very High"]} cases                        ║
║      - High (Urgent):         ${categoryCounts["High"]} cases                        ║
║      - Moderate (Stable):     ${categoryCounts["Moderate"]} cases                        ║
║      - Low (Routine):         ${categoryCounts["Low"]} cases                        ║
║                                                                       ║
║  • Simulation Integrity: ${results.length} processed successfully             ║
╚═══════════════════════════════════════════════════════════════════════╝
    `);
};

runSimulation().catch(console.error);
