/** @type {import('tailwindcss').Config} */
export default {
    content: [
        "./index.html",
        "./src/**/*.{js,ts,jsx,tsx}",
    ],
    theme: {
        extend: {
            colors: {
                'clinical-blue': '#0284c7',
                'clinical-dark': '#0f172a',
                'clinical-light': '#f8fafc',
                'critical': '#be123c',
                'success': '#10b981',
            },
            fontFamily: {
                inter: ['Inter', 'sans-serif'],
                outfit: ['Outfit', 'sans-serif'],
            },
            animation: {
                'heartbeat': 'heartbeat 1.5s ease-in-out infinite',
                'pulse-glow': 'pulse-glow 2s infinite',
                'scan': 'scan 3s linear infinite',
                'marquee': 'marquee 30s linear infinite',
            },
            keyframes: {
                heartbeat: {
                    '0%, 100%': { transform: 'scale(1)' },
                    '15%': { transform: 'scale(1.08)' },
                    '30%': { transform: 'scale(1)' },
                    '45%': { transform: 'scale(1.1)' },
                },
                'pulse-glow': {
                    '0%, 100%': { opacity: '1', boxShadow: '0 0 10px rgba(2, 132, 199, 0.4)' },
                    '50%': { opacity: '0.6', boxShadow: '0 0 20px rgba(2, 132, 199, 0.2)' },
                },
                scan: {
                    '0%': { top: '0%' },
                    '100%': { top: '100%' },
                },
                marquee: {
                    '0%': { transform: 'translateX(0%)' },
                    '100%': { transform: 'translateX(-100%)' },
                }
            }
        },
    },
    plugins: [
        require('tailwindcss-animate'),
    ],
}
