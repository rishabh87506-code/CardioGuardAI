-- CardioGuard AI: Supabase Clinical Schema & RLS Protocol

-- 1. PROFILES: High-integrity identity layer
create table if not exists public.profiles (
  id uuid references auth.users on delete cascade primary key,
  patient_name text,
  medical_id text unique,
  gender text,
  dob date,
  blood_group text,
  created_at timestamp with time zone default timezone('utc'::text, now()) not null
);

-- 2. VITALS: Bio-telemetry snapshots
create table if not exists public.vitals (
  id uuid default gen_random_uuid() primary key,
  patient_id uuid references auth.users on delete cascade not null,
  systolic_bp integer,
  diastolic_bp integer,
  heart_rate integer,
  spo2 decimal,
  temperature decimal,
  respiratory_rate integer,
  hrv integer,
  blood_sugar integer,
  is_smoker boolean default false,
  has_diabetes boolean default false,
  created_at timestamp with time zone default timezone('utc'::text, now()) not null
);

-- 3. SCANS: Photoplethysmography & Optical analysis captures
create table if not exists public.scans (
  id uuid default gen_random_uuid() primary key,
  patient_id uuid references auth.users on delete cascade not null,
  scan_type text default 'PPG',
  raw_data_url text, 
  result_value decimal,
  created_at timestamp with time zone default timezone('utc'::text, now()) not null
);

-- 4. RISK_ASSESSMENTS: AI-driven diagnostic outputs
create table if not exists public.risk_assessments (
  id uuid default gen_random_uuid() primary key,
  patient_id uuid references auth.users on delete cascade not null,
  vitals_id uuid references public.vitals(id) on delete set null,
  risk_score decimal not null,
  risk_level text not null,
  summary text,
  recommendations text[],
  timeline jsonb, 
  is_verified boolean default false,
  created_at timestamp with time zone default timezone('utc'::text, now()) not null
);

-- RLS SECURITY POLICIES --

-- Enable RLS
alter table public.profiles enable row level security;
alter table public.vitals enable row level security;
alter table public.scans enable row level security;
alter table public.risk_assessments enable row level security;

-- PROFILES: Owner view/update
create policy "Profiles are viewable by owner" on public.profiles for select using (auth.uid() = id);
create policy "Profiles are updatable by owner" on public.profiles for update using (auth.uid() = id);

-- VITALS: Owner view/insert
create policy "Vitals are viewable by owner" on public.vitals for select using (auth.uid() = patient_id);
create policy "Users can log their own vitals" on public.vitals for insert with check (auth.uid() = patient_id);

-- SCANS: Owner view/insert
create policy "Scans are viewable by owner" on public.scans for select using (auth.uid() = patient_id);
create policy "Users can log their own scans" on public.scans for insert with check (auth.uid() = patient_id);

-- RISK_ASSESSMENTS: Owner view/insert
create policy "Assessments are viewable by owner" on public.risk_assessments for select using (auth.uid() = patient_id);
create policy "Users can log their own assessments" on public.risk_assessments for insert with check (auth.uid() = patient_id);

-- CLINICIAN ACCESS (Emergency Handover)
-- Example: Allow users with 'clinician' metadata to view all assessments
-- create policy "Physicians can view assessments" on public.risk_assessments for select using (
--   (auth.jwt() ->> 'role') = 'clinician'
-- );
