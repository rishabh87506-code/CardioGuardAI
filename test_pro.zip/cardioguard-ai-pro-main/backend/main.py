from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
import joblib
import numpy as np
import os
import google.generativeai as genai

app = FastAPI(title="CardioGuard AI - Prediction & Chat Node")

# CORS for frontend access
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Configure Gemini
GEMINI_KEY = os.getenv("VITE_GEMINI_API_KEY") or os.getenv("GEMINI_API_KEY")
if GEMINI_KEY:
    genai.configure(api_key=GEMINI_KEY)

# Load XGBoost Model
MODEL_PATH = 'xgboost_cardio_model.pkl'
try:
    if os.path.exists(MODEL_PATH):
        model = joblib.load(MODEL_PATH)
    else:
        print(f"Warning: {MODEL_PATH} not found. Prediction endpoint will be disabled.")
        model = None
except Exception as e:
    print(f"Error loading model: {e}")
    model = None

# Schemas
class RiskInput(BaseModel):
    age_years: int
    gender: int
    height: int
    weight: float
    ap_hi: int
    ap_lo: int
    cholesterol: int
    gluc: int
    smoke: int
    alco: int
    active: int

class ChatMessage(BaseModel):
    role: str
    content: str

class ChatInput(BaseModel):
    message: str
    history: list[ChatMessage]
    profile: dict = None
    recent_risk: dict = None

@app.get("/")
async def root():
    return {
        "status": "Operational",
        "model_loaded": model is not None,
        "ai_ready": GEMINI_KEY is not None
    }

@app.post("/predict")
async def predict_risk(data: RiskInput):
    if model is None:
        raise HTTPException(status_code=503, detail="CVD Model not loaded on server.")
    try:
        features = np.array([[
            data.age_years, data.gender, data.height, data.weight,
            data.ap_hi, data.ap_lo, data.cholesterol, data.gluc,
            data.smoke, data.alco, data.active
        ]])
        probability = model.predict_proba(features)[0][1]
        risk_level = "high" if probability > 0.7 else "medium" if probability > 0.4 else "low"
        return {
            "probability": float(probability),
            "risk_level": risk_level,
            "score": round(probability * 100, 2),
            "recommendations": "Consult doctor if high risk. Maintain healthy lifestyle."
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/api/gemini-chat")
async def gemini_chat(data: ChatInput):
    if not GEMINI_KEY:
        raise HTTPException(status_code=503, detail="Gemini API Key not configured.")
    
    try:
        # Construct system instruction
        system_instruction = f"""
        You are a helpful, professional cardiovascular health assistant for CardioGuard AI.
        Your role is preventive guidance ONLY:
        - Use evidence-based advice from AHA/ESC guidelines.
        - Never diagnose, prescribe, or give medical advice.
        - If question is non-health related or urgent, say: "I'm focused on preventive heart health. For emergencies, call local services. For medical concerns, consult a doctor."
        - Be concise, empathetic, actionable.
        - Reference user data if provided to personalize prevention tips.
        - Always end with: "This is not medical advice – see a healthcare professional."

        User profile: {data.profile if data.profile else 'Not provided'}
        Recent risk: {data.recent_risk if data.recent_risk else 'Not provided'}
        """

        chat_model = genai.GenerativeModel(
            model_name='gemini-1.5-flash',
            system_instruction=system_instruction
        )

        formatted_history = []
        for m in data.history:
            formatted_history.append({
                "role": "user" if m.role == "user" else "model",
                "parts": [m.content]
            })

        chat = chat_model.start_chat(history=formatted_history)
        response = chat.send_message(data.message)
        
        return {"response": response.text}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=int(os.getenv("PORT", 8000)))
