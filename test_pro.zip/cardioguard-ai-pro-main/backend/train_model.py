import pandas as pd
from sklearn.model_selection import train_test_split
from xgboost import XGBClassifier
from sklearn.metrics import accuracy_score, classification_report
import joblib

# Load Kaggle cardio_train.csv (download from https://www.kaggle.com/datasets/sulianova/cardiovascular-disease-dataset)
# Ensure this file is present in the same directory
df = pd.read_csv('cardio_train.csv', sep=';')

# Preprocess
df['age_years'] = df['age'] // 365
df = df.drop(['id', 'age'], axis=1)  # drop ID and original age

X = df.drop('cardio', axis=1)
y = df['cardio']

X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

model = XGBClassifier(n_estimators=200, learning_rate=0.1, max_depth=5, random_state=42)
model.fit(X_train, y_train)

# Evaluate
preds = model.predict(X_test)
print("Accuracy:", accuracy_score(y_test, preds))
print(classification_report(y_test, preds))

# Save model
joblib.dump(model, 'xgboost_cardio_model.pkl')
print("Model saved as xgboost_cardio_model.pkl")
