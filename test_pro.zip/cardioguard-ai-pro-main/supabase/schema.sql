-- CardioGuard AI - Supabase Database Schema
-- Run this SQL in your Supabase SQL Editor (Dashboard → SQL Editor)

-- ============================================
-- USER PROFILES TABLE
-- Stores user health profiles and emergency contacts
-- ============================================
CREATE TABLE IF NOT EXISTS user_profiles (
  id UUID REFERENCES auth.users PRIMARY KEY,
  name TEXT,
  age INTEGER,
  gender TEXT CHECK (gender IN ('male', 'female', 'other')),
  known_conditions TEXT[] DEFAULT '{}',
  medications TEXT[] DEFAULT '{}',
  allergies TEXT[] DEFAULT '{}',
  emergency_contact JSONB,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- ============================================
-- HEALTH ASSESSMENTS TABLE
-- Stores AI-powered health risk assessments
-- ============================================
CREATE TABLE IF NOT EXISTS health_assessments (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES auth.users NOT NULL,
  risk_score INTEGER CHECK (risk_score >= 0 AND risk_score <= 100),
  risk_category TEXT CHECK (risk_category IN ('Low', 'Moderate', 'High', 'Very High')),
  summary TEXT,
  vitals JSONB,
  key_factors JSONB DEFAULT '[]',
  recommendations TEXT[] DEFAULT '{}',
  consistency_score INTEGER,
  consistency_alert TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- ============================================
-- SYMPTOM ENTRIES TABLE
-- Tracks patient symptoms over time
-- ============================================
CREATE TABLE IF NOT EXISTS symptom_entries (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES auth.users NOT NULL,
  symptom TEXT NOT NULL,
  category TEXT,
  severity TEXT CHECK (severity IN ('MILD', 'MODERATE', 'SEVERE', 'CRITICAL')),
  notes TEXT,
  triggers TEXT[] DEFAULT '{}',
  duration TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- ============================================
-- INDEXES FOR PERFORMANCE
-- ============================================
CREATE INDEX IF NOT EXISTS idx_assessments_user_id ON health_assessments(user_id);
CREATE INDEX IF NOT EXISTS idx_assessments_created_at ON health_assessments(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_symptoms_user_id ON symptom_entries(user_id);
CREATE INDEX IF NOT EXISTS idx_symptoms_created_at ON symptom_entries(created_at DESC);

-- ============================================
-- ROW LEVEL SECURITY (RLS)
-- Ensures users can only access their own data
-- ============================================

-- Enable RLS on all tables
ALTER TABLE user_profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE health_assessments ENABLE ROW LEVEL SECURITY;
ALTER TABLE symptom_entries ENABLE ROW LEVEL SECURITY;

-- User Profiles: Users can only access their own profile
CREATE POLICY "Users can view own profile" 
  ON user_profiles FOR SELECT 
  USING (auth.uid() = id);

CREATE POLICY "Users can insert own profile" 
  ON user_profiles FOR INSERT 
  WITH CHECK (auth.uid() = id);

CREATE POLICY "Users can update own profile" 
  ON user_profiles FOR UPDATE 
  USING (auth.uid() = id);

-- Health Assessments: Users can only access their own assessments
CREATE POLICY "Users can view own assessments" 
  ON health_assessments FOR SELECT 
  USING (auth.uid() = user_id);

CREATE POLICY "Users can insert own assessments" 
  ON health_assessments FOR INSERT 
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can delete own assessments" 
  ON health_assessments FOR DELETE 
  USING (auth.uid() = user_id);

-- Symptom Entries: Users can only access their own symptoms
CREATE POLICY "Users can view own symptoms" 
  ON symptom_entries FOR SELECT 
  USING (auth.uid() = user_id);

CREATE POLICY "Users can insert own symptoms" 
  ON symptom_entries FOR INSERT 
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can delete own symptoms" 
  ON symptom_entries FOR DELETE 
  USING (auth.uid() = user_id);

-- ============================================
-- AUTO-UPDATE TIMESTAMP TRIGGER
-- ============================================
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$ language 'plpgsql';

CREATE TRIGGER update_user_profiles_updated_at
  BEFORE UPDATE ON user_profiles
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

-- ============================================
-- SUCCESS MESSAGE
-- ============================================
-- If you see this, the schema was created successfully!
-- Your CardioGuard AI database is ready to use.
