# CardioGuard AI - Clinical Triage Engine 🧬

CardioGuard AI is a state-of-the-art cardiovascular health intelligence platform. It leverages Google Gemini AI and real-time biometric analysis to provide clinical-grade risk assessments and patient monitoring.

## 🚀 Vision
To bridge the gap between "Silent" cardiovascular symptoms and life-saving clinical intervention through transparent, AI-driven diagnostics.

## 🛡️ Core Technologies
- **Frontend**: React 19 + TypeScript + Vite
- **Styling**: Tailwind CSS + Framer Motion
- **Intelligence**: Google Gemini 2.0 Flash
- **Backend**: Supabase (Auth, DB, Real-time)
- **Security**: HIPAA-ready AES-256 encryption

## 🛠️ Project Structure
- `/src/components`: UI components (Vitals, Lab, Agents, etc.)
- `/src/services`: AI and Database uplink logic
- `/src/types`: Centralized medical data schemas
- `/scripts`: Clinical trial simulations and benchmarking

## 🧪 Advanced Features
- **She-Guard Protocol™**: Specialized gender-based risk analysis for non-traditional heart symptoms.
- **Diagnostic Lab**: Real-time benchmarking against clinical ground truth datasets.
- **Vital Stream**: Continuous multi-agent monitoring of patient health nodes.
- **PPG Scanner**: rPPG-simulated heart rate detection using machine vision.

## 📦 Getting Started
1. Clone the repository.
2. Run `npm install`.
3. Set your `VITE_GEMINI_API_KEY` in `.env`.
4. Run `npm run dev`.

---
*Created with the precision of AI. Designed for human life.*
